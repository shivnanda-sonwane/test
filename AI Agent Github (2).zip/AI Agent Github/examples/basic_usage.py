"""
Basic usage examples for the Repository Setup Agent.
"""

import asyncio
from pathlib import Path
from repo_agent import RepoSetupAgent


async def basic_setup_example():
    """Basic repository setup example."""
    print("🚀 Basic Repository Setup Example")
    print("=" * 50)
    
    # Initialize the agent
    agent = RepoSetupAgent()
    
    # Set up a repository
    repository_url = "https://github.com/psf/requests.git"
    
    try:
        result = await agent.setup_repository(repository_url)
        
        if result.success:
            print(f"✅ Setup completed successfully!")
            print(f"📂 Repository: {result.repository.url}")
            print(f"📁 Location: {result.repository.local_path}")
            print(f"🔍 Detected: {result.detection.language.value}")
            print(f"⏱️ Duration: {result.total_duration:.2f} seconds")
            
            if result.detection.framework_indicators:
                print(f"🔧 Frameworks: {', '.join(result.detection.framework_indicators)}")
            
            if result.environment:
                print(f"🐍 Environment: {result.environment.type} at {result.environment.path}")
            
            if result.dependencies:
                successful_deps = sum(1 for dep in result.dependencies if dep.success)
                print(f"📦 Dependencies: {successful_deps}/{len(result.dependencies)} installed")
        else:
            print("❌ Setup failed!")
            for operation in result.failed_operations:
                print(f"   Failed: {operation.name} - {operation.error_message}")
                
    except Exception as e:
        print(f"❌ Error: {e}")


async def custom_configuration_example():
    """Example with custom configuration."""
    print("\n⚙️ Custom Configuration Example")
    print("=" * 50)
    
    # Custom configuration
    config_overrides = {
        'workspace_dir': Path('./my-custom-workspace'),
        'max_concurrent_operations': 5,
        'log_level': 'DEBUG',
        'force_environment_creation': True,
        'parallel_dependency_install': True
    }
    
    agent = RepoSetupAgent(config_overrides)
    
    # Show agent configuration
    agent_info = agent.get_agent_info()
    print("🔧 Agent Configuration:")
    for key, value in agent_info.items():
        print(f"   {key}: {value}")


async def batch_setup_example():
    """Batch repository setup example."""
    print("\n🔄 Batch Setup Example")
    print("=" * 50)
    
    agent = RepoSetupAgent()
    
    # List of repositories to set up
    repositories = [
        "https://github.com/psf/requests.git",
        "https://github.com/pallets/flask.git",
        "https://github.com/encode/starlette.git"
    ]
    
    try:
        print(f"Setting up {len(repositories)} repositories...")
        
        results = await agent.setup_multiple_repositories(
            repository_urls=repositories,
            base_directory=Path("./batch-projects"),
            max_concurrent=2
        )
        
        # Analyze results
        successful = [r for r in results if r.success]
        failed = [r for r in results if not r.success]
        
        print(f"\n📊 Batch Results:")
        print(f"   ✅ Successful: {len(successful)}")
        print(f"   ❌ Failed: {len(failed)}")
        
        if successful:
            print(f"\n✅ Successfully set up:")
            for result in successful:
                repo_name = Path(result.repository.url).stem.replace('.git', '')
                print(f"   - {repo_name} ({result.detection.language.value})")
        
        if failed:
            print(f"\n❌ Failed to set up:")
            for result in failed:
                repo_name = Path(result.repository.url).stem.replace('.git', '')
                print(f"   - {repo_name}")
                
    except Exception as e:
        print(f"❌ Batch setup error: {e}")


async def repository_info_example():
    """Example of getting repository information without cloning."""
    print("\n📋 Repository Information Example")
    print("=" * 50)
    
    agent = RepoSetupAgent()
    
    repository_url = "https://github.com/django/django.git"
    
    try:
        repo_info = await agent.get_repository_info(repository_url)
        
        print(f"📂 Repository Information for {repository_url}:")
        print(f"   Name: {repo_info.get('name', 'N/A')}")
        print(f"   Description: {repo_info.get('description', 'N/A')}")
        print(f"   Language: {repo_info.get('language', 'N/A')}")
        print(f"   Stars: {repo_info.get('stars', 'N/A')}")
        print(f"   Forks: {repo_info.get('forks', 'N/A')}")
        print(f"   Size: {repo_info.get('size', 'N/A')} KB")
        print(f"   Default Branch: {repo_info.get('default_branch', 'N/A')}")
        
    except Exception as e:
        print(f"❌ Error getting repository info: {e}")


async def error_handling_example():
    """Example of error handling and recovery."""
    print("\n🛠️ Error Handling Example")
    print("=" * 50)
    
    agent = RepoSetupAgent()
    
    # Try to set up an invalid repository
    invalid_url = "https://github.com/nonexistent/repository.git"
    
    try:
        result = await agent.setup_repository(invalid_url)
        
        if not result.success:
            print(f"❌ Setup failed as expected for invalid repository")
            print(f"📊 Operation Summary:")
            
            for operation in result.operations:
                status_icon = "✅" if operation.status.value == "completed" else "❌"
                print(f"   {status_icon} {operation.name}: {operation.status.value}")
                
                if operation.error_message:
                    print(f"      Error: {operation.error_message}")
                    
    except Exception as e:
        print(f"❌ Expected error: {e}")


async def cleanup_example():
    """Example of workspace cleanup."""
    print("\n🧹 Cleanup Example")
    print("=" * 50)
    
    agent = RepoSetupAgent()
    
    try:
        # Show current workspace status
        workspace_info = agent.get_agent_info()
        print(f"📁 Workspace: {workspace_info['workspace_dir']}")
        
        # Perform cleanup
        cleanup_stats = await agent.cleanup_workspace(keep_successful=True)
        
        print(f"🧹 Cleanup Results:")
        print(f"   Cleaned: {cleanup_stats['cleaned']} directories")
        print(f"   Kept: {cleanup_stats['kept']} directories")
        print(f"   Errors: {cleanup_stats['errors']} directories")
        
    except Exception as e:
        print(f"❌ Cleanup error: {e}")


async def advanced_usage_example():
    """Advanced usage example with all features."""
    print("\n🎯 Advanced Usage Example")
    print("=" * 50)
    
    # Custom configuration for production use
    config_overrides = {
        'workspace_dir': Path('./production-workspace'),
        'max_concurrent_operations': 3,
        'timeout_minutes': 45,
        'enable_async_operations': True,
        'parallel_dependency_install': True,
        'cache_detection_results': True
    }
    
    agent = RepoSetupAgent(config_overrides)
    
    # Get supported languages
    supported_langs = agent.get_supported_languages()
    print(f"🔧 Supported languages: {', '.join(supported_langs)}")
    
    # Set up a complex project
    repository_url = "https://github.com/tiangolo/fastapi.git"
    
    try:
        print(f"\n🚀 Setting up complex project: {repository_url}")
        
        result = await agent.setup_repository(
            repository_url=repository_url,
            target_directory=Path("./advanced-project"),
            show_progress=True
        )
        
        if result.success:
            print(f"\n✅ Advanced setup completed!")
            
            # Detailed analysis
            print(f"📊 Detailed Analysis:")
            print(f"   Language: {result.detection.language.value}")
            print(f"   Confidence: {result.detection.confidence:.2%}")
            print(f"   Detected files: {len(result.detection.detected_files)}")
            print(f"   Package manager files: {result.detection.package_manager_files}")
            print(f"   Framework indicators: {result.detection.framework_indicators}")
            
            if result.environment:
                print(f"   Environment type: {result.environment.type}")
                print(f"   Environment created: {result.environment.created}")
            
            print(f"   Total operations: {len(result.operations)}")
            print(f"   Successful operations: {len(result.completed_operations)}")
            print(f"   Failed operations: {len(result.failed_operations)}")
            print(f"   Total duration: {result.total_duration:.2f}s")
            
            if result.created_files:
                print(f"   Created files: {result.created_files}")
        
    except Exception as e:
        print(f"❌ Advanced setup error: {e}")


async def main():
    """Run all examples."""
    print("🚀 Repository Setup Agent - Examples")
    print("=" * 60)
    
    examples = [
        basic_setup_example,
        custom_configuration_example,
        repository_info_example,
        batch_setup_example,
        error_handling_example,
        cleanup_example,
        advanced_usage_example
    ]
    
    for example in examples:
        try:
            await example()
            print("\n" + "─" * 60)
        except KeyboardInterrupt:
            print("\n⏹️ Examples interrupted by user")
            break
        except Exception as e:
            print(f"❌ Example failed: {e}")
            print("─" * 60)
    
    print("\n🎉 Examples completed!")


if __name__ == "__main__":
    asyncio.run(main()) 