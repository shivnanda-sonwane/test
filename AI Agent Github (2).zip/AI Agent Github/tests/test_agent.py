"""
Comprehensive tests for the Repository Setup Agent.
"""

import pytest
import asyncio
import tempfile
import shutil
from pathlib import Path
from unittest.mock import Mock, patch, AsyncMock

from repo_agent import RepoSetupAgent
from repo_agent.models import (
    ProjectLanguage, ProjectDetectionResult, SetupResult, 
    RepositoryInfo, EnvironmentInfo
)


@pytest.fixture
def temp_workspace():
    """Create a temporary workspace for testing."""
    temp_dir = Path(tempfile.mkdtemp())
    yield temp_dir
    shutil.rmtree(temp_dir, ignore_errors=True)


@pytest.fixture
def agent_config():
    """Configuration for test agent."""
    return {
        'log_level': 'DEBUG',
        'timeout_minutes': 5,  # Shorter timeout for tests
        'max_concurrent_operations': 2
    }


@pytest.fixture
def test_agent(temp_workspace, agent_config):
    """Create a test agent with temporary workspace."""
    config_overrides = {
        **agent_config,
        'workspace_dir': temp_workspace
    }
    return RepoSetupAgent(config_overrides)


class TestRepoSetupAgent:
    """Test cases for the main RepoSetupAgent class."""
    
    def test_agent_initialization(self, test_agent):
        """Test agent initialization."""
        assert test_agent.workflow is not None
        agent_info = test_agent.get_agent_info()
        assert 'agent_name' in agent_info
        assert 'supported_languages' in agent_info
    
    def test_supported_languages(self, test_agent):
        """Test supported languages list."""
        languages = test_agent.get_supported_languages()
        assert 'python' in languages
        assert 'javascript' in languages
        assert 'typescript' in languages
        assert 'java' in languages
        assert 'go' in languages
        assert 'rust' in languages
        assert len(languages) > 5
    
    def test_agent_info(self, test_agent):
        """Test agent info retrieval."""
        info = test_agent.get_agent_info()
        required_keys = [
            'agent_name', 'workspace_dir', 'supported_languages',
            'max_concurrent_operations', 'timeout_minutes'
        ]
        for key in required_keys:
            assert key in info
    
    @pytest.mark.asyncio
    async def test_repository_info_github(self, test_agent):
        """Test repository info retrieval from GitHub."""
        # Mock GitHub API response
        mock_response = {
            'name': 'requests',
            'description': 'Python HTTP Requests for Humans',
            'language': 'Python',
            'stargazers_count': 50000,
            'forks_count': 9000,
            'size': 1000,
            'default_branch': 'main',
            'type': 'github'
        }
        
        with patch('aiohttp.ClientSession.get') as mock_get:
            mock_get.return_value.__aenter__.return_value.status = 200
            mock_get.return_value.__aenter__.return_value.json = AsyncMock(return_value={
                'name': 'requests',
                'description': 'Python HTTP Requests for Humans',
                'language': 'Python',
                'stargazers_count': 50000,
                'forks_count': 9000,
                'size': 1000,
                'default_branch': 'main'
            })
            
            info = await test_agent.get_repository_info("https://github.com/psf/requests.git")
            assert info['name'] == 'requests'
            assert info['language'] == 'Python'
            assert info['type'] == 'github'


class TestProjectDetection:
    """Test cases for project detection functionality."""
    
    def test_python_project_detection(self, temp_workspace):
        """Test Python project detection."""
        # Create a mock Python project
        project_dir = temp_workspace / "python_project"
        project_dir.mkdir()
        
        # Create Python-specific files
        (project_dir / "requirements.txt").write_text("flask==2.0.1\nrequests==2.25.1\n")
        (project_dir / "app.py").write_text("from flask import Flask\napp = Flask(__name__)\n")
        (project_dir / "main.py").write_text("def main():\n    print('Hello World')\n")
        
        from repo_agent.detector import ProjectDetector
        detector = ProjectDetector()
        
        # Run detection
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            result = loop.run_until_complete(detector.detect_project_type(project_dir))
            assert result.language == ProjectLanguage.PYTHON
            assert result.confidence > 0.5
            assert 'requirements.txt' in result.package_manager_files
            assert len(result.detected_files) > 0
        finally:
            loop.close()
    
    def test_javascript_project_detection(self, temp_workspace):
        """Test JavaScript project detection."""
        # Create a mock JavaScript project
        project_dir = temp_workspace / "js_project"
        project_dir.mkdir()
        
        # Create JavaScript-specific files
        package_json = {
            "name": "test-project",
            "version": "1.0.0",
            "dependencies": {
                "express": "^4.17.1",
                "lodash": "^4.17.21"
            }
        }
        
        import json
        (project_dir / "package.json").write_text(json.dumps(package_json, indent=2))
        (project_dir / "index.js").write_text("const express = require('express');\nconst app = express();\n")
        
        from repo_agent.detector import ProjectDetector
        detector = ProjectDetector()
        
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            result = loop.run_until_complete(detector.detect_project_type(project_dir))
            assert result.language == ProjectLanguage.JAVASCRIPT
            assert result.confidence > 0.5
            assert 'package.json' in result.package_manager_files
            assert 'express' in result.framework_indicators
        finally:
            loop.close()


class TestEnvironmentManagement:
    """Test cases for environment management."""
    
    @pytest.mark.asyncio
    async def test_python_environment_creation(self, temp_workspace):
        """Test Python virtual environment creation."""
        from repo_agent.environment import EnvironmentManager
        from repo_agent.models import ProjectDetectionResult
        
        env_manager = EnvironmentManager()
        
        # Mock detection result
        detection = ProjectDetectionResult(
            language=ProjectLanguage.PYTHON,
            confidence=0.9,
            detected_files=["app.py", "requirements.txt"],
            package_manager_files=["requirements.txt"]
        )
        
        # Create environment
        project_dir = temp_workspace / "test_project"
        project_dir.mkdir()
        
        try:
            env_info = await env_manager.create_environment(project_dir, detection)
            if env_info:  # Environment creation might be skipped in test environment
                assert env_info.type == "venv"
                assert env_info.path.exists()
                assert env_info.created is True
        except Exception as e:
            # Environment creation might fail in test environment due to missing Python
            pytest.skip(f"Environment creation failed in test environment: {e}")
    
    @pytest.mark.asyncio
    async def test_environment_validation(self, temp_workspace):
        """Test environment validation."""
        from repo_agent.environment import EnvironmentManager
        
        env_manager = EnvironmentManager()
        
        # Test with non-existent environment
        fake_env = EnvironmentInfo(
            type="venv",
            path=temp_workspace / "non_existent_venv",
            created=False
        )
        
        is_valid = await env_manager.validate_environment(fake_env)
        assert is_valid is False


class TestDependencyManagement:
    """Test cases for dependency management."""
    
    @pytest.mark.asyncio
    async def test_get_install_commands_python(self, temp_workspace):
        """Test getting Python install commands."""
        from repo_agent.dependency_manager import DependencyManager
        from repo_agent.models import ProjectDetectionResult
        
        dep_manager = DependencyManager()
        
        # Create test project with requirements.txt
        project_dir = temp_workspace / "python_project"
        project_dir.mkdir()
        (project_dir / "requirements.txt").write_text("flask==2.0.1\nrequests==2.25.1\n")
        
        detection = ProjectDetectionResult(
            language=ProjectLanguage.PYTHON,
            confidence=0.9,
            detected_files=["requirements.txt"],
            package_manager_files=["requirements.txt"]
        )
        
        commands = dep_manager._get_install_commands(project_dir, detection)
        assert len(commands) >= 2  # upgrade_pip + install_requirements
        assert any('pip install -r requirements.txt' in cmd['command'] for cmd in commands)
    
    @pytest.mark.asyncio
    async def test_get_install_commands_javascript(self, temp_workspace):
        """Test getting JavaScript install commands."""
        from repo_agent.dependency_manager import DependencyManager
        from repo_agent.models import ProjectDetectionResult
        
        dep_manager = DependencyManager()
        
        # Create test project with package.json
        project_dir = temp_workspace / "js_project"
        project_dir.mkdir()
        
        package_json = {"name": "test", "dependencies": {"express": "^4.17.1"}}
        import json
        (project_dir / "package.json").write_text(json.dumps(package_json))
        
        detection = ProjectDetectionResult(
            language=ProjectLanguage.JAVASCRIPT,
            confidence=0.9,
            detected_files=["package.json"],
            package_manager_files=["package.json"]
        )
        
        commands = dep_manager._get_install_commands(project_dir, detection)
        assert len(commands) >= 1
        assert any('npm install' in cmd['command'] for cmd in commands)


class TestWorkflowIntegration:
    """Integration tests for the complete workflow."""
    
    @pytest.mark.asyncio
    @patch('repo_agent.repository.RepositoryManager.clone_repository')
    @patch('repo_agent.detector.ProjectDetector.detect_project_type')
    @patch('repo_agent.environment.EnvironmentManager.create_environment')
    @patch('repo_agent.dependency_manager.DependencyManager.install_dependencies')
    async def test_complete_workflow_python(
        self, 
        mock_install_deps,
        mock_create_env,
        mock_detect,
        mock_clone,
        test_agent,
        temp_workspace
    ):
        """Test complete workflow for Python project."""
        
        # Mock repository cloning
        repo_path = temp_workspace / "test_repo"
        repo_path.mkdir()
        
        mock_clone.return_value = RepositoryInfo(
            url="https://github.com/test/repo.git",
            local_path=repo_path,
            branch="main",
            clone_success=True,
            clone_time=1.0,
            size_mb=5.0
        )
        
        # Mock project detection
        mock_detect.return_value = ProjectDetectionResult(
            language=ProjectLanguage.PYTHON,
            confidence=0.9,
            detected_files=["app.py", "requirements.txt"],
            package_manager_files=["requirements.txt"],
            framework_indicators=["flask"]
        )
        
        # Mock environment creation
        mock_create_env.return_value = EnvironmentInfo(
            type="venv",
            path=repo_path / "venv",
            created=True,
            python_version="3.9.0"
        )
        
        # Mock dependency installation
        mock_install_deps.return_value = []
        
        # Run the workflow
        result = await test_agent.setup_repository(
            repository_url="https://github.com/test/repo.git",
            show_progress=False
        )
        
        # Verify the workflow completed
        assert result is not None
        # Note: Success might be False due to mocked operations
        # but the workflow should complete without exceptions
    
    @pytest.mark.asyncio
    async def test_batch_setup_mock(self, test_agent):
        """Test batch setup with mocked repositories."""
        
        # Mock the individual setup method
        async def mock_setup(repo_url, target_dir=None, show_progress=True):
            return SetupResult(
                repository=RepositoryInfo(
                    url=repo_url,
                    local_path=Path("mock_path"),
                    clone_success=True
                ),
                detection=ProjectDetectionResult(
                    language=ProjectLanguage.PYTHON,
                    confidence=0.8
                ),
                success=True,
                total_duration=1.0
            )
        
        with patch.object(test_agent, 'setup_repository', side_effect=mock_setup):
            repositories = [
                "https://github.com/test/repo1.git",
                "https://github.com/test/repo2.git"
            ]
            
            results = await test_agent.setup_multiple_repositories(
                repository_urls=repositories,
                show_progress=False
            )
            
            assert len(results) == 2
            assert all(result.success for result in results)


class TestErrorHandling:
    """Test cases for error handling and recovery."""
    
    @pytest.mark.asyncio
    async def test_invalid_repository_url(self, test_agent):
        """Test handling of invalid repository URLs."""
        
        with pytest.raises(Exception):
            await test_agent.setup_repository("invalid-url")
    
    @pytest.mark.asyncio
    async def test_repository_not_found(self, test_agent):
        """Test handling of non-existent repositories."""
        
        # This should not raise an exception but should return a failed result
        try:
            result = await test_agent.setup_repository(
                "https://github.com/nonexistent/repository.git",
                show_progress=False
            )
            assert result.success is False
        except Exception:
            # Expected to fail due to network/git operations
            pass
    
    @pytest.mark.asyncio
    async def test_cleanup_workspace(self, test_agent, temp_workspace):
        """Test workspace cleanup functionality."""
        
        # Create some mock repositories
        (temp_workspace / "repo1" / ".git").mkdir(parents=True)
        (temp_workspace / "repo2" / ".git").mkdir(parents=True)
        (temp_workspace / "repo2" / "venv").mkdir(parents=True)  # Successful setup
        
        stats = await test_agent.cleanup_workspace(keep_successful=True)
        
        assert 'cleaned' in stats
        assert 'kept' in stats
        assert 'errors' in stats


class TestConfigurationManagement:
    """Test cases for configuration management."""
    
    def test_config_overrides(self, temp_workspace):
        """Test configuration overrides."""
        overrides = {
            'workspace_dir': temp_workspace,
            'max_concurrent_operations': 5,
            'log_level': 'DEBUG'
        }
        
        agent = RepoSetupAgent(overrides)
        agent_info = agent.get_agent_info()
        
        assert str(agent_info['workspace_dir']) == str(temp_workspace)
        assert agent_info['max_concurrent_operations'] == 5
    
    def test_default_configuration(self):
        """Test default configuration values."""
        agent = RepoSetupAgent()
        agent_info = agent.get_agent_info()
        
        assert 'workspace_dir' in agent_info
        assert 'supported_languages' in agent_info
        assert len(agent_info['supported_languages']) > 0


# Performance and stress tests
class TestPerformance:
    """Performance and stress tests."""
    
    @pytest.mark.asyncio
    @pytest.mark.slow
    async def test_concurrent_operations(self, test_agent):
        """Test concurrent operations performance."""
        
        # Mock setup method for performance testing
        async def mock_setup(repo_url, target_dir=None, show_progress=True):
            await asyncio.sleep(0.1)  # Simulate work
            return SetupResult(
                repository=RepositoryInfo(
                    url=repo_url,
                    local_path=Path("mock_path"),
                    clone_success=True
                ),
                detection=ProjectDetectionResult(
                    language=ProjectLanguage.PYTHON,
                    confidence=0.8
                ),
                success=True,
                total_duration=0.1
            )
        
        with patch.object(test_agent, 'setup_repository', side_effect=mock_setup):
            repositories = [f"https://github.com/test/repo{i}.git" for i in range(10)]
            
            start_time = asyncio.get_event_loop().time()
            results = await test_agent.setup_multiple_repositories(
                repository_urls=repositories,
                max_concurrent=3,
                show_progress=False
            )
            end_time = asyncio.get_event_loop().time()
            
            assert len(results) == 10
            assert all(result.success for result in results)
            
            # Should complete faster than sequential execution
            assert end_time - start_time < 5.0  # Should be much faster than 10 * 0.1


# Utility functions for tests
def create_mock_git_repo(path: Path):
    """Create a mock git repository for testing."""
    git_dir = path / ".git"
    git_dir.mkdir(parents=True, exist_ok=True)
    (git_dir / "HEAD").write_text("ref: refs/heads/main\n")
    (git_dir / "config").write_text("[core]\n\trepositoryformatversion = 0\n")


if __name__ == "__main__":
    pytest.main([__file__, "-v"]) 