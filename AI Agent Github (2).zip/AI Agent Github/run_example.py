#!/usr/bin/env python3
"""
Quick demo script for the LangGraph Repository Setup Agent.

This script demonstrates the agent's capabilities with a small, fast repository.
"""

import asyncio
import os
from pathlib import Path
from repo_agent import RepoSetupAgent


async def main():
    """Run a quick demonstration of the agent."""
    
    print("🚀 LangGraph Repository Setup Agent - Quick Demo")
    print("=" * 60)
    
    # Check if OpenAI API key is available
    if not os.getenv('OPENAI_API_KEY'):
        print("⚠️  Warning: OPENAI_API_KEY not found in environment")
        print("   The agent will work but AI-powered analysis will be limited")
        print("   Set your OpenAI API key: export OPENAI_API_KEY=your_key_here")
        print()
    
    # Configure agent for demo
    config_overrides = {
        'workspace_dir': Path('./demo-workspace'),
        'log_level': 'INFO',
        'max_concurrent_operations': 2,
        'force_environment_creation': False  # Don't recreate if exists
    }
    
    # Initialize agent
    agent = RepoSetupAgent(config_overrides)
    
    # Show agent capabilities
    print("🔧 Agent Configuration:")
    agent_info = agent.get_agent_info()
    print(f"   Workspace: {agent_info['workspace_dir']}")
    print(f"   Supported Languages: {len(agent_info['supported_languages'])}")
    print(f"   Max Concurrent: {agent_info['max_concurrent_operations']}")
    print()
    
    # Demo repositories (small and fast to clone)
    demo_repos = [
        {
            "url": "https://github.com/pallets/click.git",
            "description": "Python CLI library (small, fast)",
            "expected_language": "python"
        },
        {
            "url": "https://github.com/sindresorhus/is.git", 
            "description": "JavaScript utility library (tiny)",
            "expected_language": "javascript"
        }
    ]
    
    print("📦 Demo Repositories:")
    for i, repo in enumerate(demo_repos, 1):
        print(f"   {i}. {repo['description']}")
        print(f"      URL: {repo['url']}")
    print()
    
    # Ask user which demo to run
    try:
        choice = input("Choose demo (1-2, or 'batch' for both, 'info' for repo info only): ").strip().lower()
        
        if choice == 'info':
            # Just get repository information
            print("\n📋 Getting Repository Information...")
            for repo in demo_repos:
                print(f"\n🔍 Analyzing: {repo['url']}")
                try:
                    info = await agent.get_repository_info(repo['url'])
                    print(f"   Name: {info.get('name', 'N/A')}")
                    print(f"   Language: {info.get('language', 'N/A')}")
                    print(f"   Description: {info.get('description', 'N/A')[:100]}...")
                    print(f"   Stars: {info.get('stars', 'N/A')}")
                    print(f"   Size: {info.get('size', 'N/A')} KB")
                except Exception as e:
                    print(f"   ❌ Error: {e}")
        
        elif choice == 'batch':
            # Run batch setup
            print("\n🔄 Running Batch Setup Demo...")
            urls = [repo['url'] for repo in demo_repos]
            
            results = await agent.setup_multiple_repositories(
                repository_urls=urls,
                base_directory=Path('./demo-workspace/batch'),
                max_concurrent=2,
                show_progress=True
            )
            
            print(f"\n📊 Batch Results Summary:")
            successful = sum(1 for r in results if r.success)
            print(f"   ✅ Successful: {successful}/{len(results)}")
            
            for i, result in enumerate(results):
                repo_name = demo_repos[i]['description'].split(' ')[0]
                status = "✅" if result.success else "❌"
                duration = f"{result.total_duration:.1f}s" if result.total_duration else "N/A"
                print(f"   {status} {repo_name}: {duration}")
        
        elif choice in ['1', '2']:
            # Run single repository setup
            repo_index = int(choice) - 1
            selected_repo = demo_repos[repo_index]
            
            print(f"\n🚀 Setting up: {selected_repo['description']}")
            print(f"URL: {selected_repo['url']}")
            
            result = await agent.setup_repository(
                repository_url=selected_repo['url'],
                target_directory=Path(f"./demo-workspace/single-{repo_index + 1}"),
                show_progress=True
            )
            
            if result.success:
                print(f"\n🎉 Demo completed successfully!")
                print(f"📁 Project location: {result.repository.local_path}")
                print(f"🔍 Detected language: {result.detection.language.value}")
                print(f"⏱️  Total time: {result.total_duration:.2f} seconds")
                
                if result.detection.framework_indicators:
                    print(f"🔧 Frameworks: {', '.join(result.detection.framework_indicators)}")
                
                if result.environment:
                    print(f"🐍 Environment: {result.environment.type}")
                
                if result.dependencies:
                    successful_deps = sum(1 for dep in result.dependencies if dep.success)
                    print(f"📦 Dependencies: {successful_deps}/{len(result.dependencies)} installed")
                
                print(f"\n💡 Try exploring the project:")
                print(f"   cd {result.repository.local_path}")
                if result.environment and result.environment.type == "venv":
                    if os.name == 'nt':
                        print(f"   .\\venv\\Scripts\\activate")
                    else:
                        print(f"   source venv/bin/activate")
            
            else:
                print(f"\n❌ Demo failed. Check the logs for details.")
                failed_ops = [op for op in result.operations if op.status.value == "failed"]
                if failed_ops:
                    print(f"Failed operations:")
                    for op in failed_ops:
                        print(f"   - {op.name}: {op.error_message}")
        
        else:
            print("❌ Invalid choice. Please run the script again.")
            return
        
    except KeyboardInterrupt:
        print("\n⏹️ Demo cancelled by user")
        return
    except Exception as e:
        print(f"\n❌ Demo failed with error: {e}")
        return
    
    print("\n" + "=" * 60)
    print("🎉 Demo completed! The agent is ready for production use.")
    print("\n💡 Next steps:")
    print("   1. Set up your OpenAI API key for full AI capabilities")
    print("   2. Try: repo-agent setup <your-repository-url>")
    print("   3. Read the documentation in README.md")
    print("   4. Explore examples in the examples/ directory")


if __name__ == "__main__":
    # Ensure we can import the agent
    try:
        asyncio.run(main())
    except ImportError as e:
        print(f"❌ Import error: {e}")
        print("\n💡 Setup instructions:")
        print("   1. Install dependencies: pip install -r requirements.txt")
        print("   2. Install the package: pip install -e .")
        print("   3. Set your OpenAI API key: export OPENAI_API_KEY=your_key")
        print("   4. Run the demo again: python run_example.py")
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        print("\n🔍 Debug information:")
        import traceback
        traceback.print_exc() 