# 🚀 Azure OpenAI Setup Guide for Repository Setup Agent

This guide will help you configure the LangGraph Repository Setup Agent to use Azure OpenAI instead of standard OpenAI.

## 📋 Prerequisites

- ✅ Azure subscription with access to Azure OpenAI
- ✅ Python 3.8+ installed
- ✅ Repository Setup Agent installed (`pip install -e .`)

## 🔧 Step 1: Create Azure OpenAI Resource

### 1.1 Azure Portal Setup
1. Go to [Azure Portal](https://portal.azure.com)
2. Click **"Create a resource"**
3. Search for **"Azure OpenAI"**
4. Click **"Create"**
5. Fill in the details:
   - **Subscription**: Select your Azure subscription
   - **Resource Group**: Create new or select existing
   - **Region**: Choose a region with OpenAI availability
   - **Name**: Give your resource a unique name
   - **Pricing Tier**: Select appropriate tier

### 1.2 Wait for Deployment
- Deployment typically takes 5-10 minutes
- You'll receive a notification when complete

## 🚀 Step 2: Deploy a Model

### 2.1 Navigate to Model Deployments
1. Go to your Azure OpenAI resource
2. In the left menu, click **"Model deployments"**
3. Click **"Create new deployment"**

### 2.2 Deploy GPT-4 Model
1. **Model**: Select `gpt-4` (or `gpt-35-turbo` if GPT-4 isn't available)
2. **Deployment name**: Enter a name like `gpt-4` (remember this!)
3. **Model version**: Use the latest available
4. **Deployment type**: Standard
5. Click **"Create"**

### 2.3 Note Your Deployment Name
- ⚠️ **Important**: Remember the deployment name you used
- This will be your `AZURE_OPENAI_DEPLOYMENT_NAME`

## 🔑 Step 3: Get Your Credentials

### 3.1 Access Keys and Endpoint
1. In your Azure OpenAI resource, go to **"Keys and Endpoint"**
2. Copy the following information:
   - **KEY 1** → This is your `AZURE_OPENAI_API_KEY`
   - **Endpoint** → This is your `AZURE_OPENAI_ENDPOINT`

## ⚙️ Step 4: Configure Environment Variables

### 4.1 Windows PowerShell
```powershell
$env:AI_PROVIDER="azure"
$env:AZURE_OPENAI_API_KEY="your-api-key-from-step-3"
$env:AZURE_OPENAI_ENDPOINT="https://your-resource.openai.azure.com/"
$env:AZURE_OPENAI_DEPLOYMENT_NAME="gpt-4"
$env:AZURE_OPENAI_API_VERSION="2024-02-15-preview"
```

### 4.2 Linux/Mac Terminal
```bash
export AI_PROVIDER="azure"
export AZURE_OPENAI_API_KEY="your-api-key-from-step-3"
export AZURE_OPENAI_ENDPOINT="https://your-resource.openai.azure.com/"
export AZURE_OPENAI_DEPLOYMENT_NAME="gpt-4"
export AZURE_OPENAI_API_VERSION="2024-02-15-preview"
```

### 4.3 .env File (Recommended)
Create a `.env` file in your project root:

```env
# Azure OpenAI Configuration
AI_PROVIDER=azure
AZURE_OPENAI_API_KEY=your-api-key-here
AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/
AZURE_OPENAI_DEPLOYMENT_NAME=gpt-4
AZURE_OPENAI_API_VERSION=2024-02-15-preview

# Agent Configuration (optional)
WORKSPACE_DIR=./workspace
LOG_LEVEL=INFO
MAX_CONCURRENT_OPERATIONS=3
```

## 🧪 Step 5: Test Your Configuration

### 5.1 Test with Python Script
```bash
python azure_setup_example.py
```

### 5.2 Test with Streamlit UI
```bash
python streamlit_run.py
```
Then:
1. Open browser → `http://localhost:8501`
2. In sidebar, select **"Azure OpenAI"** as AI Provider
3. Fill in your Azure OpenAI credentials
4. Click **"🧪 Test Azure OpenAI Connection"**

## 🚀 Step 6: Use the Agent

### 6.1 CLI Usage
```bash
# Set environment variables first, then:
python -m repo_agent.main setup https://github.com/user/repository
```

### 6.2 Python API Usage
```python
from repo_agent import RepoSetupAgent, AgentConfig

config = AgentConfig(
    ai_provider="azure",
    azure_openai_api_key="your-key",
    azure_openai_endpoint="https://your-resource.openai.azure.com/",
    azure_openai_deployment_name="gpt-4",
    azure_openai_api_version="2024-02-15-preview"
)

agent = RepoSetupAgent(config)
result = await agent.setup_repository("https://github.com/user/repo")
```

### 6.3 Streamlit UI Usage
```bash
python streamlit_run.py
```
- Select "Azure OpenAI" in the sidebar
- Enter your credentials
- Use the interface normally

## 🔍 Troubleshooting

### Common Issues

#### ❌ "Azure OpenAI configuration missing"
**Solution**: Ensure all required environment variables are set:
- `AZURE_OPENAI_API_KEY`
- `AZURE_OPENAI_ENDPOINT`
- `AZURE_OPENAI_DEPLOYMENT_NAME`

#### ❌ "AuthenticationError"
**Solutions**:
1. Verify your API key is correct
2. Check that your Azure subscription is active
3. Ensure your resource has sufficient quota

#### ❌ "DeploymentNotFound"
**Solutions**:
1. Verify your deployment name is correct
2. Check that the model is fully deployed in Azure
3. Ensure the deployment is in "Succeeded" state

#### ❌ "Endpoint not found"
**Solutions**:
1. Verify your endpoint URL is correct
2. Ensure it starts with `https://`
3. Check the endpoint format: `https://your-resource.openai.azure.com/`

#### ❌ "API version not supported"
**Solution**: Try a different API version:
- `2024-02-15-preview` (recommended)
- `2023-12-01-preview`
- `2023-05-15`

### Debug Mode
Enable debug logging to see detailed error messages:

```bash
# Set debug level
export LOG_LEVEL=DEBUG

# Or in .env file
LOG_LEVEL=DEBUG
```

## 📊 Comparison: OpenAI vs Azure OpenAI

| Feature | OpenAI | Azure OpenAI |
|---------|--------|---------------|
| **Setup** | Simple API key | Azure resource + deployment |
| **Security** | API key only | Azure AD + RBAC + Private endpoints |
| **Compliance** | OpenAI policies | Azure compliance (SOC, HIPAA, etc.) |
| **Data** | Shared infrastructure | Dedicated instances |
| **Billing** | Direct OpenAI billing | Azure billing integration |
| **Models** | Latest models first | Stable, enterprise-ready models |

## 🛡️ Security Best Practices

### 1. Environment Variables
- ✅ Use environment variables or `.env` files
- ❌ Never hardcode credentials in source code

### 2. Azure Security
- ✅ Use Azure Key Vault for sensitive data
- ✅ Enable Azure AD authentication
- ✅ Set up private endpoints if needed

### 3. Network Security
- ✅ Use VNet integration for production
- ✅ Configure firewall rules
- ✅ Enable audit logging

## 📈 Performance Tips

### 1. Region Selection
- Choose Azure regions closest to your users
- Consider model availability by region

### 2. Deployment Configuration
- Use appropriate deployment scale settings
- Monitor quota and rate limits

### 3. Agent Configuration
```python
config = AgentConfig(
    ai_provider="azure",
    max_concurrent_operations=3,  # Adjust based on quota
    operation_timeout=300,        # 5 minutes timeout
    # ... other Azure OpenAI settings
)
```

## 🆘 Getting Help

### Azure Support
- [Azure OpenAI Documentation](https://docs.microsoft.com/azure/cognitive-services/openai/)
- [Azure Support Portal](https://portal.azure.com/#blade/Microsoft_Azure_Support/HelpAndSupportBlade)

### Agent Support
- Check the [main README.md](./README.md)
- Run `python azure_setup_example.py` for configuration test
- Use `LOG_LEVEL=DEBUG` for detailed error information

## ✅ Verification Checklist

Before using the agent, verify:

- [ ] Azure OpenAI resource is created and deployed
- [ ] Model is deployed with a known deployment name
- [ ] API key and endpoint are copied correctly
- [ ] Environment variables are set properly
- [ ] Test connection is successful
- [ ] Agent configuration validates without errors

## 🎉 Success!

If everything is configured correctly, you should see:
- ✅ Configuration validation passes
- ✅ Test connection succeeds
- ✅ Agent initializes without errors
- ✅ Repository setup works with Azure OpenAI AI analysis

Now you can use the Repository Setup Agent with Azure OpenAI for enhanced security, compliance, and enterprise features! 🚀 