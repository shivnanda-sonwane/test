#!/usr/bin/env python3
"""
Single Repository Setup Example
Complete example showing how to use the RepoSetupAgent Python API
"""

import asyncio
import os
from pathlib import Path
from repo_agent import RepoSetupAgent, AgentConfig

async def setup_single_repository():
    """Example: Setup a single repository with full configuration"""
    
    # 1. Configure the agent
    config = AgentConfig(
        workspace_directory="./workspace",
        openai_api_key=os.getenv("OPENAI_API_KEY"),
        github_token=os.getenv("GITHUB_TOKEN"),  # Optional
        log_level="INFO",
        create_environment=True,
        install_dependencies=True,
        max_concurrent_operations=3,
        operation_timeout=300,  # 5 minutes
    )
    
    # 2. Initialize the agent
    agent = RepoSetupAgent(config)
    
    # 3. Repository to setup
    repository_url = "https://github.com/fastapi/fastapi"
    target_directory = "fastapi-project"
    
    print(f"🚀 Setting up repository: {repository_url}")
    print(f"📁 Target directory: {target_directory}")
    print("=" * 50)
    
    try:
        # 4. Execute the setup
        result = await agent.setup_repository(
            repository_url=repository_url,
            target_directory=target_directory,
            show_progress=True  # Show rich progress bars
        )
        
        # 5. Display results
        print("\n" + "=" * 50)
        print("📊 SETUP RESULTS")
        print("=" * 50)
        
        print(f"✅ Status: {result.status}")
        print(f"📁 Directory: {result.target_directory}")
        print(f"🏗️ Project Type: {result.detected_language}")
        print(f"⚡ Framework: {result.detected_frameworks}")
        print(f"⏱️ Setup Time: {result.setup_time:.2f}s")
        print(f"📦 Dependencies Installed: {len(result.installed_dependencies)}")
        
        if result.environment_info:
            print(f"🐍 Environment: {result.environment_info.type}")
            print(f"📍 Environment Path: {result.environment_info.path}")
        
        # 6. Show installed dependencies
        if result.installed_dependencies:
            print("\n📦 Installed Dependencies:")
            for dep in result.installed_dependencies[:10]:  # Show first 10
                print(f"  • {dep.name} ({dep.type})")
            
            if len(result.installed_dependencies) > 10:
                print(f"  ... and {len(result.installed_dependencies) - 10} more")
        
        # 7. Show setup operations performed
        print("\n🔧 Operations Performed:")
        for op in result.operations:
            status_icon = "✅" if op.status == "completed" else "❌"
            print(f"  {status_icon} {op.name}: {op.description}")
            if op.duration:
                print(f"     ⏱️ {op.duration:.2f}s")
        
        # 8. Show next steps
        if result.status == "completed":
            print("\n🎉 SETUP COMPLETED SUCCESSFULLY!")
            print("Next steps:")
            print(f"  1. cd {result.target_directory}")
            
            if result.environment_info:
                if result.environment_info.type == "venv":
                    print("  2. Activate environment:")
                    if os.name == 'nt':  # Windows
                        print(f"     {result.environment_info.path}\\Scripts\\activate")
                    else:  # Unix/Linux/macOS
                        print(f"     source {result.environment_info.path}/bin/activate")
                elif result.environment_info.type == "node":
                    print("  2. Node environment ready")
            
            print("  3. Start developing! 🚀")
        else:
            print(f"\n❌ Setup failed: {result.error_message}")
            
    except Exception as e:
        print(f"\n❌ Error during setup: {e}")
        print("💡 Make sure you have:")
        print("  • Valid OpenAI API key")
        print("  • Internet connection")
        print("  • Git installed")
        print("  • Sufficient disk space")

async def get_repository_info_example():
    """Example: Get repository information before setup"""
    
    agent = RepoSetupAgent()
    repository_url = "https://github.com/tensorflow/tensorflow"
    
    print(f"🔍 Analyzing repository: {repository_url}")
    
    try:
        repo_info = await agent.get_repository_info(repository_url)
        
        print("\n📊 REPOSITORY ANALYSIS")
        print("=" * 50)
        print(f"📁 Name: {repo_info.name}")
        print(f"👤 Owner: {repo_info.owner}")
        print(f"📝 Description: {repo_info.description}")
        print(f"🏷️ Language: {repo_info.primary_language}")
        print(f"⭐ Stars: {repo_info.stars:,}")
        print(f"🍴 Forks: {repo_info.forks:,}")
        print(f"📊 Size: {repo_info.size_mb:.1f} MB")
        print(f"🔄 Last Updated: {repo_info.updated_at}")
        print(f"📜 License: {repo_info.license}")
        
        if repo_info.detected_frameworks:
            print(f"🏗️ Detected Frameworks: {', '.join(repo_info.detected_frameworks)}")
        
        print(f"\n💭 Recommended for setup: {'✅ Yes' if repo_info.is_suitable_for_setup else '❌ No'}")
        
    except Exception as e:
        print(f"❌ Error analyzing repository: {e}")

async def main():
    """Main function - choose what to run"""
    
    print("🤖 LangGraph Repository Setup Agent")
    print("=" * 50)
    
    # Check environment
    if not os.getenv("OPENAI_API_KEY"):
        print("⚠️ Warning: OPENAI_API_KEY not set")
        print("Set it with: export OPENAI_API_KEY='your-key-here'")
        print()
    
    while True:
        print("\nChoose an option:")
        print("1. 🚀 Setup a repository")
        print("2. 🔍 Get repository info")
        print("3. 🚪 Exit")
        
        choice = input("\nEnter choice (1-3): ").strip()
        
        if choice == "1":
            await setup_single_repository()
        elif choice == "2":
            await get_repository_info_example()
        elif choice == "3":
            print("👋 Goodbye!")
            break
        else:
            print("❌ Invalid choice. Please enter 1, 2, or 3.")

if __name__ == "__main__":
    # Run the async main function
    asyncio.run(main()) 