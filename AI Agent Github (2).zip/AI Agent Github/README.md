# 🚀 LangGraph Repository Setup Agent

A professional-grade AI agent built with LangGraph that automatically clones any repository from the internet and performs complete project setup including environment creation, dependency installation, and project configuration. This agent saves manual effort and time by intelligently detecting project types and setting up development environments.

## ✨ Features

### 🎯 Core Capabilities
- **Automatic Repository Cloning**: Clone repositories from GitHub, GitLab, Bitbucket, and other Git hosting services
- **Intelligent Project Detection**: AI-powered detection of programming languages and frameworks
- **Environment Management**: Automatic creation of virtual environments for different project types
- **Dependency Installation**: Smart dependency management for multiple package managers
- **Batch Processing**: Set up multiple repositories concurrently with performance optimization
- **Error Recovery**: Robust error handling with retry mechanisms and recovery strategies

### 🔧 Supported Technologies

#### Programming Languages
- **Python** (venv, conda, pip, poetry, pipenv)
- **JavaScript/TypeScript** (npm, yarn, pnpm)
- **Java** (Maven, Gradle)
- **Go** (go modules)
- **Rust** (Cargo)
- **PHP** (Composer)
- **Ruby** (Bundler, Gems)
- **C#/.NET** (NuGet, dotnet)
- **C/C++** (CMake, Make)

#### Frameworks Auto-Detection
- **Python**: Django, Flask, FastAPI, Streamlit, Jupyter
- **JavaScript**: React, Vue, Angular, Express, Next.js
- **TypeScript**: React, Angular, NestJS, Next.js
- **Java**: Spring Boot, Maven, Gradle projects

### 🚄 Performance Features
- **Asynchronous Operations**: Concurrent processing for maximum performance
- **Parallel Dependency Installation**: Install dependencies in parallel when possible
- **Smart Caching**: Cache detection results and avoid redundant operations
- **Progress Tracking**: Real-time progress indicators with rich terminal output
- **Memory Efficient**: Optimized for handling large repositories and batch operations

## 📦 Installation

### Prerequisites
- Python 3.8 or higher
- Git installed and accessible in PATH
- OpenAI API key (for AI-powered analysis)

### Install from Source

```bash
# Clone the repository
git clone <your-repo-url>
cd langgraph-repo-agent

# Install dependencies
pip install -r requirements.txt

# Install in development mode
pip install -e .
```

### Configuration

Create a `.env` file in the project root:

```bash
# Required
OPENAI_API_KEY=your_openai_api_key_here

# Optional
GITHUB_TOKEN=your_github_token_here
WORKSPACE_DIR=./workspace
MAX_CONCURRENT_OPERATIONS=3
LOG_LEVEL=INFO
```

## 🎯 Quick Start

### Basic Usage

```bash
# Set up a single repository
repo-agent setup https://github.com/user/awesome-project.git

# Set up with custom target directory
repo-agent setup https://github.com/user/project.git --target ./my-projects/project

# Get repository information without cloning
repo-agent info https://github.com/user/project.git
```

### Batch Operations

```bash
# Set up multiple repositories
repo-agent batch \
  https://github.com/user/project1.git \
  https://github.com/user/project2.git \
  https://github.com/user/project3.git

# Set up from a file
echo "https://github.com/user/project1.git" > repos.txt
echo "https://github.com/user/project2.git" >> repos.txt
repo-agent batch-file repos.txt --base-dir ./projects
```

## 💻 Programming Interface

### Python API

```python
import asyncio
from pathlib import Path
from repo_agent import RepoSetupAgent

async def main():
    # Initialize the agent
    agent = RepoSetupAgent()
    
    # Set up a single repository
    result = await agent.setup_repository(
        repository_url="https://github.com/user/awesome-project.git",
        target_directory=Path("./my-project")
    )
    
    if result.success:
        print(f"✅ Setup completed!")
        print(f"Language: {result.detection.language}")
        print(f"Frameworks: {result.detection.framework_indicators}")
        print(f"Location: {result.repository.local_path}")
    else:
        print("❌ Setup failed")
        for op in result.failed_operations:
            print(f"Failed: {op.name} - {op.error_message}")

# Run the async function
asyncio.run(main())
```

### Batch Processing

```python
import asyncio
from repo_agent import RepoSetupAgent

async def batch_setup():
    agent = RepoSetupAgent()
    
    repositories = [
        "https://github.com/user/python-project.git",
        "https://github.com/user/nodejs-app.git",
        "https://github.com/user/java-service.git"
    ]
    
    results = await agent.setup_multiple_repositories(
        repository_urls=repositories,
        base_directory=Path("./projects"),
        max_concurrent=3
    )
    
    successful = sum(1 for r in results if r.success)
    print(f"Completed: {successful}/{len(results)} repositories")

asyncio.run(batch_setup())
```

## 🔧 Configuration

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `OPENAI_API_KEY` | OpenAI API key for AI analysis | Required |
| `GITHUB_TOKEN` | GitHub token for private repos | Optional |
| `WORKSPACE_DIR` | Default workspace directory | `./workspace` |
| `MAX_CONCURRENT_OPERATIONS` | Max concurrent operations | `3` |
| `TIMEOUT_MINUTES` | Operation timeout | `30` |
| `LOG_LEVEL` | Logging level | `INFO` |
| `ENABLE_ASYNC_OPERATIONS` | Enable async processing | `true` |
| `PARALLEL_DEPENDENCY_INSTALL` | Parallel dependency installation | `true` |

### Custom Configuration

```python
from repo_agent import RepoSetupAgent

# Override configuration
config_overrides = {
    'workspace_dir': Path('./custom-workspace'),
    'max_concurrent_operations': 5,
    'log_level': 'DEBUG',
    'force_environment_creation': True
}

agent = RepoSetupAgent(config_overrides)
```

## 📊 Command Line Interface

### Available Commands

```bash
# Setup commands
repo-agent setup <repository_url>          # Set up single repository
repo-agent batch <url1> <url2> ...         # Set up multiple repositories
repo-agent batch-file <file>               # Set up from file

# Information commands
repo-agent info <repository_url>           # Get repository information
repo-agent languages                       # List supported languages
repo-agent status                          # Show agent configuration

# Utility commands
repo-agent cleanup                         # Clean workspace
repo-agent examples                        # Show usage examples
```

### Command Options

```bash
# Global options
--workspace, -w          # Custom workspace directory
--log-level             # Set logging level (DEBUG, INFO, WARNING, ERROR)
--config-file           # Use custom configuration file

# Setup options
--target, -t            # Target directory for repository
--no-progress           # Disable progress indicators
--force-env             # Force recreation of environments

# Batch options
--base-dir, -b          # Base directory for all repositories
--max-concurrent, -c    # Maximum concurrent operations
```

## 🏗️ Architecture

### LangGraph Workflow

The agent uses LangGraph to orchestrate a sophisticated workflow:

```mermaid
graph TD
    A[Validate Input] --> B[Clone Repository]
    B --> C[Detect Project Type]
    C --> D[Analyze Requirements]
    D --> E{Environment Needed?}
    E -->|Yes| F[Create Environment]
    E -->|No| G[Install Dependencies]
    F --> G
    G --> H[Configure Project]
    H --> I[Validate Setup]
    I --> J[Finalize]
    
    B -->|Failure| K[Handle Error]
    G -->|Failure| K
    K -->|Retry| B
    K -->|Abort| J
```

### Core Components

1. **Repository Manager**: Handles Git operations and repository cloning
2. **Project Detector**: AI-powered project type and framework detection
3. **Environment Manager**: Creates and manages virtual environments
4. **Dependency Manager**: Installs dependencies using appropriate package managers
5. **Workflow Orchestrator**: LangGraph-based workflow coordination
6. **Configuration System**: Flexible configuration management
7. **Logging System**: Comprehensive logging with performance tracking

## 📈 Performance & Scalability

### Optimization Features

- **Concurrent Operations**: Process multiple repositories simultaneously
- **Async I/O**: Non-blocking operations for better performance
- **Smart Dependency Detection**: Cache detection results to avoid redundant analysis
- **Parallel Installs**: Run dependency installations in parallel when safe
- **Memory Management**: Efficient memory usage for large batch operations

### Performance Metrics

| Operation | Time (avg) | Concurrency |
|-----------|------------|-------------|
| Repository Clone | 5-30s | Limited by network |
| Project Detection | 1-3s | CPU bound |
| Environment Creation | 10-60s | I/O bound |
| Dependency Installation | 30s-10m | Network bound |

## 🛠️ Development

### Project Structure

```
repo_agent/
├── __init__.py           # Package initialization
├── agent.py              # Main agent interface
├── workflow.py           # LangGraph workflow
├── repository.py         # Repository management
├── detector.py           # Project detection
├── environment.py        # Environment management
├── dependency_manager.py # Dependency installation
├── config.py             # Configuration management
├── logger.py             # Logging system
├── models.py             # Data models
└── main.py               # CLI interface
```

### Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature-name`
3. Make your changes with tests
4. Submit a pull request

### Testing

```bash
# Run tests
pytest tests/

# Run with coverage
pytest --cov=repo_agent tests/
```

## 📝 Examples

### Example: Django Project Setup

```bash
repo-agent setup https://github.com/django/django-project.git
```

**What happens:**
1. 🔍 Detects Python/Django project
2. 🐍 Creates Python virtual environment
3. 📦 Installs requirements.txt dependencies
4. ⚙️ Configures Django settings
5. ✅ Ready for development!

### Example: React App Setup

```bash
repo-agent setup https://github.com/facebook/create-react-app.git
```

**What happens:**
1. 🔍 Detects JavaScript/React project
2. 📦 Runs `npm install` or `yarn install`
3. ⚙️ Sets up development environment
4. ✅ Ready for `npm start`!

### Example: Multi-language Batch Setup

```bash
# Create repos.txt
cat > repos.txt << EOF
https://github.com/user/python-ml-project.git
https://github.com/user/react-frontend.git
https://github.com/user/spring-boot-api.git
https://github.com/user/rust-cli-tool.git
EOF

# Set up all projects
repo-agent batch-file repos.txt --base-dir ./projects --max-concurrent 2
```

## 🔒 Security

- **Token Security**: GitHub tokens are handled securely and never logged
- **Sandboxed Execution**: All operations run in isolated environments
- **Input Validation**: Repository URLs are validated before processing
- **Safe Cleanup**: Workspace cleanup with confirmation prompts

## 📚 API Reference

### RepoSetupAgent Class

```python
class RepoSetupAgent:
    def __init__(self, config_overrides: Optional[Dict[str, Any]] = None)
    
    async def setup_repository(
        self,
        repository_url: str,
        target_directory: Optional[Path] = None,
        show_progress: bool = True
    ) -> SetupResult
    
    async def setup_multiple_repositories(
        self,
        repository_urls: List[str],
        base_directory: Optional[Path] = None,
        max_concurrent: Optional[int] = None,
        show_progress: bool = True
    ) -> List[SetupResult]
    
    async def get_repository_info(self, repository_url: str) -> Dict[str, Any]
    
    def get_supported_languages(self) -> List[str]
    
    async def cleanup_workspace(self, keep_successful: bool = True) -> Dict[str, int]
```

### SetupResult Model

```python
class SetupResult:
    repository: RepositoryInfo
    detection: ProjectDetectionResult
    environment: Optional[EnvironmentInfo]
    dependencies: List[DependencyInstallation]
    operations: List[SetupOperation]
    success: bool
    total_duration: float
    created_files: List[str]
```

## 🆘 Troubleshooting

### Common Issues

**Git not found:**
```bash
# Install Git
# Windows: Download from git-scm.com
# macOS: brew install git
# Linux: sudo apt install git
```

**Permission errors:**
```bash
# Fix permissions
chmod +x ./venv/bin/activate
```

**Network timeouts:**
```bash
# Increase timeout
export TIMEOUT_MINUTES=60
repo-agent setup <repository_url>
```

**Memory issues with large repos:**
```bash
# Reduce concurrency
repo-agent batch --max-concurrent 1 <repositories...>
```

### Debug Mode

```bash
# Enable debug logging
repo-agent --log-level DEBUG setup <repository_url>

# Check logs
tail -f agent.log
```

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🤝 Support

- 📧 Email: support@example.com
- 💬 Issues: [GitHub Issues](https://github.com/user/repo/issues)
- 📖 Docs: [Full Documentation](https://docs.example.com)

## 🎉 Acknowledgments

- Built with [LangGraph](https://github.com/langchain-ai/langgraph) for workflow orchestration
- Uses [Rich](https://github.com/Textualize/rich) for beautiful terminal output
- Powered by [OpenAI](https://openai.com) for intelligent project analysis

---

**Made with ❤️ for developers who want to focus on coding, not setup!** 