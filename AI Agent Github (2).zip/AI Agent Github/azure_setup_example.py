#!/usr/bin/env python3
"""
Azure OpenAI Setup Example
Complete example showing how to use the RepoSetupAgent with Azure OpenAI
"""

import asyncio
import os
from pathlib import Path
from repo_agent import RepoSetupAgent, AgentConfig

async def setup_with_azure_openai():
    """Example: Setup repository using Azure OpenAI"""
    
    # Azure OpenAI Configuration
    config = AgentConfig(
        # Azure OpenAI settings
        ai_provider="azure",
        azure_openai_api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        azure_openai_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
        azure_openai_deployment_name=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME"),
        azure_openai_api_version="2024-02-15-preview",
        
        # Agent settings
        workspace_directory="./azure-workspace",
        log_level="INFO",
        create_environment=True,
        install_dependencies=True,
        max_concurrent_operations=3,
        operation_timeout=300,
    )
    
    # Initialize the agent
    agent = RepoSetupAgent(config)
    
    # Repository to setup
    repository_url = "https://github.com/microsoft/semantic-kernel"
    target_directory = "semantic-kernel-project"
    
    print("🚀 Setting up repository with Azure OpenAI")
    print(f"📁 Repository: {repository_url}")
    print(f"🤖 AI Provider: Azure OpenAI")
    print(f"🌐 Endpoint: {config.azure_openai_endpoint}")
    print(f"🚀 Deployment: {config.azure_openai_deployment_name}")
    print("=" * 50)
    
    try:
        # Execute the setup
        result = await agent.setup_repository(
            repository_url=repository_url,
            target_directory=target_directory,
            show_progress=True
        )
        
        # Display results
        print("\n" + "=" * 50)
        print("📊 AZURE OPENAI SETUP RESULTS")
        print("=" * 50)
        
        print(f"✅ Status: {result.status}")
        print(f"📁 Directory: {result.target_directory}")
        print(f"🏗️ Project Type: {result.detected_language}")
        print(f"⚡ Framework: {result.detected_frameworks}")
        print(f"⏱️ Setup Time: {result.setup_time:.2f}s")
        
        if result.status == "completed":
            print("\n🎉 SETUP COMPLETED WITH AZURE OPENAI!")
        else:
            print(f"\n❌ Setup failed: {result.error_message}")
            
    except Exception as e:
        print(f"\n❌ Error during setup: {e}")

def check_azure_configuration():
    """Check if Azure OpenAI configuration is properly set"""
    
    print("🔍 Checking Azure OpenAI Configuration")
    print("=" * 50)
    
    required_vars = {
        'AZURE_OPENAI_API_KEY': os.getenv('AZURE_OPENAI_API_KEY'),
        'AZURE_OPENAI_ENDPOINT': os.getenv('AZURE_OPENAI_ENDPOINT'),
        'AZURE_OPENAI_DEPLOYMENT_NAME': os.getenv('AZURE_OPENAI_DEPLOYMENT_NAME')
    }
    
    missing_vars = []
    for var_name, var_value in required_vars.items():
        if var_value:
            print(f"✅ {var_name}: {'*' * 10}...{var_value[-4:]}")
        else:
            print(f"❌ {var_name}: Not set")
            missing_vars.append(var_name)
    
    if missing_vars:
        print("\n⚠️ Missing environment variables:")
        for var in missing_vars:
            print(f"   export {var}='your-value-here'")
        return False
    else:
        print("\n✅ All Azure OpenAI configuration variables are set!")
        return True

async def main():
    """Main function - Azure OpenAI setup demonstration"""
    
    print("🤖 LangGraph Repository Setup Agent - Azure OpenAI")
    print("=" * 60)
    
    # Check configuration
    if not check_azure_configuration():
        print("\n💡 To set up Azure OpenAI environment variables:")
        print("")
        print("# Windows PowerShell:")
        print("$env:AZURE_OPENAI_API_KEY='your-api-key'")
        print("$env:AZURE_OPENAI_ENDPOINT='https://your-resource.openai.azure.com/'")
        print("$env:AZURE_OPENAI_DEPLOYMENT_NAME='gpt-4'")
        print("")
        print("# Linux/Mac:")
        print("export AZURE_OPENAI_API_KEY='your-api-key'")
        print("export AZURE_OPENAI_ENDPOINT='https://your-resource.openai.azure.com/'")
        print("export AZURE_OPENAI_DEPLOYMENT_NAME='gpt-4'")
        print("")
        print("# .env file:")
        print("AZURE_OPENAI_API_KEY=your-api-key")
        print("AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/")
        print("AZURE_OPENAI_DEPLOYMENT_NAME=gpt-4")
        print("AI_PROVIDER=azure")
        print("")
        return
    
    while True:
        print("\nChoose an option:")
        print("1. 🚀 Setup repository with Azure OpenAI")
        print("2. 🔍 Test Azure OpenAI configuration")
        print("3. 📖 Show Azure setup guide")
        print("4. 🚪 Exit")
        
        choice = input("\nEnter choice (1-4): ").strip()
        
        if choice == "1":
            await setup_with_azure_openai()
        elif choice == "2":
            check_azure_configuration()
        elif choice == "3":
            show_azure_setup_guide()
        elif choice == "4":
            print("👋 Goodbye!")
            break
        else:
            print("❌ Invalid choice. Please enter 1, 2, 3, or 4.")

def show_azure_setup_guide():
    """Show detailed Azure OpenAI setup guide"""
    
    print("\n📖 Azure OpenAI Setup Guide")
    print("=" * 50)
    
    print("\n🔧 Step 1: Create Azure OpenAI Resource")
    print("   1. Go to Azure Portal (portal.azure.com)")
    print("   2. Create a new 'Azure OpenAI' resource")
    print("   3. Choose your subscription, resource group, and region")
    print("   4. Wait for deployment to complete")
    
    print("\n🚀 Step 2: Deploy a Model")
    print("   1. Go to your Azure OpenAI resource")
    print("   2. Navigate to 'Model deployments'")
    print("   3. Click 'Create new deployment'")
    print("   4. Choose a model (e.g., gpt-4)")
    print("   5. Give it a deployment name (e.g., 'gpt-4')")
    print("   6. Deploy the model")
    
    print("\n🔑 Step 3: Get Your Configuration")
    print("   1. Go to 'Keys and Endpoint'")
    print("   2. Copy 'KEY 1' → This is your AZURE_OPENAI_API_KEY")
    print("   3. Copy 'Endpoint' → This is your AZURE_OPENAI_ENDPOINT")
    print("   4. Your deployment name → This is your AZURE_OPENAI_DEPLOYMENT_NAME")
    
    print("\n⚙️ Step 4: Set Environment Variables")
    print("   For Windows PowerShell:")
    print("   $env:AZURE_OPENAI_API_KEY='your-key-from-step-3'")
    print("   $env:AZURE_OPENAI_ENDPOINT='your-endpoint-from-step-3'")
    print("   $env:AZURE_OPENAI_DEPLOYMENT_NAME='your-deployment-name'")
    print("   $env:AI_PROVIDER='azure'")
    
    print("\n   For Linux/Mac:")
    print("   export AZURE_OPENAI_API_KEY='your-key-from-step-3'")
    print("   export AZURE_OPENAI_ENDPOINT='your-endpoint-from-step-3'")
    print("   export AZURE_OPENAI_DEPLOYMENT_NAME='your-deployment-name'")
    print("   export AI_PROVIDER='azure'")
    
    print("\n📄 Step 5: Create .env File (Optional)")
    print("   Create a .env file in your project root:")
    print("   ```")
    print("   AI_PROVIDER=azure")
    print("   AZURE_OPENAI_API_KEY=your-key-here")
    print("   AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/")
    print("   AZURE_OPENAI_DEPLOYMENT_NAME=gpt-4")
    print("   AZURE_OPENAI_API_VERSION=2024-02-15-preview")
    print("   ```")
    
    print("\n🚀 Step 6: Run the Agent")
    print("   python azure_setup_example.py")
    print("   # Or use the Streamlit UI:")
    print("   python streamlit_run.py")

if __name__ == "__main__":
    # Run the async main function
    asyncio.run(main()) 