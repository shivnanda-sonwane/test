"""
Repository cloning and management functionality.
"""

import os
import shutil
import asyncio
import aiohttp
import subprocess
from pathlib import Path
from typing import Optional, Tuple
from urllib.parse import urlparse
import git
from git import Repo, GitCommandError

from .config import config
from .logger import agent_logger, performance_monitor
from .models import RepositoryInfo, ProjectLanguage


class RepositoryManager:
    """Manages repository cloning and basic operations."""
    
    def __init__(self):
        self.workspace_dir = config.workspace_dir
        self.github_token = config.github_token
    
    @performance_monitor("repository_clone")
    async def clone_repository(self, repo_url: str, target_dir: Optional[Path] = None) -> RepositoryInfo:
        """
        Clone a repository from the given URL.
        
        Args:
            repo_url: The repository URL to clone
            target_dir: Optional target directory (auto-generated if not provided)
            
        Returns:
            RepositoryInfo with cloning results
        """
        agent_logger.info(f"Starting repository clone: {repo_url}")
        
        # Validate URL
        if not self._is_valid_repo_url(repo_url):
            raise ValueError(f"Invalid repository URL: {repo_url}")
        
        # Generate target directory if not provided
        if target_dir is None:
            target_dir = self._generate_target_dir(repo_url)
        
        # Ensure parent directory exists
        target_dir.parent.mkdir(parents=True, exist_ok=True)
        
        # Remove existing directory if it exists
        if target_dir.exists():
            agent_logger.warning(f"Target directory already exists, removing: {target_dir}")
            shutil.rmtree(target_dir)
        
        repo_info = RepositoryInfo(
            url=repo_url,
            local_path=target_dir,
            clone_success=False
        )
        
        try:
            # Clone the repository
            start_time = asyncio.get_event_loop().time()
            
            # Use git command for better performance and control
            clone_env = os.environ.copy()
            if self.github_token and "github.com" in repo_url:
                # Add authentication for private repos
                auth_url = self._add_auth_to_url(repo_url)
                clone_env["GIT_ASKPASS"] = "echo"
                clone_env["GIT_USERNAME"] = "token"
                clone_env["GIT_PASSWORD"] = self.github_token
            else:
                auth_url = repo_url
            
            # Clone repository with depth 1 for performance
            clone_command = [
                "git", "clone", 
                "--depth", "1",
                "--recurse-submodules", "--shallow-submodules",
                auth_url, str(target_dir)
            ]
            
            process = await asyncio.create_subprocess_exec(
                *clone_command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=clone_env
            )
            
            stdout, stderr = await process.communicate()
            
            if process.returncode != 0:
                error_msg = stderr.decode() if stderr else "Unknown clone error"
                raise GitCommandError(clone_command, process.returncode, stderr=error_msg)
            
            clone_time = asyncio.get_event_loop().time() - start_time
            repo_info.clone_time = clone_time
            repo_info.clone_success = True
            
            # Get additional repository information
            repo = Repo(target_dir)
            repo_info.branch = repo.active_branch.name
            repo_info.commit_hash = repo.head.object.hexsha
            
            # Calculate repository size
            repo_info.size_mb = self._calculate_directory_size(target_dir)
            
            agent_logger.success(
                f"Successfully cloned repository: {repo_url}",
                repo_url=repo_url,
                target_dir=str(target_dir),
                clone_time=clone_time,
                size_mb=repo_info.size_mb
            )
            
            return repo_info
            
        except Exception as e:
            agent_logger.error(
                f"Failed to clone repository: {repo_url}",
                repo_url=repo_url,
                target_dir=str(target_dir),
                error=str(e)
            )
            raise
    
    def _is_valid_repo_url(self, url: str) -> bool:
        """Validate if the URL is a valid repository URL."""
        try:
            parsed = urlparse(url)
            
            # Check for common git hosting services
            valid_hosts = [
                "github.com", "gitlab.com", "bitbucket.org",
                "codeberg.org", "sourceforge.net"
            ]
            
            # Check for HTTPS or SSH URLs
            if parsed.scheme in ["https", "http"]:
                return any(host in parsed.netloc for host in valid_hosts)
            elif parsed.scheme == "git" or url.startswith("git@"):
                return True
            elif url.endswith(".git"):
                return True
            
            return False
        except Exception:
            return False
    
    def _generate_target_dir(self, repo_url: str) -> Path:
        """Generate a target directory name from the repository URL."""
        parsed = urlparse(repo_url)
        
        if parsed.path:
            # Extract repository name from path
            repo_name = Path(parsed.path).stem
            if repo_name.endswith(".git"):
                repo_name = repo_name[:-4]
        else:
            # Fallback to netloc if no path
            repo_name = parsed.netloc.replace(".", "_")
        
        # Ensure unique directory name
        base_dir = self.workspace_dir / repo_name
        counter = 1
        target_dir = base_dir
        
        while target_dir.exists():
            target_dir = self.workspace_dir / f"{repo_name}_{counter}"
            counter += 1
        
        return target_dir
    
    def _add_auth_to_url(self, url: str) -> str:
        """Add authentication token to GitHub URL."""
        if not self.github_token:
            return url
        
        parsed = urlparse(url)
        if "github.com" in parsed.netloc:
            # Convert to authenticated URL
            auth_url = f"https://{self.github_token}@{parsed.netloc}{parsed.path}"
            return auth_url
        
        return url
    
    def _calculate_directory_size(self, directory: Path) -> float:
        """Calculate directory size in MB."""
        try:
            total_size = 0
            for dirpath, dirnames, filenames in os.walk(directory):
                for filename in filenames:
                    filepath = os.path.join(dirpath, filename)
                    if os.path.exists(filepath):
                        total_size += os.path.getsize(filepath)
            return round(total_size / (1024 * 1024), 2)  # Convert to MB
        except Exception as e:
            agent_logger.warning(f"Could not calculate directory size: {e}")
            return 0.0
    
    @performance_monitor("repository_validation")
    async def validate_repository(self, repo_path: Path) -> bool:
        """
        Validate that the cloned repository is valid.
        
        Args:
            repo_path: Path to the repository
            
        Returns:
            True if repository is valid
        """
        try:
            if not repo_path.exists():
                return False
            
            # Check if it's a git repository
            git_dir = repo_path / ".git"
            if not git_dir.exists():
                return False
            
            # Try to create a Repo object
            repo = Repo(repo_path)
            
            # Check if we can access basic information
            _ = repo.head.object.hexsha
            
            agent_logger.debug(f"Repository validation successful: {repo_path}")
            return True
            
        except Exception as e:
            agent_logger.error(f"Repository validation failed: {repo_path} - {e}")
            return False
    
    @performance_monitor("repository_cleanup")
    async def cleanup_repository(self, repo_path: Path) -> bool:
        """
        Clean up a repository directory.
        
        Args:
            repo_path: Path to the repository to clean up
            
        Returns:
            True if cleanup was successful
        """
        try:
            if repo_path.exists():
                shutil.rmtree(repo_path)
                agent_logger.info(f"Cleaned up repository: {repo_path}")
                return True
            return True
        except Exception as e:
            agent_logger.error(f"Failed to cleanup repository: {repo_path} - {e}")
            return False
    
    async def get_remote_info(self, repo_url: str) -> dict:
        """
        Get information about a remote repository without cloning.
        
        Args:
            repo_url: The repository URL
            
        Returns:
            Dictionary with repository information
        """
        try:
            # For GitHub repositories, use the API
            if "github.com" in repo_url:
                return await self._get_github_info(repo_url)
            
            # For other repositories, try to get basic info
            return {"url": repo_url, "type": "unknown"}
            
        except Exception as e:
            agent_logger.warning(f"Could not get remote info for {repo_url}: {e}")
            return {"url": repo_url, "type": "unknown", "error": str(e)}
    
    async def _get_github_info(self, repo_url: str) -> dict:
        """Get GitHub repository information via API."""
        try:
            # Extract owner and repo from URL
            parsed = urlparse(repo_url)
            path_parts = parsed.path.strip("/").split("/")
            
            if len(path_parts) >= 2:
                owner, repo = path_parts[0], path_parts[1]
                if repo.endswith(".git"):
                    repo = repo[:-4]
                
                # GitHub API URL
                api_url = f"https://api.github.com/repos/{owner}/{repo}"
                
                headers = {}
                if self.github_token:
                    headers["Authorization"] = f"token {self.github_token}"
                
                async with aiohttp.ClientSession() as session:
                    async with session.get(api_url, headers=headers) as response:
                        if response.status == 200:
                            data = await response.json()
                            return {
                                "url": repo_url,
                                "name": data.get("name"),
                                "description": data.get("description"),
                                "language": data.get("language"),
                                "stars": data.get("stargazers_count"),
                                "forks": data.get("forks_count"),
                                "size": data.get("size"),
                                "default_branch": data.get("default_branch"),
                                "type": "github"
                            }
            
            return {"url": repo_url, "type": "github", "error": "Invalid GitHub URL"}
            
        except Exception as e:
            return {"url": repo_url, "type": "github", "error": str(e)} 