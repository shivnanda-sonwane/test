"""
Command Line Interface for the Repository Setup Agent.
"""

import asyncio
import sys
from pathlib import Path
from typing import Optional, List

import click
from rich.console import Console

from .agent import RepoSetupAgent
from .config import config
from .logger import agent_logger


console = Console()


@click.group()
@click.version_option(version="1.0.0")
@click.option('--workspace', '-w', type=click.Path(), help='Workspace directory')
@click.option('--log-level', type=click.Choice(['DEBUG', 'INFO', 'WARNING', 'ERROR']), help='Log level')
@click.option('--config-file', type=click.Path(exists=True), help='Configuration file path')
@click.pass_context
def cli(ctx, workspace, log_level, config_file):
    """
    🚀 Repository Setup Agent
    
    Automatically clone, detect, and set up development environments for any repository.
    """
    ctx.ensure_object(dict)
    
    # Apply configuration overrides
    config_overrides = {}
    if workspace:
        config_overrides['workspace_dir'] = Path(workspace)
    if log_level:
        config_overrides['log_level'] = log_level
    
    ctx.obj['config_overrides'] = config_overrides


@cli.command()
@click.argument('repository_url')
@click.option('--target', '-t', type=click.Path(), help='Target directory for the repository')
@click.option('--no-progress', is_flag=True, help='Disable progress indicators')
@click.option('--force-env', is_flag=True, help='Force recreation of existing environments')
@click.pass_context
def setup(ctx, repository_url, target, no_progress, force_env):
    """
    Set up a single repository with automatic detection and configuration.
    
    REPOSITORY_URL: URL of the repository to clone and setup
    """
    config_overrides = ctx.obj.get('config_overrides', {})
    if force_env:
        config_overrides['force_environment_creation'] = True
    
    async def run_setup():
        agent = RepoSetupAgent(config_overrides)
        
        target_path = Path(target) if target else None
        
        try:
            result = await agent.setup_repository(
                repository_url=repository_url,
                target_directory=target_path,
                show_progress=not no_progress
            )
            
            if result.success:
                console.print(f"✅ Repository setup completed successfully!")
                console.print(f"📁 Location: {result.repository.local_path}")
                sys.exit(0)
            else:
                console.print(f"❌ Repository setup completed with errors.")
                console.print(f"📄 Check logs for details: {config.log_file}")
                sys.exit(1)
                
        except Exception as e:
            console.print(f"❌ Setup failed: {e}")
            agent_logger.error(f"CLI setup failed: {e}")
            sys.exit(1)
    
    asyncio.run(run_setup())


@cli.command()
@click.argument('repository_urls', nargs=-1, required=True)
@click.option('--base-dir', '-b', type=click.Path(), help='Base directory for all repositories')
@click.option('--max-concurrent', '-c', type=int, help='Maximum concurrent operations')
@click.option('--no-progress', is_flag=True, help='Disable progress indicators')
@click.pass_context
def batch(ctx, repository_urls, base_dir, max_concurrent, no_progress):
    """
    Set up multiple repositories concurrently.
    
    REPOSITORY_URLS: Space-separated list of repository URLs
    """
    config_overrides = ctx.obj.get('config_overrides', {})
    if max_concurrent:
        config_overrides['max_concurrent_operations'] = max_concurrent
    
    async def run_batch():
        agent = RepoSetupAgent(config_overrides)
        
        base_path = Path(base_dir) if base_dir else None
        
        try:
            results = await agent.setup_multiple_repositories(
                repository_urls=list(repository_urls),
                base_directory=base_path,
                max_concurrent=max_concurrent,
                show_progress=not no_progress
            )
            
            successful = sum(1 for r in results if r.success)
            total = len(results)
            
            if successful == total:
                console.print(f"✅ All {total} repositories set up successfully!")
                sys.exit(0)
            elif successful > 0:
                console.print(f"⚠️ {successful}/{total} repositories set up successfully.")
                sys.exit(1)
            else:
                console.print(f"❌ All {total} repositories failed to set up.")
                sys.exit(1)
                
        except Exception as e:
            console.print(f"❌ Batch setup failed: {e}")
            agent_logger.error(f"CLI batch setup failed: {e}")
            sys.exit(1)
    
    asyncio.run(run_batch())


@cli.command()
@click.argument('repository_url')
@click.pass_context
def info(ctx, repository_url):
    """
    Get information about a repository without cloning it.
    
    REPOSITORY_URL: URL of the repository to analyze
    """
    config_overrides = ctx.obj.get('config_overrides', {})
    
    async def get_info():
        agent = RepoSetupAgent(config_overrides)
        
        try:
            repo_info = await agent.get_repository_info(repository_url)
            
            console.print(f"📂 Repository Information")
            console.print(f"━━━━━━━━━━━━━━━━━━━━━━━━")
            
            for key, value in repo_info.items():
                if key != 'error':
                    console.print(f"{key.replace('_', ' ').title()}: {value}")
            
            if 'error' in repo_info:
                console.print(f"❌ Error: {repo_info['error']}")
                sys.exit(1)
            
        except Exception as e:
            console.print(f"❌ Failed to get repository info: {e}")
            sys.exit(1)
    
    asyncio.run(get_info())


@cli.command()
@click.pass_context
def languages(ctx):
    """List all supported programming languages."""
    config_overrides = ctx.obj.get('config_overrides', {})
    agent = RepoSetupAgent(config_overrides)
    
    supported_langs = agent.get_supported_languages()
    
    console.print("📋 Supported Programming Languages")
    console.print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    
    for i, lang in enumerate(supported_langs, 1):
        console.print(f"{i:2d}. {lang.title()}")
    
    console.print(f"\nTotal: {len(supported_langs)} languages supported")


@cli.command()
@click.pass_context
def status(ctx):
    """Show agent configuration and status."""
    config_overrides = ctx.obj.get('config_overrides', {})
    agent = RepoSetupAgent(config_overrides)
    
    agent_info = agent.get_agent_info()
    
    console.print("⚙️ Agent Configuration")
    console.print("━━━━━━━━━━━━━━━━━━━━━━━")
    
    for key, value in agent_info.items():
        if isinstance(value, list):
            console.print(f"{key.replace('_', ' ').title()}: {len(value)} items")
        else:
            console.print(f"{key.replace('_', ' ').title()}: {value}")


@cli.command()
@click.option('--keep-successful', is_flag=True, default=True, help='Keep successfully set up repositories')
@click.confirmation_option(prompt='Are you sure you want to cleanup the workspace?')
@click.pass_context
def cleanup(ctx, keep_successful):
    """Clean up the workspace directory."""
    config_overrides = ctx.obj.get('config_overrides', {})
    
    async def run_cleanup():
        agent = RepoSetupAgent(config_overrides)
        
        try:
            stats = await agent.cleanup_workspace(keep_successful=keep_successful)
            
            console.print("🧹 Workspace Cleanup Complete")
            console.print("━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            console.print(f"Cleaned: {stats['cleaned']} directories")
            console.print(f"Kept: {stats['kept']} directories")
            
            if stats['errors'] > 0:
                console.print(f"Errors: {stats['errors']} directories")
                sys.exit(1)
            
        except Exception as e:
            console.print(f"❌ Cleanup failed: {e}")
            sys.exit(1)
    
    asyncio.run(run_cleanup())


@cli.command()
@click.argument('repository_urls_file', type=click.File('r'))
@click.option('--base-dir', '-b', type=click.Path(), help='Base directory for all repositories')
@click.option('--max-concurrent', '-c', type=int, help='Maximum concurrent operations')
@click.option('--no-progress', is_flag=True, help='Disable progress indicators')
@click.pass_context
def batch_file(ctx, repository_urls_file, base_dir, max_concurrent, no_progress):
    """
    Set up multiple repositories from a file.
    
    REPOSITORY_URLS_FILE: File containing repository URLs (one per line)
    """
    # Read URLs from file
    urls = []
    for line in repository_urls_file:
        line = line.strip()
        if line and not line.startswith('#'):
            urls.append(line)
    
    if not urls:
        console.print("❌ No repository URLs found in file")
        sys.exit(1)
    
    console.print(f"📄 Found {len(urls)} repositories in file")
    
    config_overrides = ctx.obj.get('config_overrides', {})
    if max_concurrent:
        config_overrides['max_concurrent_operations'] = max_concurrent
    
    async def run_batch():
        agent = RepoSetupAgent(config_overrides)
        
        base_path = Path(base_dir) if base_dir else None
        
        try:
            results = await agent.setup_multiple_repositories(
                repository_urls=urls,
                base_directory=base_path,
                max_concurrent=max_concurrent,
                show_progress=not no_progress
            )
            
            successful = sum(1 for r in results if r.success)
            total = len(results)
            
            if successful == total:
                console.print(f"✅ All {total} repositories set up successfully!")
                sys.exit(0)
            elif successful > 0:
                console.print(f"⚠️ {successful}/{total} repositories set up successfully.")
                sys.exit(1)
            else:
                console.print(f"❌ All {total} repositories failed to set up.")
                sys.exit(1)
                
        except Exception as e:
            console.print(f"❌ Batch setup failed: {e}")
            agent_logger.error(f"CLI batch setup failed: {e}")
            sys.exit(1)
    
    asyncio.run(run_batch())


@cli.command()
@click.pass_context
def examples(ctx):
    """Show usage examples."""
    console.print("""
🚀 Repository Setup Agent - Usage Examples
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📦 Basic Setup:
   repo-agent setup https://github.com/user/repo.git
   
📁 Custom Target Directory:
   repo-agent setup https://github.com/user/repo.git --target ./my-projects/repo
   
🔄 Batch Setup:
   repo-agent batch https://github.com/user/repo1.git https://github.com/user/repo2.git
   
📄 Batch from File:
   repo-agent batch-file repos.txt --base-dir ./projects
   
📋 Repository Info:
   repo-agent info https://github.com/user/repo.git
   
⚙️ Custom Configuration:
   repo-agent --workspace ./my-workspace --log-level DEBUG setup https://github.com/user/repo.git
   
🧹 Cleanup Workspace:
   repo-agent cleanup --keep-successful
   
📚 Show Supported Languages:
   repo-agent languages
   
📊 Show Agent Status:
   repo-agent status

📝 Example repos.txt file:
   https://github.com/user/python-project.git
   https://github.com/user/nodejs-app.git
   # This is a comment
   https://github.com/user/java-service.git
""")


def main():
    """Main entry point for the CLI."""
    try:
        cli()
    except KeyboardInterrupt:
        console.print("\n⏹️ Operation cancelled by user")
        sys.exit(130)
    except Exception as e:
        console.print(f"❌ Unexpected error: {e}")
        agent_logger.error(f"CLI unexpected error: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main() 