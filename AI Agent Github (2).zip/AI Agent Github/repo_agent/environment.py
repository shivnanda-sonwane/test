"""
Environment management for different project types.
"""

import os
import sys
import shutil
import asyncio
import subprocess
from pathlib import Path
from typing import Optional, Dict, List, Tuple
import platform

from .config import config
from .logger import agent_logger, performance_monitor
from .models import EnvironmentInfo, ProjectLanguage, ProjectDetectionResult


class EnvironmentManager:
    """Manages virtual environments for different project types."""
    
    def __init__(self):
        self.workspace_dir = config.workspace_dir
        self.system_info = self._get_system_info()
    
    def _get_system_info(self) -> Dict[str, str]:
        """Get system information for environment setup."""
        return {
            "platform": platform.system().lower(),
            "architecture": platform.machine(),
            "python_version": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
            "python_executable": sys.executable
        }
    
    @performance_monitor("environment_creation")
    async def create_environment(
        self, 
        project_path: Path, 
        detection: ProjectDetectionResult,
        force: bool = False
    ) -> Optional[EnvironmentInfo]:
        """
        Create appropriate environment for the detected project type.
        
        Args:
            project_path: Path to the project
            detection: Project detection results
            force: Force recreation of existing environment
            
        Returns:
            EnvironmentInfo if environment was created, None if not needed
        """
        language = detection.language
        
        agent_logger.info(f"Creating environment for {language.value} project at {project_path}")
        
        # Check if environment is needed for this language
        if not self._environment_needed(language):
            agent_logger.info(f"No environment needed for {language.value}")
            return None
        
        # Create environment based on language
        if language == ProjectLanguage.PYTHON:
            return await self._create_python_environment(project_path, detection, force)
        elif language in [ProjectLanguage.JAVASCRIPT, ProjectLanguage.TYPESCRIPT]:
            return await self._create_node_environment(project_path, detection, force)
        elif language == ProjectLanguage.JAVA:
            return await self._setup_java_environment(project_path, detection)
        elif language == ProjectLanguage.GO:
            return await self._setup_go_environment(project_path, detection)
        elif language == ProjectLanguage.RUST:
            return await self._setup_rust_environment(project_path, detection)
        elif language == ProjectLanguage.PHP:
            return await self._setup_php_environment(project_path, detection)
        elif language == ProjectLanguage.RUBY:
            return await self._setup_ruby_environment(project_path, detection)
        elif language == ProjectLanguage.CSHARP:
            return await self._setup_dotnet_environment(project_path, detection)
        else:
            agent_logger.warning(f"Environment creation not implemented for {language.value}")
            return None
    
    def _environment_needed(self, language: ProjectLanguage) -> bool:
        """Check if environment creation is needed for the language."""
        environments_needed = {
            ProjectLanguage.PYTHON: True,
            ProjectLanguage.JAVASCRIPT: True,
            ProjectLanguage.TYPESCRIPT: True,
            ProjectLanguage.JAVA: True,
            ProjectLanguage.GO: False,  # Go manages dependencies differently
            ProjectLanguage.RUST: False,  # Cargo manages dependencies
            ProjectLanguage.PHP: True,
            ProjectLanguage.RUBY: True,
            ProjectLanguage.CSHARP: True,
        }
        return environments_needed.get(language, False)
    
    async def _create_python_environment(
        self, 
        project_path: Path, 
        detection: ProjectDetectionResult,
        force: bool = False
    ) -> EnvironmentInfo:
        """Create Python virtual environment."""
        env_path = project_path / "venv"
        
        # Check if environment already exists
        if env_path.exists() and not force:
            if config.skip_existing_environments:
                agent_logger.info(f"Python environment already exists at {env_path}")
                return EnvironmentInfo(
                    type="venv",
                    path=env_path,
                    created=False,
                    activated=False,
                    python_version=self.system_info["python_version"]
                )
            else:
                agent_logger.info(f"Removing existing environment at {env_path}")
                shutil.rmtree(env_path)
        
        agent_logger.log_environment_creation("Python venv", env_path)
        
        try:
            # Create virtual environment
            create_command = [
                sys.executable, "-m", "venv", 
                str(env_path), "--upgrade-deps"
            ]
            
            process = await asyncio.create_subprocess_exec(
                *create_command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=project_path
            )
            
            stdout, stderr = await process.communicate()
            
            if process.returncode != 0:
                error_msg = stderr.decode() if stderr else "Unknown error"
                raise RuntimeError(f"Failed to create Python virtual environment: {error_msg}")
            
            # Verify environment creation
            python_exe = self._get_python_executable(env_path)
            if not python_exe.exists():
                raise RuntimeError("Python executable not found in created environment")
            
            # Get Python version in the environment
            version_command = [str(python_exe), "--version"]
            version_process = await asyncio.create_subprocess_exec(
                *version_command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            version_stdout, _ = await version_process.communicate()
            python_version = version_stdout.decode().strip().split()[-1]
            
            env_info = EnvironmentInfo(
                type="venv",
                path=env_path,
                created=True,
                activated=False,
                python_version=python_version
            )
            
            agent_logger.success(
                f"Created Python virtual environment at {env_path}",
                env_path=str(env_path),
                python_version=python_version
            )
            
            return env_info
            
        except Exception as e:
            agent_logger.error(f"Failed to create Python environment: {e}")
            raise
    
    async def _create_node_environment(
        self, 
        project_path: Path, 
        detection: ProjectDetectionResult,
        force: bool = False
    ) -> EnvironmentInfo:
        """Create Node.js environment (check Node.js installation and setup)."""
        
        # Check if Node.js is installed
        node_version = await self._get_node_version()
        if not node_version:
            raise RuntimeError("Node.js is not installed or not in PATH")
        
        # Check for package.json
        package_json_path = project_path / "package.json"
        if not package_json_path.exists():
            agent_logger.warning("No package.json found, Node.js environment setup may be incomplete")
        
        # Node.js doesn't require virtual environments like Python,
        # but we can verify npm/yarn installation
        npm_version = await self._get_npm_version()
        yarn_version = await self._get_yarn_version()
        
        env_info = EnvironmentInfo(
            type="node",
            path=project_path,
            created=True,
            activated=True,  # Node environments are always "active"
            node_version=node_version
        )
        
        agent_logger.success(
            f"Node.js environment ready",
            node_version=node_version,
            npm_version=npm_version,
            yarn_version=yarn_version
        )
        
        return env_info
    
    async def _setup_java_environment(
        self, 
        project_path: Path, 
        detection: ProjectDetectionResult
    ) -> EnvironmentInfo:
        """Setup Java environment."""
        
        # Check for Java installation
        java_version = await self._get_java_version()
        if not java_version:
            raise RuntimeError("Java is not installed or not in PATH")
        
        # Check for Maven or Gradle
        maven_version = await self._get_maven_version()
        gradle_version = await self._get_gradle_version()
        
        if not maven_version and not gradle_version:
            agent_logger.warning("Neither Maven nor Gradle found. Manual dependency management may be required.")
        
        env_info = EnvironmentInfo(
            type="java",
            path=project_path,
            created=True,
            activated=True
        )
        
        agent_logger.success(
            f"Java environment ready",
            java_version=java_version,
            maven_version=maven_version,
            gradle_version=gradle_version
        )
        
        return env_info
    
    async def _setup_go_environment(
        self, 
        project_path: Path, 
        detection: ProjectDetectionResult
    ) -> EnvironmentInfo:
        """Setup Go environment."""
        
        go_version = await self._get_go_version()
        if not go_version:
            raise RuntimeError("Go is not installed or not in PATH")
        
        env_info = EnvironmentInfo(
            type="go",
            path=project_path,
            created=True,
            activated=True
        )
        
        agent_logger.success(f"Go environment ready", go_version=go_version)
        return env_info
    
    async def _setup_rust_environment(
        self, 
        project_path: Path, 
        detection: ProjectDetectionResult
    ) -> EnvironmentInfo:
        """Setup Rust environment."""
        
        rust_version = await self._get_rust_version()
        if not rust_version:
            raise RuntimeError("Rust is not installed or not in PATH")
        
        cargo_version = await self._get_cargo_version()
        
        env_info = EnvironmentInfo(
            type="rust",
            path=project_path,
            created=True,
            activated=True
        )
        
        agent_logger.success(
            f"Rust environment ready",
            rust_version=rust_version,
            cargo_version=cargo_version
        )
        return env_info
    
    async def _setup_php_environment(
        self, 
        project_path: Path, 
        detection: ProjectDetectionResult
    ) -> EnvironmentInfo:
        """Setup PHP environment."""
        
        php_version = await self._get_php_version()
        if not php_version:
            raise RuntimeError("PHP is not installed or not in PATH")
        
        composer_version = await self._get_composer_version()
        
        env_info = EnvironmentInfo(
            type="php",
            path=project_path,
            created=True,
            activated=True
        )
        
        agent_logger.success(
            f"PHP environment ready",
            php_version=php_version,
            composer_version=composer_version
        )
        return env_info
    
    async def _setup_ruby_environment(
        self, 
        project_path: Path, 
        detection: ProjectDetectionResult
    ) -> EnvironmentInfo:
        """Setup Ruby environment."""
        
        ruby_version = await self._get_ruby_version()
        if not ruby_version:
            raise RuntimeError("Ruby is not installed or not in PATH")
        
        gem_version = await self._get_gem_version()
        bundler_version = await self._get_bundler_version()
        
        env_info = EnvironmentInfo(
            type="ruby",
            path=project_path,
            created=True,
            activated=True
        )
        
        agent_logger.success(
            f"Ruby environment ready",
            ruby_version=ruby_version,
            gem_version=gem_version,
            bundler_version=bundler_version
        )
        return env_info
    
    async def _setup_dotnet_environment(
        self, 
        project_path: Path, 
        detection: ProjectDetectionResult
    ) -> EnvironmentInfo:
        """Setup .NET environment."""
        
        dotnet_version = await self._get_dotnet_version()
        if not dotnet_version:
            raise RuntimeError(".NET is not installed or not in PATH")
        
        env_info = EnvironmentInfo(
            type="dotnet",
            path=project_path,
            created=True,
            activated=True
        )
        
        agent_logger.success(f".NET environment ready", dotnet_version=dotnet_version)
        return env_info
    
    # Utility methods for getting tool versions
    async def _get_version(self, command: List[str]) -> Optional[str]:
        """Generic method to get version of a tool."""
        try:
            process = await asyncio.create_subprocess_exec(
                *command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await process.communicate()
            
            if process.returncode == 0:
                output = stdout.decode().strip()
                # Extract version number from output
                import re
                version_match = re.search(r'(\d+\.\d+\.\d+)', output)
                return version_match.group(1) if version_match else output.split()[0]
            return None
        except (FileNotFoundError, OSError):
            return None
    
    async def _get_python_version(self) -> Optional[str]:
        return await self._get_version([sys.executable, "--version"])
    
    async def _get_node_version(self) -> Optional[str]:
        return await self._get_version(["node", "--version"])
    
    async def _get_npm_version(self) -> Optional[str]:
        return await self._get_version(["npm", "--version"])
    
    async def _get_yarn_version(self) -> Optional[str]:
        return await self._get_version(["yarn", "--version"])
    
    async def _get_java_version(self) -> Optional[str]:
        return await self._get_version(["java", "-version"])
    
    async def _get_maven_version(self) -> Optional[str]:
        return await self._get_version(["mvn", "--version"])
    
    async def _get_gradle_version(self) -> Optional[str]:
        return await self._get_version(["gradle", "--version"])
    
    async def _get_go_version(self) -> Optional[str]:
        return await self._get_version(["go", "version"])
    
    async def _get_rust_version(self) -> Optional[str]:
        return await self._get_version(["rustc", "--version"])
    
    async def _get_cargo_version(self) -> Optional[str]:
        return await self._get_version(["cargo", "--version"])
    
    async def _get_php_version(self) -> Optional[str]:
        return await self._get_version(["php", "--version"])
    
    async def _get_composer_version(self) -> Optional[str]:
        return await self._get_version(["composer", "--version"])
    
    async def _get_ruby_version(self) -> Optional[str]:
        return await self._get_version(["ruby", "--version"])
    
    async def _get_gem_version(self) -> Optional[str]:
        return await self._get_version(["gem", "--version"])
    
    async def _get_bundler_version(self) -> Optional[str]:
        return await self._get_version(["bundler", "--version"])
    
    async def _get_dotnet_version(self) -> Optional[str]:
        return await self._get_version(["dotnet", "--version"])
    
    def _get_python_executable(self, venv_path: Path) -> Path:
        """Get Python executable path in virtual environment."""
        if self.system_info["platform"] == "windows":
            return venv_path / "Scripts" / "python.exe"
        else:
            return venv_path / "bin" / "python"
    
    def get_activation_command(self, env_info: EnvironmentInfo) -> Optional[str]:
        """Get command to activate environment."""
        if env_info.type == "venv":
            if self.system_info["platform"] == "windows":
                return str(env_info.path / "Scripts" / "activate.bat")
            else:
                return f"source {env_info.path / 'bin' / 'activate'}"
        elif env_info.type == "conda":
            return f"conda activate {env_info.path.name}"
        else:
            return None
    
    @performance_monitor("environment_validation")
    async def validate_environment(self, env_info: EnvironmentInfo) -> bool:
        """Validate that the environment is properly created and functional."""
        try:
            if env_info.type == "venv":
                python_exe = self._get_python_executable(env_info.path)
                if not python_exe.exists():
                    return False
                
                # Test Python execution
                test_command = [str(python_exe), "-c", "print('test')"]
                process = await asyncio.create_subprocess_exec(
                    *test_command,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
                stdout, stderr = await process.communicate()
                return process.returncode == 0
            
            elif env_info.type in ["node", "java", "go", "rust", "php", "ruby", "dotnet"]:
                # For these environments, just check if the directory exists
                return env_info.path.exists()
            
            return True
            
        except Exception as e:
            agent_logger.error(f"Environment validation failed: {e}")
            return False 