"""
Intelligent project type detection system.
"""

import os
import re
import json
import asyncio
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Set
from collections import defaultdict, Counter

from .config import config
from .logger import agent_logger, performance_monitor
from .models import ProjectLanguage, ProjectDetectionResult


class ProjectDetector:
    """Intelligent project type and framework detection."""
    
    def __init__(self):
        self.detection_patterns = self._initialize_detection_patterns()
        self.framework_patterns = self._initialize_framework_patterns()
        self.file_extensions = self._initialize_file_extensions()
    
    def _initialize_detection_patterns(self) -> Dict[str, Dict[str, any]]:
        """Initialize detection patterns for different languages."""
        return {
            "python": {
                "files": ["requirements.txt", "setup.py", "pyproject.toml", "Pipfile", "poetry.lock", "conda.yml", "environment.yml"],
                "extensions": [".py", ".pyx", ".pyw"],
                "directories": ["__pycache__", ".pytest_cache", "venv", "env", ".venv"],
                "keywords": ["import ", "from ", "def ", "class ", "if __name__"],
                "confidence_boost": 0.3
            },
            "javascript": {
                "files": ["package.json", "yarn.lock", "package-lock.json", ".babelrc", "webpack.config.js"],
                "extensions": [".js", ".mjs", ".jsx"],
                "directories": ["node_modules", "dist", "build"],
                "keywords": ["require(", "import ", "export ", "function ", "const ", "let "],
                "confidence_boost": 0.3
            },
            "typescript": {
                "files": ["tsconfig.json", "package.json", "tslint.json", ".eslintrc"],
                "extensions": [".ts", ".tsx", ".d.ts"],
                "directories": ["node_modules", "dist", "build", "lib"],
                "keywords": ["interface ", "type ", "export ", "import ", "const "],
                "confidence_boost": 0.4
            },
            "java": {
                "files": ["pom.xml", "build.gradle", "build.gradle.kts", "gradle.properties"],
                "extensions": [".java", ".class", ".jar"],
                "directories": ["target", "build", "src/main/java", "src/test/java"],
                "keywords": ["public class", "import java", "package ", "public static"],
                "confidence_boost": 0.3
            },
            "go": {
                "files": ["go.mod", "go.sum", "Gopkg.toml", "Gopkg.lock"],
                "extensions": [".go"],
                "directories": ["vendor"],
                "keywords": ["package ", "import ", "func ", "type ", "var "],
                "confidence_boost": 0.4
            },
            "rust": {
                "files": ["Cargo.toml", "Cargo.lock"],
                "extensions": [".rs"],
                "directories": ["target", "src"],
                "keywords": ["fn ", "let ", "use ", "mod ", "pub "],
                "confidence_boost": 0.4
            },
            "php": {
                "files": ["composer.json", "composer.lock", "index.php"],
                "extensions": [".php", ".phtml"],
                "directories": ["vendor"],
                "keywords": ["<?php", "class ", "function ", "namespace "],
                "confidence_boost": 0.3
            },
            "ruby": {
                "files": ["Gemfile", "Gemfile.lock", "Rakefile", ".gemspec"],
                "extensions": [".rb", ".rake"],
                "directories": ["vendor"],
                "keywords": ["def ", "class ", "module ", "require "],
                "confidence_boost": 0.3
            },
            "c": {
                "files": ["Makefile", "CMakeLists.txt", "configure"],
                "extensions": [".c", ".h"],
                "directories": ["build", "obj"],
                "keywords": ["#include", "int main", "void ", "struct "],
                "confidence_boost": 0.2
            },
            "cpp": {
                "files": ["Makefile", "CMakeLists.txt", "configure", "meson.build"],
                "extensions": [".cpp", ".cc", ".cxx", ".hpp", ".hxx"],
                "directories": ["build", "obj"],
                "keywords": ["#include", "int main", "class ", "namespace "],
                "confidence_boost": 0.2
            },
            "csharp": {
                "files": [".csproj", ".sln", "packages.config", "Directory.Build.props"],
                "extensions": [".cs", ".vb"],
                "directories": ["bin", "obj", "packages"],
                "keywords": ["using ", "namespace ", "class ", "public "],
                "confidence_boost": 0.3
            }
        }
    
    def _initialize_framework_patterns(self) -> Dict[str, Dict[str, List[str]]]:
        """Initialize framework detection patterns."""
        return {
            "python": {
                "django": ["manage.py", "settings.py", "urls.py", "wsgi.py"],
                "flask": ["app.py", "application.py", "wsgi.py"],
                "fastapi": ["main.py", "app.py"],
                "streamlit": ["streamlit_app.py", "app.py"],
                "jupyter": [".ipynb", "requirements.txt"]
            },
            "javascript": {
                "react": ["src/App.js", "src/index.js", "public/index.html"],
                "vue": ["src/App.vue", "src/main.js"],
                "angular": ["angular.json", "src/app/app.module.ts"],
                "express": ["app.js", "server.js", "index.js"],
                "next": ["next.config.js", "pages/index.js"]
            },
            "typescript": {
                "react": ["src/App.tsx", "src/index.tsx"],
                "angular": ["angular.json", "src/app/app.module.ts"],
                "next": ["next.config.js", "pages/index.tsx"],
                "nest": ["src/main.ts", "nest-cli.json"]
            },
            "java": {
                "spring": ["src/main/java", "application.properties", "pom.xml"],
                "maven": ["pom.xml", "src/main/java"],
                "gradle": ["build.gradle", "gradle.properties"]
            }
        }
    
    def _initialize_file_extensions(self) -> Dict[str, List[str]]:
        """Initialize file extension mappings."""
        return {
            "python": [".py", ".pyx", ".pyw", ".pyi"],
            "javascript": [".js", ".mjs", ".jsx"],
            "typescript": [".ts", ".tsx", ".d.ts"],
            "java": [".java"],
            "go": [".go"],
            "rust": [".rs"],
            "php": [".php", ".phtml"],
            "ruby": [".rb", ".rake"],
            "c": [".c", ".h"],
            "cpp": [".cpp", ".cc", ".cxx", ".hpp", ".hxx", ".h++"],
            "csharp": [".cs", ".vb"]
        }
    
    @performance_monitor("project_detection")
    async def detect_project_type(self, project_path: Path) -> ProjectDetectionResult:
        """
        Detect the project type and framework.
        
        Args:
            project_path: Path to the project directory
            
        Returns:
            ProjectDetectionResult with detection information
        """
        agent_logger.info(f"Starting project detection for: {project_path}")
        
        if not project_path.exists() or not project_path.is_dir():
            raise ValueError(f"Invalid project path: {project_path}")
        
        # Initialize detection scores
        language_scores = defaultdict(float)
        detected_files = []
        package_manager_files = []
        build_files = []
        config_files = []
        framework_indicators = []
        
        # Scan directory structure
        scanned_files = await self._scan_directory(project_path)
        
        # Analyze files for language detection
        for file_path in scanned_files:
            file_name = file_path.name.lower()
            file_ext = file_path.suffix.lower()
            
            # Check against detection patterns
            for language, patterns in self.detection_patterns.items():
                score = 0.0
                
                # Check specific files
                if file_name in [f.lower() for f in patterns["files"]]:
                    score += patterns["confidence_boost"]
                    if file_name in ["package.json", "requirements.txt", "pom.xml", "go.mod", "cargo.toml"]:
                        package_manager_files.append(file_name)
                    elif file_name in ["makefile", "cmake", "build.gradle"]:
                        build_files.append(file_name)
                    else:
                        config_files.append(file_name)
                
                # Check file extensions
                if file_ext in patterns["extensions"]:
                    score += 0.2
                    detected_files.append(str(file_path.relative_to(project_path)))
                
                # Check directory patterns
                for dir_pattern in patterns["directories"]:
                    if dir_pattern in str(file_path):
                        score += 0.1
                
                language_scores[language] += score
        
        # Analyze file contents for additional clues
        content_scores = await self._analyze_file_contents(project_path, scanned_files[:20])  # Limit for performance
        for language, score in content_scores.items():
            language_scores[language] += score
        
        # Detect frameworks
        framework_indicators = await self._detect_frameworks(project_path, scanned_files)
        
        # Determine the most likely language
        if language_scores:
            detected_language = max(language_scores.items(), key=lambda x: x[1])
            language = ProjectLanguage(detected_language[0])
            confidence = min(detected_language[1], 1.0)
        else:
            language = ProjectLanguage.UNKNOWN
            confidence = 0.0
        
        result = ProjectDetectionResult(
            language=language,
            confidence=confidence,
            detected_files=detected_files[:10],  # Limit for readability
            package_manager_files=package_manager_files,
            build_files=build_files,
            config_files=config_files,
            framework_indicators=framework_indicators
        )
        
        agent_logger.log_detection_result(
            language=language.value,
            files_found=detected_files[:5],
            confidence=confidence,
            frameworks=framework_indicators
        )
        
        return result
    
    async def _scan_directory(self, project_path: Path, max_depth: int = 3) -> List[Path]:
        """Scan directory structure and return relevant files."""
        scanned_files = []
        
        def _recursive_scan(current_path: Path, current_depth: int):
            if current_depth > max_depth:
                return
            
            try:
                for item in current_path.iterdir():
                    # Skip hidden directories and common ignore patterns
                    if item.name.startswith('.') and item.name not in ['.gitignore', '.env', '.dockerignore']:
                        continue
                    
                    if item.name in ['node_modules', '__pycache__', '.git', 'target', 'build', 'dist']:
                        continue
                    
                    if item.is_file():
                        scanned_files.append(item)
                    elif item.is_dir() and current_depth < max_depth:
                        _recursive_scan(item, current_depth + 1)
            except (PermissionError, OSError):
                pass
        
        _recursive_scan(project_path, 0)
        return scanned_files
    
    async def _analyze_file_contents(self, project_path: Path, files: List[Path]) -> Dict[str, float]:
        """Analyze file contents for language-specific keywords."""
        content_scores = defaultdict(float)
        
        for file_path in files:
            if file_path.stat().st_size > 1024 * 1024:  # Skip files larger than 1MB
                continue
            
            try:
                # Read file content
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read(8192)  # Read first 8KB only
                
                # Check keywords for each language
                for language, patterns in self.detection_patterns.items():
                    keyword_count = 0
                    for keyword in patterns["keywords"]:
                        keyword_count += content.count(keyword)
                    
                    if keyword_count > 0:
                        # Normalize score based on file size and keyword frequency
                        score = min(keyword_count * 0.05, 0.3)
                        content_scores[language] += score
            
            except (UnicodeDecodeError, OSError, PermissionError):
                continue
        
        return content_scores
    
    async def _detect_frameworks(self, project_path: Path, files: List[Path]) -> List[str]:
        """Detect frameworks based on file patterns."""
        frameworks = []
        file_names = [f.name.lower() for f in files]
        
        # Check for package.json content for JS/TS frameworks
        package_json_path = project_path / "package.json"
        if package_json_path.exists():
            try:
                with open(package_json_path, 'r', encoding='utf-8') as f:
                    package_data = json.load(f)
                    dependencies = {**package_data.get('dependencies', {}), 
                                  **package_data.get('devDependencies', {})}
                    
                    # Detect JS/TS frameworks from dependencies
                    if 'react' in dependencies:
                        frameworks.append('react')
                    if 'vue' in dependencies:
                        frameworks.append('vue')
                    if '@angular/core' in dependencies:
                        frameworks.append('angular')
                    if 'express' in dependencies:
                        frameworks.append('express')
                    if 'next' in dependencies:
                        frameworks.append('next.js')
                    if '@nestjs/core' in dependencies:
                        frameworks.append('nestjs')
            except (json.JSONDecodeError, OSError):
                pass
        
        # Check for requirements.txt content for Python frameworks
        requirements_path = project_path / "requirements.txt"
        if requirements_path.exists():
            try:
                with open(requirements_path, 'r', encoding='utf-8') as f:
                    requirements = f.read().lower()
                    
                    if 'django' in requirements:
                        frameworks.append('django')
                    if 'flask' in requirements:
                        frameworks.append('flask')
                    if 'fastapi' in requirements:
                        frameworks.append('fastapi')
                    if 'streamlit' in requirements:
                        frameworks.append('streamlit')
            except OSError:
                pass
        
        # Check file patterns for other frameworks
        for language, fw_patterns in self.framework_patterns.items():
            for framework, pattern_files in fw_patterns.items():
                matches = sum(1 for pattern in pattern_files 
                            if any(pattern.lower() in fname for fname in file_names))
                if matches >= len(pattern_files) * 0.5:  # At least 50% of patterns match
                    if framework not in frameworks:
                        frameworks.append(framework)
        
        return frameworks
    
    def get_recommended_setup(self, detection: ProjectDetectionResult) -> Dict[str, any]:
        """Get recommended setup steps based on detection results."""
        language = detection.language.value
        
        if language in config.package_managers:
            pm_config = config.package_managers[language]
            return {
                "language": language,
                "environment_needed": pm_config.get("venv_command") is not None,
                "environment_command": pm_config.get("venv_command"),
                "install_commands": pm_config.get("install_commands", []),
                "package_files": pm_config.get("files", []),
                "frameworks": detection.framework_indicators
            }
        
        return {
            "language": language,
            "environment_needed": False,
            "install_commands": [],
            "frameworks": detection.framework_indicators
        } 