"""
Dependency management and installation system.
"""

import os
import asyncio
import subprocess
from pathlib import Path
from typing import List, Dict, Optional, Tuple
import json

from .config import config
from .logger import agent_logger, performance_monitor
from .models import (
    DependencyInstallation, EnvironmentInfo, ProjectDetectionResult, 
    ProjectLanguage
)


class DependencyManager:
    """Manages dependency installation for different project types."""
    
    def __init__(self):
        self.workspace_dir = config.workspace_dir
        self.timeout = config.timeout_minutes * 60  # Convert to seconds
        self.parallel_install = config.parallel_dependency_install
        self.max_concurrent = config.max_concurrent_operations
    
    @performance_monitor("dependency_installation")
    async def install_dependencies(
        self,
        project_path: Path,
        detection: ProjectDetectionResult,
        environment: Optional[EnvironmentInfo] = None
    ) -> List[DependencyInstallation]:
        """
        Install dependencies for the detected project type.
        
        Args:
            project_path: Path to the project
            detection: Project detection results
            environment: Environment information if available
            
        Returns:
            List of DependencyInstallation results
        """
        language = detection.language
        agent_logger.info(f"Installing dependencies for {language.value} project")
        
        # Get installation commands based on detected language
        install_commands = self._get_install_commands(project_path, detection, environment)
        
        if not install_commands:
            agent_logger.info(f"No dependencies to install for {language.value}")
            return []
        
        # Install dependencies
        if self.parallel_install and len(install_commands) > 1:
            installations = await self._install_parallel(project_path, install_commands, environment)
        else:
            installations = await self._install_sequential(project_path, install_commands, environment)
        
        # Log summary
        successful = sum(1 for inst in installations if inst.success)
        total = len(installations)
        
        if successful == total:
            agent_logger.success(
                f"Successfully installed all dependencies ({successful}/{total})",
                project_path=str(project_path),
                language=language.value
            )
        else:
            agent_logger.warning(
                f"Partial dependency installation ({successful}/{total} successful)",
                project_path=str(project_path),
                language=language.value
            )
        
        return installations
    
    def _get_install_commands(
        self,
        project_path: Path,
        detection: ProjectDetectionResult,
        environment: Optional[EnvironmentInfo] = None
    ) -> List[Dict[str, str]]:
        """Get appropriate installation commands based on project type."""
        language = detection.language.value
        commands = []
        
        if language == "python":
            commands.extend(self._get_python_commands(project_path, detection, environment))
        elif language in ["javascript", "typescript"]:
            commands.extend(self._get_node_commands(project_path, detection))
        elif language == "java":
            commands.extend(self._get_java_commands(project_path, detection))
        elif language == "go":
            commands.extend(self._get_go_commands(project_path, detection))
        elif language == "rust":
            commands.extend(self._get_rust_commands(project_path, detection))
        elif language == "php":
            commands.extend(self._get_php_commands(project_path, detection))
        elif language == "ruby":
            commands.extend(self._get_ruby_commands(project_path, detection))
        elif language == "csharp":
            commands.extend(self._get_dotnet_commands(project_path, detection))
        
        return commands
    
    def _get_python_commands(
        self,
        project_path: Path,
        detection: ProjectDetectionResult,
        environment: Optional[EnvironmentInfo] = None
    ) -> List[Dict[str, str]]:
        """Get Python dependency installation commands."""
        commands = []
        
        # Determine Python executable
        if environment and environment.type == "venv":
            if os.name == "nt":  # Windows
                python_exe = str(environment.path / "Scripts" / "python.exe")
                pip_exe = str(environment.path / "Scripts" / "pip.exe")
            else:  # Unix-like
                python_exe = str(environment.path / "bin" / "python")
                pip_exe = str(environment.path / "bin" / "pip")
        else:
            python_exe = "python"
            pip_exe = "pip"
        
        # Upgrade pip first
        commands.append({
            "name": "upgrade_pip",
            "command": f"{python_exe} -m pip install --upgrade pip",
            "description": "Upgrade pip to latest version"
        })
        
        # Install from requirements.txt
        requirements_file = project_path / "requirements.txt"
        if requirements_file.exists():
            commands.append({
                "name": "install_requirements",
                "command": f"{pip_exe} install -r requirements.txt",
                "description": "Install dependencies from requirements.txt"
            })
        
        # Install from pyproject.toml
        pyproject_file = project_path / "pyproject.toml"
        if pyproject_file.exists():
            commands.append({
                "name": "install_pyproject",
                "command": f"{pip_exe} install -e .",
                "description": "Install package in development mode"
            })
        
        # Install from setup.py
        setup_file = project_path / "setup.py"
        if setup_file.exists() and not pyproject_file.exists():
            commands.append({
                "name": "install_setup",
                "command": f"{pip_exe} install -e .",
                "description": "Install package from setup.py"
            })
        
        # Install from Pipfile
        pipfile = project_path / "Pipfile"
        if pipfile.exists():
            commands.append({
                "name": "install_pipenv",
                "command": "pipenv install",
                "description": "Install dependencies using Pipenv"
            })
        
        return commands
    
    def _get_node_commands(
        self,
        project_path: Path,
        detection: ProjectDetectionResult
    ) -> List[Dict[str, str]]:
        """Get Node.js dependency installation commands."""
        commands = []
        
        package_json = project_path / "package.json"
        if not package_json.exists():
            return commands
        
        # Determine package manager
        yarn_lock = project_path / "yarn.lock"
        pnpm_lock = project_path / "pnpm-lock.yaml"
        
        if pnpm_lock.exists():
            commands.append({
                "name": "install_pnpm",
                "command": "pnpm install",
                "description": "Install dependencies using pnpm"
            })
        elif yarn_lock.exists():
            commands.append({
                "name": "install_yarn",
                "command": "yarn install",
                "description": "Install dependencies using Yarn"
            })
        else:
            commands.append({
                "name": "install_npm",
                "command": "npm install",
                "description": "Install dependencies using npm"
            })
        
        return commands
    
    def _get_java_commands(
        self,
        project_path: Path,
        detection: ProjectDetectionResult
    ) -> List[Dict[str, str]]:
        """Get Java dependency installation commands."""
        commands = []
        
        # Maven
        pom_xml = project_path / "pom.xml"
        if pom_xml.exists():
            commands.append({
                "name": "maven_install",
                "command": "mvn clean install -DskipTests",
                "description": "Install dependencies using Maven"
            })
        
        # Gradle
        build_gradle = project_path / "build.gradle"
        build_gradle_kts = project_path / "build.gradle.kts"
        if build_gradle.exists() or build_gradle_kts.exists():
            commands.append({
                "name": "gradle_build",
                "command": "./gradlew build -x test",
                "description": "Build project using Gradle"
            })
        
        return commands
    
    def _get_go_commands(
        self,
        project_path: Path,
        detection: ProjectDetectionResult
    ) -> List[Dict[str, str]]:
        """Get Go dependency installation commands."""
        commands = []
        
        go_mod = project_path / "go.mod"
        if go_mod.exists():
            commands.extend([
                {
                    "name": "go_mod_download",
                    "command": "go mod download",
                    "description": "Download Go module dependencies"
                },
                {
                    "name": "go_mod_tidy",
                    "command": "go mod tidy",
                    "description": "Tidy Go module dependencies"
                }
            ])
        
        return commands
    
    def _get_rust_commands(
        self,
        project_path: Path,
        detection: ProjectDetectionResult
    ) -> List[Dict[str, str]]:
        """Get Rust dependency installation commands."""
        commands = []
        
        cargo_toml = project_path / "Cargo.toml"
        if cargo_toml.exists():
            commands.append({
                "name": "cargo_build",
                "command": "cargo build",
                "description": "Build Rust project and install dependencies"
            })
        
        return commands
    
    def _get_php_commands(
        self,
        project_path: Path,
        detection: ProjectDetectionResult
    ) -> List[Dict[str, str]]:
        """Get PHP dependency installation commands."""
        commands = []
        
        composer_json = project_path / "composer.json"
        if composer_json.exists():
            commands.append({
                "name": "composer_install",
                "command": "composer install",
                "description": "Install PHP dependencies using Composer"
            })
        
        return commands
    
    def _get_ruby_commands(
        self,
        project_path: Path,
        detection: ProjectDetectionResult
    ) -> List[Dict[str, str]]:
        """Get Ruby dependency installation commands."""
        commands = []
        
        gemfile = project_path / "Gemfile"
        if gemfile.exists():
            commands.append({
                "name": "bundle_install",
                "command": "bundle install",
                "description": "Install Ruby gems using Bundler"
            })
        
        return commands
    
    def _get_dotnet_commands(
        self,
        project_path: Path,
        detection: ProjectDetectionResult
    ) -> List[Dict[str, str]]:
        """Get .NET dependency installation commands."""
        commands = []
        
        # Look for .csproj files
        csproj_files = list(project_path.glob("*.csproj"))
        sln_files = list(project_path.glob("*.sln"))
        
        if csproj_files or sln_files:
            commands.append({
                "name": "dotnet_restore",
                "command": "dotnet restore",
                "description": "Restore .NET dependencies"
            })
        
        return commands
    
    async def _install_sequential(
        self,
        project_path: Path,
        install_commands: List[Dict[str, str]],
        environment: Optional[EnvironmentInfo] = None
    ) -> List[DependencyInstallation]:
        """Install dependencies sequentially."""
        installations = []
        
        for cmd_info in install_commands:
            installation = await self._run_install_command(
                project_path, cmd_info, environment
            )
            installations.append(installation)
            
            # Stop on critical failures
            if not installation.success and cmd_info["name"] in ["upgrade_pip", "install_requirements"]:
                agent_logger.error(f"Critical installation step failed: {cmd_info['name']}")
                break
        
        return installations
    
    async def _install_parallel(
        self,
        project_path: Path,
        install_commands: List[Dict[str, str]],
        environment: Optional[EnvironmentInfo] = None
    ) -> List[DependencyInstallation]:
        """Install dependencies in parallel where possible."""
        
        # Separate commands that must run sequentially vs. in parallel
        sequential_commands = []
        parallel_commands = []
        
        for cmd_info in install_commands:
            # Commands that should run sequentially
            if cmd_info["name"] in ["upgrade_pip", "maven_install", "gradle_build"]:
                sequential_commands.append(cmd_info)
            else:
                parallel_commands.append(cmd_info)
        
        installations = []
        
        # Run sequential commands first
        for cmd_info in sequential_commands:
            installation = await self._run_install_command(
                project_path, cmd_info, environment
            )
            installations.append(installation)
            
            if not installation.success and cmd_info["name"] == "upgrade_pip":
                agent_logger.warning("Pip upgrade failed, continuing anyway")
        
        # Run parallel commands
        if parallel_commands:
            semaphore = asyncio.Semaphore(self.max_concurrent)
            
            async def run_with_semaphore(cmd_info):
                async with semaphore:
                    return await self._run_install_command(
                        project_path, cmd_info, environment
                    )
            
            parallel_results = await asyncio.gather(
                *[run_with_semaphore(cmd) for cmd in parallel_commands],
                return_exceptions=True
            )
            
            for result in parallel_results:
                if isinstance(result, Exception):
                    # Create failed installation record
                    installation = DependencyInstallation(
                        command="unknown",
                        working_directory=project_path,
                        success=False,
                        error=str(result)
                    )
                else:
                    installation = result
                installations.append(installation)
        
        return installations
    
    async def _run_install_command(
        self,
        project_path: Path,
        cmd_info: Dict[str, str],
        environment: Optional[EnvironmentInfo] = None
    ) -> DependencyInstallation:
        """Run a single installation command."""
        
        command = cmd_info["command"]
        name = cmd_info["name"]
        description = cmd_info["description"]
        
        agent_logger.log_dependency_installation(
            command=command,
            working_dir=project_path,
            operation=name
        )
        
        installation = DependencyInstallation(
            command=command,
            working_directory=project_path
        )
        
        start_time = asyncio.get_event_loop().time()
        
        try:
            # Prepare environment variables
            env = os.environ.copy()
            
            # Set up environment-specific variables
            if environment and environment.type == "venv":
                if os.name == "nt":  # Windows
                    env["PATH"] = f"{environment.path / 'Scripts'}{os.pathsep}{env['PATH']}"
                else:  # Unix-like
                    env["PATH"] = f"{environment.path / 'bin'}{os.pathsep}{env['PATH']}"
                env["VIRTUAL_ENV"] = str(environment.path)
            
            # Split command for subprocess
            cmd_parts = command.split()
            
            # Run the command
            process = await asyncio.create_subprocess_exec(
                *cmd_parts,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=project_path,
                env=env
            )
            
            try:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(),
                    timeout=self.timeout
                )
            except asyncio.TimeoutError:
                process.kill()
                raise RuntimeError(f"Command timed out after {self.timeout} seconds")
            
            duration = asyncio.get_event_loop().time() - start_time
            
            installation.duration = duration
            installation.output = stdout.decode() if stdout else ""
            installation.error = stderr.decode() if stderr else ""
            installation.success = process.returncode == 0
            
            if installation.success:
                agent_logger.success(
                    f"Installation completed: {description}",
                    command=command,
                    duration=duration
                )
            else:
                agent_logger.error(
                    f"Installation failed: {description}",
                    command=command,
                    error=installation.error[:500],  # Limit error message length
                    return_code=process.returncode
                )
            
            return installation
            
        except Exception as e:
            duration = asyncio.get_event_loop().time() - start_time
            installation.duration = duration
            installation.success = False
            installation.error = str(e)
            
            agent_logger.error(
                f"Installation exception: {description}",
                command=command,
                error=str(e)
            )
            
            return installation
    
    async def check_dependencies(
        self,
        project_path: Path,
        detection: ProjectDetectionResult
    ) -> Dict[str, bool]:
        """Check if dependencies are already installed."""
        language = detection.language.value
        
        if language == "python":
            return await self._check_python_dependencies(project_path)
        elif language in ["javascript", "typescript"]:
            return await self._check_node_dependencies(project_path)
        elif language == "java":
            return await self._check_java_dependencies(project_path)
        elif language == "go":
            return await self._check_go_dependencies(project_path)
        elif language == "rust":
            return await self._check_rust_dependencies(project_path)
        
        return {}
    
    async def _check_python_dependencies(self, project_path: Path) -> Dict[str, bool]:
        """Check Python dependencies."""
        checks = {}
        
        # Check if virtual environment exists
        venv_path = project_path / "venv"
        checks["virtual_environment"] = venv_path.exists()
        
        # Check if requirements are installed
        requirements_file = project_path / "requirements.txt"
        if requirements_file.exists():
            # This is a simplified check - in production, you might want to
            # parse requirements.txt and check each package
            site_packages = venv_path / "lib" / "python*" / "site-packages"
            checks["requirements_installed"] = len(list(venv_path.glob("lib/python*/site-packages/*"))) > 10
        
        return checks
    
    async def _check_node_dependencies(self, project_path: Path) -> Dict[str, bool]:
        """Check Node.js dependencies."""
        checks = {}
        
        node_modules = project_path / "node_modules"
        checks["node_modules"] = node_modules.exists()
        
        package_json = project_path / "package.json"
        if package_json.exists() and node_modules.exists():
            # Check if main dependencies are installed
            try:
                with open(package_json, 'r') as f:
                    data = json.load(f)
                    dependencies = data.get('dependencies', {})
                    
                    if dependencies:
                        # Check if at least 80% of dependencies are installed
                        installed_count = 0
                        for dep in dependencies:
                            if (node_modules / dep).exists():
                                installed_count += 1
                        
                        checks["dependencies_installed"] = installed_count >= len(dependencies) * 0.8
            except (json.JSONDecodeError, OSError):
                checks["dependencies_installed"] = False
        
        return checks
    
    async def _check_java_dependencies(self, project_path: Path) -> Dict[str, bool]:
        """Check Java dependencies."""
        checks = {}
        
        # Check Maven
        target_dir = project_path / "target"
        checks["maven_built"] = target_dir.exists()
        
        # Check Gradle
        build_dir = project_path / "build"
        checks["gradle_built"] = build_dir.exists()
        
        return checks
    
    async def _check_go_dependencies(self, project_path: Path) -> Dict[str, bool]:
        """Check Go dependencies."""
        checks = {}
        
        go_mod = project_path / "go.mod"
        go_sum = project_path / "go.sum"
        
        checks["go_mod"] = go_mod.exists()
        checks["go_sum"] = go_sum.exists()
        
        return checks
    
    async def _check_rust_dependencies(self, project_path: Path) -> Dict[str, bool]:
        """Check Rust dependencies."""
        checks = {}
        
        cargo_lock = project_path / "Cargo.lock"
        target_dir = project_path / "target"
        
        checks["cargo_lock"] = cargo_lock.exists()
        checks["target_built"] = target_dir.exists()
        
        return checks 