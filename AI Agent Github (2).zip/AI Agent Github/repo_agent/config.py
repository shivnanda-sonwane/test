"""
Configuration management for the Repository Setup Agent.
"""

import os
from pathlib import Path
from typing import Optional, Dict, Any, List
from pydantic import BaseSettings, Field, validator
from dotenv import load_dotenv

# Load environment variables
load_dotenv()


class AgentConfig(BaseSettings):
    """Configuration settings for the Repository Setup Agent."""
    
    # AI Provider Configuration
    ai_provider: str = Field("openai", env="AI_PROVIDER")  # "openai" or "azure"
    
    # OpenAI Configuration
    openai_api_key: Optional[str] = Field(None, env="OPENAI_API_KEY")
    openai_model: str = Field("gpt-4", env="OPENAI_MODEL")
    
    # Azure OpenAI Configuration
    azure_openai_api_key: Optional[str] = Field(None, env="AZURE_OPENAI_API_KEY")
    azure_openai_endpoint: Optional[str] = Field(None, env="AZURE_OPENAI_ENDPOINT")
    azure_openai_api_version: str = Field("2024-02-15-preview", env="AZURE_OPENAI_API_VERSION")
    azure_openai_deployment_name: Optional[str] = Field(None, env="AZURE_OPENAI_DEPLOYMENT_NAME")
    
    # GitHub Configuration
    github_token: Optional[str] = Field(None, env="GITHUB_TOKEN")
    
    # Agent Configuration
    agent_name: str = Field("RepoSetupAgent", env="AGENT_NAME")
    workspace_dir: Path = Field(Path("./workspace"), env="WORKSPACE_DIR")
    max_concurrent_operations: int = Field(3, env="MAX_CONCURRENT_OPERATIONS")
    timeout_minutes: int = Field(30, env="TIMEOUT_MINUTES")
    
    # Logging Configuration
    log_level: str = Field("INFO", env="LOG_LEVEL")
    log_file: str = Field("agent.log", env="LOG_FILE")
    
    # Project Detection Settings
    auto_detect_language: bool = Field(True, env="AUTO_DETECT_LANGUAGE")
    force_environment_creation: bool = Field(False, env="FORCE_ENVIRONMENT_CREATION")
    skip_existing_environments: bool = Field(True, env="SKIP_EXISTING_ENVIRONMENTS")
    
    # Performance Settings
    enable_async_operations: bool = Field(True, env="ENABLE_ASYNC_OPERATIONS")
    cache_detection_results: bool = Field(True, env="CACHE_DETECTION_RESULTS")
    parallel_dependency_install: bool = Field(True, env="PARALLEL_DEPENDENCY_INSTALL")
    
    # Supported Languages and Tools
    supported_languages: List[str] = Field(default=[
        "python", "javascript", "typescript", "java", "go", "rust", 
        "php", "ruby", "c", "cpp", "csharp", "swift", "kotlin"
    ])
    
    # Package Managers Configuration
    package_managers: Dict[str, Dict[str, Any]] = Field(default={
        "python": {
            "files": ["requirements.txt", "pyproject.toml", "setup.py", "Pipfile"],
            "install_commands": ["pip install -r requirements.txt", "pip install -e ."],
            "venv_command": "python -m venv"
        },
        "javascript": {
            "files": ["package.json", "yarn.lock", "pnpm-lock.yaml"],
            "install_commands": ["npm install", "yarn install", "pnpm install"],
            "venv_command": None
        },
        "typescript": {
            "files": ["package.json", "tsconfig.json"],
            "install_commands": ["npm install", "yarn install"],
            "venv_command": None
        },
        "java": {
            "files": ["pom.xml", "build.gradle", "build.gradle.kts"],
            "install_commands": ["mvn install", "gradle build"],
            "venv_command": None
        },
        "go": {
            "files": ["go.mod", "go.sum"],
            "install_commands": ["go mod download", "go mod tidy"],
            "venv_command": None
        },
        "rust": {
            "files": ["Cargo.toml", "Cargo.lock"],
            "install_commands": ["cargo build"],
            "venv_command": None
        }
    })
    
    @validator("workspace_dir", pre=True)
    def validate_workspace_dir(cls, v):
        """Ensure workspace directory exists."""
        if isinstance(v, str):
            v = Path(v)
        v.mkdir(parents=True, exist_ok=True)
        return v
    
    @validator("log_level")
    def validate_log_level(cls, v):
        """Validate log level."""
        valid_levels = ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
        if v.upper() not in valid_levels:
            raise ValueError(f"Invalid log level. Must be one of: {valid_levels}")
        return v.upper()
    
    @validator("max_concurrent_operations")
    def validate_max_concurrent_operations(cls, v):
        """Validate concurrent operations limit."""
        if v < 1 or v > 10:
            raise ValueError("max_concurrent_operations must be between 1 and 10")
        return v
    
    @validator("ai_provider")
    def validate_ai_provider(cls, v):
        """Validate AI provider."""
        valid_providers = ["openai", "azure"]
        if v.lower() not in valid_providers:
            raise ValueError(f"Invalid AI provider. Must be one of: {valid_providers}")
        return v.lower()
    
    @validator("azure_openai_endpoint")
    def validate_azure_endpoint(cls, v, values):
        """Validate Azure OpenAI endpoint format."""
        if v and not v.startswith('https://'):
            raise ValueError("Azure OpenAI endpoint must start with 'https://'")
        return v
    
    def __init__(self, **data):
        """Initialize with validation."""
        super().__init__(**data)
        self._validate_ai_configuration()
    
    def _validate_ai_configuration(self):
        """Validate AI configuration based on provider."""
        if self.ai_provider == "openai":
            if not self.openai_api_key:
                raise ValueError("OpenAI API key is required when using OpenAI provider")
        elif self.ai_provider == "azure":
            missing_fields = []
            if not self.azure_openai_api_key:
                missing_fields.append("azure_openai_api_key")
            if not self.azure_openai_endpoint:
                missing_fields.append("azure_openai_endpoint")
            if not self.azure_openai_deployment_name:
                missing_fields.append("azure_openai_deployment_name")
            
            if missing_fields:
                raise ValueError(f"Azure OpenAI configuration missing: {', '.join(missing_fields)}")
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False


# Global configuration instance
config = AgentConfig() 