"""
Main Repository Setup Agent.
"""

import asyncio
from pathlib import Path
from typing import Optional, Dict, Any, List
from datetime import datetime

from .config import config
from .logger import agent_logger, create_progress_bar, console
from .workflow import RepoSetupWorkflow
from .models import SetupResult, ProjectLanguage
from rich.table import Table
from rich.panel import Panel
from rich.text import Text


class RepoSetupAgent:
    """
    Main agent for automated repository setup.
    
    This agent orchestrates the entire process of cloning repositories,
    detecting project types, creating environments, and installing dependencies.
    """
    
    def __init__(self, config_overrides: Optional[Dict[str, Any]] = None):
        """
        Initialize the Repository Setup Agent.
        
        Args:
            config_overrides: Optional configuration overrides
        """
        self.workflow = RepoSetupWorkflow()
        self.start_time = None
        
        # Apply configuration overrides
        if config_overrides:
            for key, value in config_overrides.items():
                if hasattr(config, key):
                    setattr(config, key, value)
        
        agent_logger.info(f"Repository Setup Agent initialized", agent_name=config.agent_name)
    
    async def setup_repository(
        self,
        repository_url: str,
        target_directory: Optional[Path] = None,
        show_progress: bool = True
    ) -> SetupResult:
        """
        Setup a repository with automatic detection and configuration.
        
        Args:
            repository_url: URL of the repository to setup
            target_directory: Optional target directory (auto-generated if not provided)
            show_progress: Whether to show progress indicators
            
        Returns:
            SetupResult with complete setup information
        """
        self.start_time = datetime.now()
        
        agent_logger.info(
            f"Starting repository setup",
            repository_url=repository_url,
            target_directory=str(target_directory) if target_directory else "auto-generated"
        )
        
        if show_progress:
            console.print(Panel(
                f"🚀 [bold blue]Repository Setup Agent[/bold blue]\n"
                f"📂 Repository: [cyan]{repository_url}[/cyan]\n"
                f"📁 Target: [cyan]{target_directory or 'Auto-generated'}[/cyan]",
                title="Starting Setup",
                border_style="blue"
            ))
        
        try:
            # Run the workflow
            with create_progress_bar("Setting up repository...") as progress:
                if show_progress:
                    task = progress.add_task("Processing...", total=100)
                
                result = await self.workflow.run(repository_url, target_directory)
                
                if show_progress:
                    progress.update(task, completed=100)
            
            # Display results
            if show_progress:
                self._display_results(result)
            
            return result
            
        except Exception as e:
            agent_logger.error(f"Repository setup failed: {e}")
            if show_progress:
                console.print(Panel(
                    f"❌ [bold red]Setup Failed[/bold red]\n"
                    f"Error: {str(e)}",
                    title="Setup Error",
                    border_style="red"
                ))
            raise
    
    async def setup_multiple_repositories(
        self,
        repository_urls: List[str],
        base_directory: Optional[Path] = None,
        max_concurrent: Optional[int] = None,
        show_progress: bool = True
    ) -> List[SetupResult]:
        """
        Setup multiple repositories concurrently.
        
        Args:
            repository_urls: List of repository URLs to setup
            base_directory: Base directory for all repositories
            max_concurrent: Maximum concurrent operations (defaults to config)
            show_progress: Whether to show progress indicators
            
        Returns:
            List of SetupResult objects
        """
        max_concurrent = max_concurrent or config.max_concurrent_operations
        
        agent_logger.info(
            f"Starting batch repository setup",
            repository_count=len(repository_urls),
            max_concurrent=max_concurrent
        )
        
        if show_progress:
            console.print(Panel(
                f"🔄 [bold blue]Batch Repository Setup[/bold blue]\n"
                f"📂 Repositories: [cyan]{len(repository_urls)}[/cyan]\n"
                f"⚡ Concurrent: [cyan]{max_concurrent}[/cyan]",
                title="Batch Setup",
                border_style="blue"
            ))
        
        # Create semaphore for concurrency control
        semaphore = asyncio.Semaphore(max_concurrent)
        
        async def setup_single(repo_url: str) -> SetupResult:
            """Setup a single repository with semaphore control."""
            async with semaphore:
                target_dir = None
                if base_directory:
                    repo_name = Path(repo_url).stem.replace('.git', '')
                    target_dir = base_directory / repo_name
                
                return await self.setup_repository(
                    repo_url, 
                    target_dir, 
                    show_progress=False  # Disable individual progress for batch
                )
        
        # Run all setups concurrently
        with create_progress_bar("Setting up repositories...") as progress:
            if show_progress:
                task = progress.add_task("Processing batch...", total=len(repository_urls))
            
            results = await asyncio.gather(
                *[setup_single(url) for url in repository_urls],
                return_exceptions=True
            )
            
            if show_progress:
                progress.update(task, completed=len(repository_urls))
        
        # Process results and handle exceptions
        final_results = []
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                agent_logger.error(f"Repository setup failed: {repository_urls[i]} - {result}")
                # Create a failed result
                from .models import RepositoryInfo
                failed_result = SetupResult(
                    repository=RepositoryInfo(
                        url=repository_urls[i],
                        local_path=Path("failed"),
                        clone_success=False
                    ),
                    detection=None,
                    success=False
                )
                final_results.append(failed_result)
            else:
                final_results.append(result)
        
        # Display batch results
        if show_progress:
            self._display_batch_results(final_results)
        
        return final_results
    
    def _display_results(self, result: SetupResult):
        """Display setup results in a formatted table."""
        
        # Create main results table
        table = Table(title="📊 Setup Results", show_header=True, header_style="bold magenta")
        table.add_column("Aspect", style="cyan", no_wrap=True)
        table.add_column("Status", style="green")
        table.add_column("Details", style="white")
        
        # Repository info
        repo_status = "✅ Success" if result.repository.clone_success else "❌ Failed"
        table.add_row(
            "Repository",
            repo_status,
            f"{result.repository.url} → {result.repository.local_path}"
        )
        
        # Project detection
        if result.detection:
            detection_status = "✅ Detected" if result.detection.confidence > 0.5 else "⚠️ Uncertain"
            detection_details = f"{result.detection.language.value} (confidence: {result.detection.confidence:.2f})"
            if result.detection.framework_indicators:
                detection_details += f", frameworks: {', '.join(result.detection.framework_indicators)}"
        else:
            detection_status = "❌ Failed"
            detection_details = "Could not detect project type"
        
        table.add_row("Detection", detection_status, detection_details)
        
        # Environment
        if result.environment:
            env_status = "✅ Created" if result.environment.created else "⚠️ Existing"
            env_details = f"{result.environment.type} at {result.environment.path}"
        else:
            env_status = "➖ Not needed"
            env_details = "No environment required"
        
        table.add_row("Environment", env_status, env_details)
        
        # Dependencies
        if result.dependencies:
            successful_deps = sum(1 for dep in result.dependencies if dep.success)
            total_deps = len(result.dependencies)
            if successful_deps == total_deps:
                deps_status = "✅ All installed"
            elif successful_deps > 0:
                deps_status = "⚠️ Partial"
            else:
                deps_status = "❌ Failed"
            deps_details = f"{successful_deps}/{total_deps} successful"
        else:
            deps_status = "➖ None found"
            deps_details = "No dependencies to install"
        
        table.add_row("Dependencies", deps_status, deps_details)
        
        # Overall status
        overall_status = "✅ Success" if result.success else "❌ Failed"
        overall_details = f"Completed in {result.total_duration:.2f}s"
        table.add_row("Overall", overall_status, overall_details)
        
        console.print(table)
        
        # Display operations summary if there are failures
        failed_operations = result.failed_operations
        if failed_operations:
            console.print("\n")
            error_table = Table(title="❌ Failed Operations", show_header=True, header_style="bold red")
            error_table.add_column("Operation", style="cyan")
            error_table.add_column("Error", style="red")
            
            for op in failed_operations:
                error_table.add_row(op.name, op.error_message or "Unknown error")
            
            console.print(error_table)
        
        # Display created files
        if result.created_files:
            console.print(f"\n📝 Created files: {', '.join(result.created_files)}")
        
        # Final summary panel
        if result.success:
            summary_style = "green"
            summary_title = "✅ Setup Complete"
            summary_text = f"Repository successfully set up at [cyan]{result.repository.local_path}[/cyan]"
        else:
            summary_style = "red"
            summary_title = "❌ Setup Incomplete"
            summary_text = f"Setup completed with errors. Check logs for details."
        
        console.print(Panel(
            summary_text,
            title=summary_title,
            border_style=summary_style
        ))
    
    def _display_batch_results(self, results: List[SetupResult]):
        """Display batch setup results."""
        
        # Summary statistics
        total = len(results)
        successful = sum(1 for r in results if r.success)
        failed = total - successful
        
        # Create summary table
        summary_table = Table(title="📈 Batch Results Summary", show_header=True, header_style="bold magenta")
        summary_table.add_column("Metric", style="cyan")
        summary_table.add_column("Count", style="green")
        summary_table.add_column("Percentage", style="yellow")
        
        summary_table.add_row("Total Repositories", str(total), "100%")
        summary_table.add_row("Successful", str(successful), f"{successful/total*100:.1f}%")
        summary_table.add_row("Failed", str(failed), f"{failed/total*100:.1f}%")
        
        console.print(summary_table)
        
        # Individual results table
        if total <= 10:  # Show individual results for small batches
            results_table = Table(title="📋 Individual Results", show_header=True, header_style="bold blue")
            results_table.add_column("Repository", style="cyan")
            results_table.add_column("Language", style="green")
            results_table.add_column("Status", style="white")
            results_table.add_column("Duration", style="yellow")
            
            for result in results:
                repo_name = Path(result.repository.url).stem.replace('.git', '')
                language = result.detection.language.value if result.detection else "unknown"
                status = "✅ Success" if result.success else "❌ Failed"
                duration = f"{result.total_duration:.1f}s"
                
                results_table.add_row(repo_name, language, status, duration)
            
            console.print(results_table)
        
        # Final summary
        if successful == total:
            summary_style = "green"
            summary_title = "✅ Batch Complete"
            summary_text = f"All {total} repositories set up successfully!"
        elif successful > 0:
            summary_style = "yellow"
            summary_title = "⚠️ Batch Partial"
            summary_text = f"{successful}/{total} repositories set up successfully"
        else:
            summary_style = "red"
            summary_title = "❌ Batch Failed"
            summary_text = f"All {total} repositories failed to set up"
        
        console.print(Panel(
            summary_text,
            title=summary_title,
            border_style=summary_style
        ))
    
    async def get_repository_info(self, repository_url: str) -> Dict[str, Any]:
        """
        Get information about a repository without cloning it.
        
        Args:
            repository_url: URL of the repository
            
        Returns:
            Dictionary with repository information
        """
        agent_logger.info(f"Getting repository info: {repository_url}")
        
        try:
            repo_info = await self.workflow.repo_manager.get_remote_info(repository_url)
            return repo_info
        except Exception as e:
            agent_logger.error(f"Failed to get repository info: {e}")
            return {"url": repository_url, "error": str(e)}
    
    def get_supported_languages(self) -> List[str]:
        """Get list of supported programming languages."""
        return [lang.value for lang in ProjectLanguage if lang != ProjectLanguage.UNKNOWN]
    
    def get_agent_info(self) -> Dict[str, Any]:
        """Get information about the agent configuration."""
        return {
            "agent_name": config.agent_name,
            "workspace_dir": str(config.workspace_dir),
            "supported_languages": self.get_supported_languages(),
            "max_concurrent_operations": config.max_concurrent_operations,
            "timeout_minutes": config.timeout_minutes,
            "async_operations_enabled": config.enable_async_operations,
            "parallel_dependency_install": config.parallel_dependency_install
        }
    
    async def cleanup_workspace(self, keep_successful: bool = True) -> Dict[str, int]:
        """
        Clean up the workspace directory.
        
        Args:
            keep_successful: Whether to keep successfully set up repositories
            
        Returns:
            Dictionary with cleanup statistics
        """
        agent_logger.info("Starting workspace cleanup")
        
        cleaned_count = 0
        kept_count = 0
        error_count = 0
        
        try:
            if not config.workspace_dir.exists():
                return {"cleaned": 0, "kept": 0, "errors": 0}
            
            for item in config.workspace_dir.iterdir():
                if item.is_dir():
                    try:
                        # Check if it's a git repository
                        git_dir = item / ".git"
                        if git_dir.exists():
                            if keep_successful:
                                # Simple check: if virtual environment exists, consider it successful
                                venv_exists = (item / "venv").exists() or (item / "node_modules").exists()
                                if venv_exists:
                                    kept_count += 1
                                    continue
                            
                            # Clean up the directory
                            await self.workflow.repo_manager.cleanup_repository(item)
                            cleaned_count += 1
                        
                    except Exception as e:
                        agent_logger.error(f"Failed to cleanup {item}: {e}")
                        error_count += 1
            
            agent_logger.info(
                f"Workspace cleanup completed",
                cleaned=cleaned_count,
                kept=kept_count,
                errors=error_count
            )
            
            return {"cleaned": cleaned_count, "kept": kept_count, "errors": error_count}
            
        except Exception as e:
            agent_logger.error(f"Workspace cleanup failed: {e}")
            return {"cleaned": cleaned_count, "kept": kept_count, "errors": error_count + 1} 