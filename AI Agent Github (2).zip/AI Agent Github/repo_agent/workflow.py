"""
LangGraph workflow for repository setup automation.
"""

import asyncio
from pathlib import Path
from typing import Dict, Any, Optional, List
from datetime import datetime
import os # Added missing import

from langgraph import StateGraph, END
from langchain_openai import ChatOpenAI, AzureChatOpenAI

from .config import config
from .logger import agent_logger, performance_monitor
from .models import AgentState, SetupResult, RepositoryInfo, ProjectLanguage, OperationStatus
from .repository import RepositoryManager
from .detector import ProjectDetector
from .environment import EnvironmentManager
from .dependency_manager import DependencyManager


class RepoSetupWorkflow:
    """LangGraph workflow for automated repository setup."""
    
    def __init__(self):
        self.repo_manager = RepositoryManager()
        self.detector = ProjectDetector()
        self.env_manager = EnvironmentManager()
        self.dep_manager = DependencyManager()
        
        # Initialize LLM for decision making
        self.llm = self._initialize_llm()
        
        # Build the workflow graph
        self.workflow = self._build_workflow()
    
    def _initialize_llm(self):
        """Initialize the appropriate LLM based on configuration."""
        if config.ai_provider == "azure":
            return AzureChatOpenAI(
                api_key=config.azure_openai_api_key,
                azure_endpoint=config.azure_openai_endpoint,
                api_version=config.azure_openai_api_version,
                deployment_name=config.azure_openai_deployment_name,
                temperature=0.1
            )
        else:  # Default to OpenAI
            return ChatOpenAI(
                api_key=config.openai_api_key,
                model=config.openai_model,
                temperature=0.1
            )
    
    def _build_workflow(self) -> StateGraph:
        """Build the LangGraph workflow."""
        
        # Define the state graph
        workflow = StateGraph(AgentState)
        
        # Add nodes
        workflow.add_node("validate_input", self.validate_input)
        workflow.add_node("clone_repository", self.clone_repository)
        workflow.add_node("detect_project", self.detect_project_type)
        workflow.add_node("analyze_requirements", self.analyze_requirements)
        workflow.add_node("create_environment", self.create_environment)
        workflow.add_node("install_dependencies", self.install_dependencies)
        workflow.add_node("configure_project", self.configure_project)
        workflow.add_node("validate_setup", self.validate_setup)
        workflow.add_node("handle_error", self.handle_error)
        workflow.add_node("finalize", self.finalize_setup)
        
        # Set entry point
        workflow.set_entry_point("validate_input")
        
        # Define edges (workflow flow)
        workflow.add_edge("validate_input", "clone_repository")
        workflow.add_conditional_edges(
            "clone_repository",
            self.check_clone_status,
            {
                "success": "detect_project",
                "failure": "handle_error",
                "retry": "clone_repository"
            }
        )
        workflow.add_edge("detect_project", "analyze_requirements")
        workflow.add_conditional_edges(
            "analyze_requirements",
            self.check_analysis_status,
            {
                "needs_environment": "create_environment",
                "skip_environment": "install_dependencies",
                "no_dependencies": "configure_project"
            }
        )
        workflow.add_edge("create_environment", "install_dependencies")
        workflow.add_conditional_edges(
            "install_dependencies",
            self.check_dependency_status,
            {
                "success": "configure_project",
                "partial": "configure_project",
                "failure": "handle_error",
                "retry": "install_dependencies"
            }
        )
        workflow.add_edge("configure_project", "validate_setup")
        workflow.add_conditional_edges(
            "validate_setup",
            self.check_validation_status,
            {
                "success": "finalize",
                "failure": "handle_error"
            }
        )
        workflow.add_conditional_edges(
            "handle_error",
            self.check_error_recovery,
            {
                "retry": "clone_repository",
                "abort": "finalize"
            }
        )
        workflow.add_edge("finalize", END)
        
        return workflow.compile()
    
    @performance_monitor("workflow_execution")
    async def run(self, repository_url: str, target_directory: Optional[Path] = None) -> SetupResult:
        """
        Run the complete repository setup workflow.
        
        Args:
            repository_url: URL of the repository to setup
            target_directory: Optional target directory
            
        Returns:
            SetupResult with complete setup information
        """
        agent_logger.info(f"Starting repository setup workflow for: {repository_url}")
        
        # Initialize state
        initial_state = AgentState(
            repository_url=repository_url,
            target_directory=target_directory
        )
        
        try:
            # Run the workflow
            final_state = await self.workflow.ainvoke(initial_state)
            
            # Extract and return results
            if final_state.setup_result:
                return final_state.setup_result
            else:
                # Create a failure result
                repo_info = RepositoryInfo(
                    url=repository_url,
                    local_path=target_directory or Path("unknown"),
                    clone_success=False
                )
                return SetupResult(
                    repository=repo_info,
                    detection=None,
                    success=False
                )
                
        except Exception as e:
            agent_logger.error(f"Workflow execution failed: {e}")
            raise
    
    async def validate_input(self, state: AgentState) -> AgentState:
        """Validate input parameters."""
        agent_logger.info("Validating input parameters")
        
        if not state.setup_result:
            # Initialize setup result
            repo_info = RepositoryInfo(
                url=state.repository_url,
                local_path=state.target_directory or Path("unknown"),
                clone_success=False
            )
            state.setup_result = SetupResult(
                repository=repo_info,
                detection=None
            )
        
        # Add validation operation
        operation = state.setup_result.add_operation(
            "validate_input",
            "Validate repository URL and target directory"
        )
        operation.start()
        
        try:
            # Validate repository URL
            if not state.repository_url or not isinstance(state.repository_url, str):
                raise ValueError("Invalid repository URL")
            
            # Validate URL format using repository manager
            if not self.repo_manager._is_valid_repo_url(state.repository_url):
                raise ValueError(f"Invalid repository URL format: {state.repository_url}")
            
            operation.complete("Input validation successful")
            agent_logger.success("Input validation completed")
            
        except Exception as e:
            operation.fail(str(e))
            state.increment_error()
            agent_logger.error(f"Input validation failed: {e}")
        
        return state
    
    async def clone_repository(self, state: AgentState) -> AgentState:
        """Clone the repository."""
        agent_logger.info(f"Cloning repository: {state.repository_url}")
        
        operation = state.setup_result.add_operation(
            "clone_repository",
            f"Clone repository from {state.repository_url}"
        )
        operation.start()
        
        try:
            # Clone repository
            repo_info = await self.repo_manager.clone_repository(
                state.repository_url,
                state.target_directory
            )
            
            # Update state
            state.setup_result.repository = repo_info
            state.target_directory = repo_info.local_path
            state.cloned = repo_info.clone_success
            
            if state.cloned:
                operation.complete(f"Repository cloned to {repo_info.local_path}")
                agent_logger.success(f"Repository cloned successfully to {repo_info.local_path}")
            else:
                operation.fail("Repository cloning failed")
                state.increment_error()
            
        except Exception as e:
            operation.fail(str(e))
            state.increment_error()
            agent_logger.error(f"Repository cloning failed: {e}")
        
        return state
    
    async def detect_project_type(self, state: AgentState) -> AgentState:
        """Detect project type and language."""
        agent_logger.info("Detecting project type")
        
        operation = state.setup_result.add_operation(
            "detect_project",
            "Analyze project structure and detect language/framework"
        )
        operation.start()
        
        try:
            # Detect project type
            detection = await self.detector.detect_project_type(state.target_directory)
            
            # Update state
            state.setup_result.detection = detection
            state.detected = True
            
            operation.complete(
                f"Detected {detection.language.value} project "
                f"(confidence: {detection.confidence:.2f})"
            )
            
            agent_logger.success(
                f"Project detection completed: {detection.language.value}",
                confidence=detection.confidence,
                frameworks=detection.framework_indicators
            )
            
        except Exception as e:
            operation.fail(str(e))
            state.increment_error()
            agent_logger.error(f"Project detection failed: {e}")
        
        return state
    
    async def analyze_requirements(self, state: AgentState) -> AgentState:
        """Analyze project requirements using LLM."""
        agent_logger.info("Analyzing project requirements")
        
        operation = state.setup_result.add_operation(
            "analyze_requirements",
            "Analyze project structure and determine setup requirements"
        )
        operation.start()
        
        try:
            detection = state.setup_result.detection
            if not detection:
                raise ValueError("Project detection not completed")
            
            # Get recommended setup
            setup_recommendations = self.detector.get_recommended_setup(detection)
            
            # Use LLM to analyze complex scenarios
            if detection.language == ProjectLanguage.UNKNOWN or detection.confidence < 0.5:
                analysis = await self._llm_analyze_project(state.target_directory, detection)
                # Update recommendations based on LLM analysis
                setup_recommendations.update(analysis)
            
            # Store analysis results in state
            state.current_operation = "analysis_complete"
            
            operation.complete("Requirements analysis completed")
            agent_logger.success(
                f"Requirements analysis completed",
                language=detection.language.value,
                environment_needed=setup_recommendations.get("environment_needed", False),
                frameworks=setup_recommendations.get("frameworks", [])
            )
            
        except Exception as e:
            operation.fail(str(e))
            state.increment_error()
            agent_logger.error(f"Requirements analysis failed: {e}")
        
        return state
    
    async def create_environment(self, state: AgentState) -> AgentState:
        """Create development environment."""
        agent_logger.info("Creating development environment")
        
        operation = state.setup_result.add_operation(
            "create_environment",
            "Create virtual environment for the project"
        )
        operation.start()
        
        try:
            detection = state.setup_result.detection
            if not detection:
                raise ValueError("Project detection not completed")
            
            # Create environment
            env_info = await self.env_manager.create_environment(
                state.target_directory,
                detection,
                force=config.force_environment_creation
            )
            
            if env_info:
                state.setup_result.environment = env_info
                state.environment_created = True
                operation.complete(f"Created {env_info.type} environment at {env_info.path}")
                
                agent_logger.success(
                    f"Environment created successfully",
                    env_type=env_info.type,
                    env_path=str(env_info.path)
                )
            else:
                operation.skip("Environment not needed for this project type")
                state.environment_created = True  # Mark as complete even if skipped
            
        except Exception as e:
            operation.fail(str(e))
            state.increment_error()
            agent_logger.error(f"Environment creation failed: {e}")
        
        return state
    
    async def install_dependencies(self, state: AgentState) -> AgentState:
        """Install project dependencies."""
        agent_logger.info("Installing project dependencies")
        
        operation = state.setup_result.add_operation(
            "install_dependencies",
            "Install all project dependencies and packages"
        )
        operation.start()
        
        try:
            detection = state.setup_result.detection
            environment = state.setup_result.environment
            
            if not detection:
                raise ValueError("Project detection not completed")
            
            # Install dependencies
            installations = await self.dep_manager.install_dependencies(
                state.target_directory,
                detection,
                environment
            )
            
            # Store installation results
            state.setup_result.dependencies = installations
            
            # Check success rate
            successful = sum(1 for inst in installations if inst.success)
            total = len(installations)
            
            if total == 0:
                operation.skip("No dependencies to install")
                state.dependencies_installed = True
            elif successful == total:
                operation.complete(f"All dependencies installed successfully ({successful}/{total})")
                state.dependencies_installed = True
            elif successful > 0:
                operation.complete(f"Partial dependency installation ({successful}/{total})")
                state.dependencies_installed = True  # Continue with partial success
            else:
                operation.fail(f"All dependency installations failed ({successful}/{total})")
                state.increment_error()
            
            agent_logger.info(
                f"Dependency installation completed",
                successful=successful,
                total=total,
                success_rate=f"{successful/total*100:.1f}%" if total > 0 else "N/A"
            )
            
        except Exception as e:
            operation.fail(str(e))
            state.increment_error()
            agent_logger.error(f"Dependency installation failed: {e}")
        
        return state
    
    async def configure_project(self, state: AgentState) -> AgentState:
        """Configure project settings and files."""
        agent_logger.info("Configuring project settings")
        
        operation = state.setup_result.add_operation(
            "configure_project",
            "Configure project settings and create necessary files"
        )
        operation.start()
        
        try:
            detection = state.setup_result.detection
            if not detection:
                raise ValueError("Project detection not completed")
            
            # Create configuration files based on project type
            created_files = await self._create_config_files(state.target_directory, detection)
            
            # Store created files
            state.setup_result.created_files.extend(created_files)
            state.configured = True
            
            if created_files:
                operation.complete(f"Created configuration files: {', '.join(created_files)}")
            else:
                operation.complete("Project configuration completed (no additional files needed)")
            
            agent_logger.success(
                f"Project configuration completed",
                created_files=created_files
            )
            
        except Exception as e:
            operation.fail(str(e))
            state.increment_error()
            agent_logger.error(f"Project configuration failed: {e}")
        
        return state
    
    async def validate_setup(self, state: AgentState) -> AgentState:
        """Validate the complete setup."""
        agent_logger.info("Validating setup completion")
        
        operation = state.setup_result.add_operation(
            "validate_setup",
            "Validate that all setup steps completed successfully"
        )
        operation.start()
        
        try:
            validation_results = []
            
            # Validate repository
            if state.setup_result.repository.clone_success:
                validation_results.append("✓ Repository cloned")
            else:
                validation_results.append("✗ Repository clone failed")
            
            # Validate detection
            if state.setup_result.detection and state.setup_result.detection.confidence > 0.3:
                validation_results.append(f"✓ Project detected as {state.setup_result.detection.language.value}")
            else:
                validation_results.append("⚠ Project detection uncertain")
            
            # Validate environment
            if state.setup_result.environment:
                env_valid = await self.env_manager.validate_environment(state.setup_result.environment)
                if env_valid:
                    validation_results.append(f"✓ Environment ({state.setup_result.environment.type}) created")
                else:
                    validation_results.append(f"✗ Environment validation failed")
            
            # Validate dependencies
            if state.setup_result.dependencies:
                successful_deps = sum(1 for dep in state.setup_result.dependencies if dep.success)
                total_deps = len(state.setup_result.dependencies)
                if successful_deps == total_deps:
                    validation_results.append(f"✓ All dependencies installed ({successful_deps}/{total_deps})")
                elif successful_deps > 0:
                    validation_results.append(f"⚠ Partial dependencies installed ({successful_deps}/{total_deps})")
                else:
                    validation_results.append(f"✗ Dependency installation failed")
            
            # Overall validation
            critical_failures = [r for r in validation_results if r.startswith("✗")]
            if not critical_failures:
                operation.complete("Setup validation passed: " + "; ".join(validation_results))
                state.setup_result.success = True
            else:
                operation.fail("Setup validation failed: " + "; ".join(critical_failures))
                state.increment_error()
            
            agent_logger.info(
                f"Setup validation completed",
                results=validation_results,
                success=state.setup_result.success
            )
            
        except Exception as e:
            operation.fail(str(e))
            state.increment_error()
            agent_logger.error(f"Setup validation failed: {e}")
        
        return state
    
    async def handle_error(self, state: AgentState) -> AgentState:
        """Handle errors and determine recovery strategy."""
        agent_logger.warning(f"Handling error (attempt {state.error_count}/{state.max_retries})")
        
        operation = state.setup_result.add_operation(
            "error_handling",
            f"Handle error and determine recovery strategy"
        )
        operation.start()
        
        try:
            # Analyze failed operations
            failed_ops = state.setup_result.failed_operations
            
            if failed_ops:
                last_failure = failed_ops[-1]
                agent_logger.error(
                    f"Last operation failed: {last_failure.name}",
                    error=last_failure.error_message
                )
                
                # Use LLM to suggest recovery strategy if needed
                if state.can_retry():
                    recovery_strategy = await self._determine_recovery_strategy(state, last_failure)
                    operation.complete(f"Recovery strategy: {recovery_strategy}")
                else:
                    operation.fail("Maximum retry attempts reached")
            else:
                operation.complete("No specific error to handle")
            
        except Exception as e:
            operation.fail(str(e))
            agent_logger.error(f"Error handling failed: {e}")
        
        return state
    
    async def finalize_setup(self, state: AgentState) -> AgentState:
        """Finalize the setup process."""
        agent_logger.info("Finalizing setup process")
        
        operation = state.setup_result.add_operation(
            "finalize",
            "Complete setup process and generate summary"
        )
        operation.start()
        
        try:
            # Calculate total duration
            total_duration = sum(
                op.duration for op in state.setup_result.operations 
                if op.duration is not None
            )
            state.setup_result.total_duration = total_duration
            
            # Generate setup summary
            summary = self._generate_setup_summary(state.setup_result)
            
            operation.complete(f"Setup finalized in {total_duration:.2f}s")
            
            if state.setup_result.success:
                agent_logger.success(
                    f"Repository setup completed successfully",
                    repository=state.repository_url,
                    target_directory=str(state.target_directory),
                    duration=total_duration,
                    summary=summary
                )
            else:
                agent_logger.warning(
                    f"Repository setup completed with issues",
                    repository=state.repository_url,
                    target_directory=str(state.target_directory),
                    duration=total_duration,
                    summary=summary
                )
            
        except Exception as e:
            operation.fail(str(e))
            agent_logger.error(f"Setup finalization failed: {e}")
        
        return state
    
    # Conditional edge functions
    def check_clone_status(self, state: AgentState) -> str:
        """Check repository cloning status."""
        if state.cloned:
            return "success"
        elif state.can_retry():
            return "retry"
        else:
            return "failure"
    
    def check_analysis_status(self, state: AgentState) -> str:
        """Check analysis status and determine next step."""
        if not state.setup_result.detection:
            return "no_dependencies"
        
        detection = state.setup_result.detection
        recommendations = self.detector.get_recommended_setup(detection)
        
        if recommendations.get("environment_needed", False):
            return "needs_environment"
        elif recommendations.get("install_commands"):
            return "skip_environment"
        else:
            return "no_dependencies"
    
    def check_dependency_status(self, state: AgentState) -> str:
        """Check dependency installation status."""
        if not state.setup_result.dependencies:
            return "success"  # No dependencies to install
        
        successful = sum(1 for dep in state.setup_result.dependencies if dep.success)
        total = len(state.setup_result.dependencies)
        
        if successful == total:
            return "success"
        elif successful > 0:
            return "partial"
        elif state.can_retry():
            return "retry"
        else:
            return "failure"
    
    def check_validation_status(self, state: AgentState) -> str:
        """Check validation status."""
        if state.setup_result.success:
            return "success"
        else:
            return "failure"
    
    def check_error_recovery(self, state: AgentState) -> str:
        """Check if error recovery should be attempted."""
        if state.can_retry():
            return "retry"
        else:
            return "abort"
    
    # Helper methods
    async def _llm_analyze_project(self, project_path: Path, detection) -> Dict[str, Any]:
        """Use LLM to analyze complex project scenarios."""
        try:
            # Read key files for analysis
            key_files = []
            for file_pattern in ["README*", "package.json", "requirements.txt", "*.md"]:
                key_files.extend(list(project_path.glob(file_pattern)))
            
            # Prepare context for LLM
            file_contents = []
            for file_path in key_files[:5]:  # Limit to first 5 files
                try:
                    if file_path.stat().st_size < 10000:  # Only read small files
                        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                            content = f.read()
                            file_contents.append(f"{file_path.name}:\n{content[:1000]}")
                except Exception:
                    continue
            
            # LLM prompt
            prompt = f"""
            Analyze this project and provide setup recommendations:
            
            Detection Results:
            - Language: {detection.language.value}
            - Confidence: {detection.confidence}
            - Files: {detection.detected_files}
            - Frameworks: {detection.framework_indicators}
            
            Key Files:
            {chr(10).join(file_contents)}
            
            Please provide:
            1. Environment setup recommendations
            2. Dependency installation strategy
            3. Any special configuration needed
            
            Respond in JSON format with keys: environment_needed, install_commands, special_config
            """
            
            response = await self.llm.ainvoke(prompt)
            
            # Parse LLM response (simplified - in production, use structured output)
            # For now, return basic recommendations
            return {
                "environment_needed": detection.language != ProjectLanguage.UNKNOWN,
                "install_commands": [],
                "special_config": []
            }
            
        except Exception as e:
            agent_logger.warning(f"LLM analysis failed: {e}")
            return {}
    
    async def _create_config_files(self, project_path: Path, detection) -> List[str]:
        """Create necessary configuration files."""
        created_files = []
        
        try:
            # Create .gitignore if it doesn't exist
            gitignore_path = project_path / ".gitignore"
            if not gitignore_path.exists():
                gitignore_content = self._get_gitignore_template(detection.language)
                if gitignore_content:
                    with open(gitignore_path, 'w') as f:
                        f.write(gitignore_content)
                    created_files.append(".gitignore")
            
            # Create environment activation script for Python
            if detection.language == ProjectLanguage.PYTHON:
                venv_path = project_path / "venv"
                if venv_path.exists():
                    activate_script = project_path / "activate_env.bat" if os.name == "nt" else project_path / "activate_env.sh"
                    if not activate_script.exists():
                        content = self._get_activation_script(venv_path)
                        with open(activate_script, 'w') as f:
                            f.write(content)
                        created_files.append(activate_script.name)
            
        except Exception as e:
            agent_logger.warning(f"Failed to create some config files: {e}")
        
        return created_files
    
    def _get_gitignore_template(self, language: ProjectLanguage) -> str:
        """Get appropriate .gitignore template for the language."""
        templates = {
            ProjectLanguage.PYTHON: """
# Byte-compiled / optimized / DLL files
__pycache__/
*.py[cod]
*$py.class

# Virtual environments
venv/
env/
.venv/

# IDE
.vscode/
.idea/
*.swp
*.swo

# OS
.DS_Store
Thumbs.db
""",
            ProjectLanguage.JAVASCRIPT: """
# Dependencies
node_modules/
npm-debug.log*
yarn-debug.log*
yarn-error.log*

# Production
build/
dist/

# Environment
.env
.env.local

# IDE
.vscode/
.idea/

# OS
.DS_Store
Thumbs.db
""",
            ProjectLanguage.TYPESCRIPT: """
# Dependencies
node_modules/
npm-debug.log*
yarn-debug.log*
yarn-error.log*

# Compiled output
dist/
build/
*.tsbuildinfo

# Environment
.env
.env.local

# IDE
.vscode/
.idea/

# OS
.DS_Store
Thumbs.db
"""
        }
        return templates.get(language, "")
    
    def _get_activation_script(self, venv_path: Path) -> str:
        """Get environment activation script."""
        if os.name == "nt":  # Windows
            return f"""@echo off
call "{venv_path}\\Scripts\\activate.bat"
echo Virtual environment activated!
"""
        else:  # Unix-like
            return f"""#!/bin/bash
source "{venv_path}/bin/activate"
echo "Virtual environment activated!"
"""
    
    async def _determine_recovery_strategy(self, state: AgentState, failed_operation) -> str:
        """Determine recovery strategy for failed operations."""
        # Simple recovery strategies
        if failed_operation.name == "clone_repository":
            return "retry_clone_with_different_method"
        elif failed_operation.name == "install_dependencies":
            return "retry_with_individual_commands"
        elif failed_operation.name == "create_environment":
            return "skip_environment_creation"
        else:
            return "continue_with_warnings"
    
    def _generate_setup_summary(self, setup_result: SetupResult) -> Dict[str, Any]:
        """Generate a summary of the setup process."""
        completed_ops = setup_result.completed_operations
        failed_ops = setup_result.failed_operations
        
        return {
            "repository_url": setup_result.repository.url,
            "local_path": str(setup_result.repository.local_path),
            "detected_language": setup_result.detection.language.value if setup_result.detection else "unknown",
            "confidence": setup_result.detection.confidence if setup_result.detection else 0.0,
            "frameworks": setup_result.detection.framework_indicators if setup_result.detection else [],
            "operations_completed": len(completed_ops),
            "operations_failed": len(failed_ops),
            "environment_created": setup_result.environment is not None,
            "dependencies_installed": len([d for d in setup_result.dependencies if d.success]),
            "total_duration": setup_result.total_duration,
            "success": setup_result.success
        } 