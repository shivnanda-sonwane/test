#!/usr/bin/env python3
"""
Launcher script for the Repository Setup Agent Streamlit Interface.

This script provides a convenient way to launch the Streamlit app with
proper error handling and setup validation.
"""

import os
import sys
import subprocess
from pathlib import Path


def check_dependencies():
    """Check if required dependencies are installed."""
    required_packages = [
        'streamlit',
        'plotly', 
        'pandas',
        'numpy',
        'repo_agent'
    ]
    
    missing_packages = []
    
    for package in required_packages:
        try:
            __import__(package)
        except ImportError:
            missing_packages.append(package)
    
    return missing_packages


def check_environment():
    """Check if environment is properly configured."""
    issues = []
    
    # Check OpenAI API key
    if not os.getenv('OPENAI_API_KEY'):
        issues.append("⚠️  OPENAI_API_KEY environment variable not set")
    
    # Check if git is available
    try:
        subprocess.run(['git', '--version'], capture_output=True, check=True)
    except (subprocess.CalledProcessError, FileNotFoundError):
        issues.append("❌ Git is not installed or not in PATH")
    
    return issues


def main():
    """Main launcher function."""
    print("🚀 Repository Setup Agent - Streamlit Interface")
    print("=" * 60)
    
    # Check if we're in the right directory
    if not Path('streamlit_app.py').exists():
        print("❌ Error: streamlit_app.py not found")
        print("   Please run this script from the project root directory")
        sys.exit(1)
    
    # Check dependencies
    print("🔍 Checking dependencies...")
    missing_deps = check_dependencies()
    
    if missing_deps:
        print("❌ Missing dependencies:")
        for dep in missing_deps:
            print(f"   - {dep}")
        
        print("\n💡 To install missing dependencies:")
        print("   pip install -r requirements_streamlit.txt")
        
        install = input("\n🤔 Would you like to install them now? (y/N): ").strip().lower()
        if install in ['y', 'yes']:
            try:
                print("📦 Installing dependencies...")
                subprocess.run([
                    sys.executable, '-m', 'pip', 'install', 
                    '-r', 'requirements_streamlit.txt'
                ], check=True)
                print("✅ Dependencies installed successfully!")
            except subprocess.CalledProcessError:
                print("❌ Failed to install dependencies")
                sys.exit(1)
        else:
            print("⏹️  Installation cancelled")
            sys.exit(1)
    else:
        print("✅ All dependencies are installed")
    
    # Check environment
    print("🔧 Checking environment configuration...")
    env_issues = check_environment()
    
    if env_issues:
        print("⚠️  Environment issues found:")
        for issue in env_issues:
            print(f"   {issue}")
        
        print("\n💡 Setup recommendations:")
        if not os.getenv('OPENAI_API_KEY'):
            print("   1. Set OpenAI API key: export OPENAI_API_KEY=your_key_here")
        
        print("   2. The app will still work but with limited functionality")
        
        proceed = input("\n🤔 Continue anyway? (Y/n): ").strip().lower()
        if proceed in ['n', 'no']:
            print("⏹️  Launch cancelled")
            sys.exit(1)
    else:
        print("✅ Environment is properly configured")
    
    # Create workspace directory if it doesn't exist
    workspace = Path('./streamlit-workspace')
    if not workspace.exists():
        print(f"📁 Creating workspace directory: {workspace}")
        workspace.mkdir(parents=True, exist_ok=True)
    
    # Launch Streamlit
    print("🚀 Launching Streamlit application...")
    print("📋 Use Ctrl+C to stop the application")
    print("-" * 60)
    
    try:
        # Set environment variables for better Streamlit experience
        env = os.environ.copy()
        env['STREAMLIT_BROWSER_GATHER_USAGE_STATS'] = 'false'
        env['STREAMLIT_SERVER_HEADLESS'] = 'false'
        
        # Launch Streamlit with custom configuration
        cmd = [
            sys.executable, '-m', 'streamlit', 'run', 'streamlit_app.py',
            '--theme.base', 'light',
            '--theme.primaryColor', '#FF6B6B',
            '--theme.backgroundColor', '#FFFFFF',
            '--theme.secondaryBackgroundColor', '#F0F2F6',
            '--theme.textColor', '#262730'
        ]
        
        subprocess.run(cmd, env=env)
        
    except KeyboardInterrupt:
        print("\n⏹️  Streamlit application stopped")
    except Exception as e:
        print(f"\n❌ Error launching Streamlit: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main() 