# 🚀 Repository Setup Agent - Streamlit Interface

A beautiful, user-friendly web interface for the LangGraph Repository Setup Agent that provides intuitive access to all automated repository setup capabilities.

## ✨ Features

### 🎯 Core Interface Features
- **Single Repository Setup** - Set up individual repositories with real-time progress tracking
- **Batch Processing** - Handle multiple repositories simultaneously with concurrent processing
- **Repository Analysis** - Get detailed information about repositories without cloning
- **Analytics Dashboard** - Comprehensive insights and statistics about your setups
- **Advanced Configuration** - Fine-tune agent behavior and performance settings
- **Workspace Management** - Monitor and manage your local workspace efficiently

### 🎨 User Experience
- **Responsive Design** - Works on desktop, tablet, and mobile devices
- **Real-time Progress** - Live updates during repository setup operations
- **Interactive Charts** - Beautiful visualizations of your data and performance metrics
- **Dark/Light Themes** - Customizable appearance for comfortable usage
- **Export Capabilities** - Download results, logs, and analytics in multiple formats

## 📦 Installation

### Prerequisites
- Python 3.8 or higher
- Git installed and accessible in PATH
- OpenAI API key (for AI-powered analysis)

### Quick Setup

```bash
# Clone the repository
git clone <your-repository-url>
cd langgraph-repo-agent

# Install Streamlit dependencies
pip install -r requirements_streamlit.txt

# Set your OpenAI API key
export OPENAI_API_KEY=your_openai_api_key_here

# Launch the Streamlit app
python streamlit_run.py
```

### Alternative Launch Methods

```bash
# Direct Streamlit command
streamlit run streamlit_app.py

# With custom configuration
streamlit run streamlit_app.py --server.port 8502 --theme.base dark
```

## 🎯 Quick Start Guide

### 1. Initial Setup
1. **Launch the app** using `python streamlit_run.py`
2. **Configure API Keys** in the sidebar (OpenAI required, GitHub optional)
3. **Set Workspace Directory** (default: `./streamlit-workspace`)
4. **Initialize Agent** by clicking the "Initialize Agent" button

### 2. Single Repository Setup
1. Navigate to the **"🚀 Single Setup"** tab
2. Enter a repository URL (e.g., `https://github.com/user/repository.git`)
3. Optionally specify a custom target directory
4. Click **"🚀 Setup Repository"**
5. Monitor real-time progress and view detailed results

### 3. Batch Repository Setup
1. Go to the **"🔄 Batch Setup"** tab
2. Choose your input method:
   - **Manual Entry**: Enter URLs individually
   - **Upload File**: Upload a text file with URLs (one per line)
   - **Paste List**: Copy/paste multiple URLs
3. Configure base directory and concurrent operations
4. Click **"🚀 Start Batch Setup"**
5. View progress and results for all repositories

## 📊 Interface Overview

### Main Dashboard Tabs

#### 🚀 Single Setup
- **Repository URL Input** - Enter any Git repository URL
- **Custom Target Directory** - Optionally specify where to clone
- **Real-time Progress** - Watch the setup process with live updates
- **Detailed Results** - View detection results, environment info, and dependencies

#### 🔄 Batch Setup
- **Multiple Input Methods** - Manual, file upload, or paste URLs
- **Concurrent Processing** - Configure how many repos to process simultaneously
- **Progress Tracking** - Monitor all setups with individual status updates
- **Batch Results** - Summary statistics and individual repository outcomes

#### 📋 Repository Info
- **Quick Analysis** - Get repository details without cloning
- **GitHub Integration** - Rich information for GitHub repositories
- **Language Detection** - Preview what the agent would detect
- **Repository Metrics** - Stars, forks, size, and other metadata

#### 📊 Results
- **Setup History** - View all your previous repository setups
- **Filtering & Sorting** - Find specific results quickly
- **Performance Metrics** - Success rates, timing, and statistics
- **Export Options** - Download results in CSV or JSON format

### Sidebar Features

#### ⚙️ Configuration Panel
- **API Key Management** - Secure input for OpenAI and GitHub tokens
- **Workspace Settings** - Configure directories and paths
- **Agent Parameters** - Adjust timeouts, concurrency, and logging
- **Performance Tuning** - Optimize for your system and needs

#### 📊 Quick Stats
- **Agent Status** - Current configuration and capabilities
- **Workspace Info** - Repository count and storage usage
- **Supported Languages** - View all supported programming languages

#### 🧹 Workspace Management
- **Storage Monitoring** - Track workspace size and repository count
- **Cleanup Tools** - Remove failed setups or old repositories
- **Statistics** - Detailed workspace analytics

## 🔧 Advanced Features

### Analytics Dashboard (`pages/2_📊_Analytics.py`)
- **Performance Trends** - Track setup times and success rates over time
- **Language Distribution** - See which languages you work with most
- **Framework Analysis** - Detailed breakdown of detected frameworks
- **Interactive Charts** - Hover, zoom, and filter visualizations
- **Export Capabilities** - Download charts and data for reporting

### Advanced Settings (`pages/1_🔧_Advanced_Settings.py`)
- **Fine-grained Configuration** - Detailed control over all agent parameters
- **Package Manager Setup** - Customize behavior for different languages
- **Detection Tuning** - Adjust confidence thresholds and scan parameters
- **Performance Monitoring** - System health and resource usage
- **Log Management** - View, filter, and download logs

### Help & Documentation (`pages/3_📚_Help.py`)
- **Getting Started Guide** - Step-by-step setup instructions
- **Usage Tutorials** - Detailed guides for all features
- **FAQ Section** - Answers to common questions
- **Troubleshooting** - Solutions for common issues
- **API Reference** - Complete programming interface documentation

## 🎨 Customization

### Theme Configuration
The interface supports customizable themes. You can modify the appearance by editing the launch command:

```bash
streamlit run streamlit_app.py \
  --theme.base "dark" \
  --theme.primaryColor "#FF6B6B" \
  --theme.backgroundColor "#0E1117" \
  --theme.secondaryBackgroundColor "#262730" \
  --theme.textColor "#FFFFFF"
```

### Configuration Options
- **Primary Color**: Accent color for buttons and highlights
- **Background Colors**: Main and secondary background colors
- **Text Color**: Primary text color
- **Font**: Choose from available font families

## 📈 Performance & Monitoring

### Real-time Metrics
- **Setup Progress** - Live progress bars and status updates
- **Resource Usage** - CPU, memory, and disk space monitoring
- **Network Activity** - Track repository cloning and API calls
- **Error Tracking** - Real-time error detection and reporting

### Analytics & Insights
- **Success Rates** - Track performance across different languages and frameworks
- **Timing Analysis** - Identify bottlenecks and optimization opportunities
- **Usage Patterns** - Understand your repository setup habits
- **Trend Analysis** - See how your productivity changes over time

## 🔒 Security & Privacy

### Data Protection
- **Local Processing** - All data stays on your machine
- **Secure API Keys** - Keys are masked in the interface and not logged
- **No Data Collection** - The app doesn't send usage data anywhere
- **Workspace Isolation** - Each workspace is completely isolated

### Best Practices
- Use environment variables for API keys in production
- Regularly clean up workspaces to save disk space
- Monitor resource usage for large batch operations
- Keep your OpenAI API key secure and rotate it periodically

## 🛠️ Development & Customization

### Adding New Features
The Streamlit interface is modular and extensible:

```python
# Add new pages in the pages/ directory
# pages/4_🔍_My_Feature.py

import streamlit as st

st.set_page_config(
    page_title="🔍 My Feature",
    page_icon="🔍"
)

st.title("🔍 My Custom Feature")
# Your custom functionality here
```

### Custom Visualizations
Add new charts and visualizations using Plotly:

```python
import plotly.express as px
import plotly.graph_objects as go

# Create custom charts
fig = px.bar(data, x='language', y='count')
st.plotly_chart(fig, use_container_width=True)
```

### Integrating New Agent Features
When you add new features to the core agent, integrate them into the UI:

1. Update the agent interface calls
2. Add new configuration options
3. Create visualizations for new data
4. Update the help documentation

## 📋 Keyboard Shortcuts

- **Ctrl+Shift+R** - Refresh the app
- **Ctrl+Shift+C** - Open browser console (for debugging)
- **Tab** - Navigate between input fields
- **Enter** - Submit forms and start operations
- **Esc** - Cancel modal dialogs

## 🆘 Troubleshooting

### Common Issues

**App won't start:**
```bash
# Check dependencies
pip install -r requirements_streamlit.txt

# Verify Python version
python --version  # Should be 3.8+

# Check for port conflicts
streamlit run streamlit_app.py --server.port 8502
```

**Agent initialization fails:**
- Verify OpenAI API key is set correctly
- Check internet connection
- Ensure all dependencies are installed

**Repository setup fails:**
- Check Git installation: `git --version`
- Verify repository URL is accessible
- Check workspace directory permissions

### Debug Mode
Enable detailed logging:

1. Go to Advanced Settings
2. Set Log Level to "DEBUG"
3. Monitor logs in the interface or check `agent.log`

### Performance Issues
- Reduce concurrent operations for large batches
- Clear workspace of old repositories
- Monitor system resources in the dashboard

## 🤝 Contributing

We welcome contributions to improve the Streamlit interface:

1. **Fork the repository**
2. **Create a feature branch**: `git checkout -b feature/amazing-feature`
3. **Add your improvements**
4. **Test thoroughly** with different repository types
5. **Submit a pull request**

### Areas for Contribution
- New visualizations and charts
- Additional configuration options
- Performance improvements
- UI/UX enhancements
- Documentation updates

## 📄 License

This Streamlit interface is part of the LangGraph Repository Setup Agent and is licensed under the MIT License.

## 🎉 Acknowledgments

- **Streamlit** - For the amazing web app framework
- **Plotly** - For beautiful interactive visualizations  
- **LangGraph** - For the powerful workflow orchestration
- **OpenAI** - For AI-powered project analysis capabilities

---

**Ready to automate your repository setup? Launch the Streamlit interface and experience the future of development workflow automation!**

```bash
python streamlit_run.py
```

🚀 **Happy coding with automated repository setup!** 