"""
Configuration management for the Repository Setup Agent.
"""

import os
from pathlib import Path
from typing import Optional, Dict, Any, List
from pydantic import BaseSettings, Field, validator
from dotenv import load_dotenv

# Load environment variables
load_dotenv()


class AgentConfig(BaseSettings):
    """Configuration settings for the Repository Setup Agent."""
    
    # OpenAI Configuration
    openai_api_key: str = Field(..., env="OPENAI_API_KEY")
    openai_model: str = Field("gpt-4", env="OPENAI_MODEL")
    
    # GitHub Configuration
    github_token: Optional[str] = Field(None, env="GITHUB_TOKEN")
    
    # Agent Configuration
    agent_name: str = Field("RepoSetupAgent", env="AGENT_NAME")
    workspace_dir: Path = Field(Path("./workspace"), env="WORKSPACE_DIR")
    max_concurrent_operations: int = Field(3, env="MAX_CONCURRENT_OPERATIONS")
    timeout_minutes: int = Field(30, env="TIMEOUT_MINUTES")
    
    # Logging Configuration
    log_level: str = Field("INFO", env="LOG_LEVEL")
    log_file: str = Field("agent.log", env="LOG_FILE")
    
    # Project Detection Settings
    auto_detect_language: bool = Field(True, env="AUTO_DETECT_LANGUAGE")
    force_environment_creation: bool = Field(False, env="FORCE_ENVIRONMENT_CREATION")
    skip_existing_environments: bool = Field(True, env="SKIP_EXISTING_ENVIRONMENTS")
    
    # Performance Settings
    enable_async_operations: bool = Field(True, env="ENABLE_ASYNC_OPERATIONS")
    cache_detection_results: bool = Field(True, env="CACHE_DETECTION_RESULTS")
    parallel_dependency_install: bool = Field(True, env="PARALLEL_DEPENDENCY_INSTALL")
    
    # Supported Languages and Tools
    supported_languages: List[str] = Field(default=[
        "python", "javascript", "typescript", "java", "go", "rust", 
        "php", "ruby", "c", "cpp", "csharp", "swift", "kotlin"
    ])
    
    # Package Managers Configuration
    package_managers: Dict[str, Dict[str, Any]] = Field(default={
        "python": {
            "files": ["requirements.txt", "pyproject.toml", "setup.py", "Pipfile"],
            "install_commands": ["pip install -r requirements.txt", "pip install -e ."],
            "venv_command": "python -m venv"
        },
        "javascript": {
            "files": ["package.json", "yarn.lock", "pnpm-lock.yaml"],
            "install_commands": ["npm install", "yarn install", "pnpm install"],
            "venv_command": None
        },
        "typescript": {
            "files": ["package.json", "tsconfig.json"],
            "install_commands": ["npm install", "yarn install"],
            "venv_command": None
        },
        "java": {
            "files": ["pom.xml", "build.gradle", "build.gradle.kts"],
            "install_commands": ["mvn install", "gradle build"],
            "venv_command": None
        },
        "go": {
            "files": ["go.mod", "go.sum"],
            "install_commands": ["go mod download", "go mod tidy"],
            "venv_command": None
        },
        "rust": {
            "files": ["Cargo.toml", "Cargo.lock"],
            "install_commands": ["cargo build"],
            "venv_command": None
        }
    })
    
    @validator("workspace_dir", pre=True)
    def validate_workspace_dir(cls, v):
        """Ensure workspace directory exists."""
        if isinstance(v, str):
            v = Path(v)
        v.mkdir(parents=True, exist_ok=True)
        return v
    
    @validator("log_level")
    def validate_log_level(cls, v):
        """Validate log level."""
        valid_levels = ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
        if v.upper() not in valid_levels:
            raise ValueError(f"Invalid log level. Must be one of: {valid_levels}")
        return v.upper()
    
    @validator("max_concurrent_operations")
    def validate_max_concurrent_operations(cls, v):
        """Validate concurrent operations limit."""
        if v < 1 or v > 10:
            raise ValueError("max_concurrent_operations must be between 1 and 10")
        return v
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False


# Global configuration instance
config = AgentConfig() 