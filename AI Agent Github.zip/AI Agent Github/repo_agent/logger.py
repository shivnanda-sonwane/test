"""
Professional logging system for the Repository Setup Agent.
"""

import sys
import time
from pathlib import Path
from typing import Optional, Dict, Any
from functools import wraps
from loguru import logger
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TimeRemainingColumn

from .config import config

# Rich console for beautiful output
console = Console()


class AgentLogger:
    """Enhanced logger with performance tracking and structured logging."""
    
    def __init__(self, log_file: Optional[str] = None, log_level: str = "INFO"):
        self.log_file = log_file or config.log_file
        self.log_level = log_level or config.log_level
        self._setup_logger()
        self._operation_times: Dict[str, float] = {}
    
    def _setup_logger(self):
        """Setup logger with file and console handlers."""
        # Remove default logger
        logger.remove()
        
        # Console handler with colors
        logger.add(
            sys.stderr,
            format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | "
                   "<level>{level: <8}</level> | "
                   "<cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - "
                   "<level>{message}</level>",
            level=self.log_level,
            colorize=True
        )
        
        # File handler with detailed format
        logger.add(
            self.log_file,
            format="{time:YYYY-MM-DD HH:mm:ss.SSS} | "
                   "{level: <8} | "
                   "{name}:{function}:{line} | "
                   "{extra} | "
                   "{message}",
            level="DEBUG",
            rotation="10 MB",
            retention="7 days",
            compression="zip"
        )
    
    def info(self, message: str, **kwargs):
        """Log info message with context."""
        logger.bind(**kwargs).info(message)
    
    def error(self, message: str, **kwargs):
        """Log error message with context."""
        logger.bind(**kwargs).error(message)
    
    def warning(self, message: str, **kwargs):
        """Log warning message with context."""
        logger.bind(**kwargs).warning(message)
    
    def debug(self, message: str, **kwargs):
        """Log debug message with context."""
        logger.bind(**kwargs).debug(message)
    
    def success(self, message: str, **kwargs):
        """Log success message with context."""
        logger.bind(**kwargs).success(message)
    
    def start_operation(self, operation_name: str, **context):
        """Start tracking an operation."""
        self._operation_times[operation_name] = time.time()
        self.info(f"Starting operation: {operation_name}", operation=operation_name, **context)
    
    def end_operation(self, operation_name: str, success: bool = True, **context):
        """End tracking an operation."""
        if operation_name in self._operation_times:
            duration = time.time() - self._operation_times[operation_name]
            del self._operation_times[operation_name]
            
            status = "completed" if success else "failed"
            log_func = self.success if success else self.error
            
            log_func(
                f"Operation {status}: {operation_name} (took {duration:.2f}s)",
                operation=operation_name,
                duration=duration,
                success=success,
                **context
            )
        else:
            self.warning(f"Operation {operation_name} was not started or already ended")
    
    def log_repo_info(self, repo_url: str, repo_path: Path, **context):
        """Log repository information."""
        self.info(
            f"Processing repository: {repo_url}",
            repo_url=repo_url,
            repo_path=str(repo_path),
            **context
        )
    
    def log_detection_result(self, language: str, files_found: list, **context):
        """Log project detection results."""
        self.info(
            f"Detected {language} project with files: {files_found}",
            language=language,
            files_found=files_found,
            **context
        )
    
    def log_environment_creation(self, env_type: str, env_path: Path, **context):
        """Log environment creation."""
        self.info(
            f"Creating {env_type} environment at: {env_path}",
            env_type=env_type,
            env_path=str(env_path),
            **context
        )
    
    def log_dependency_installation(self, command: str, working_dir: Path, **context):
        """Log dependency installation."""
        self.info(
            f"Installing dependencies: {command}",
            command=command,
            working_dir=str(working_dir),
            **context
        )


def performance_monitor(operation_name: str):
    """Decorator to monitor operation performance."""
    def decorator(func):
        @wraps(func)
        async def async_wrapper(*args, **kwargs):
            agent_logger.start_operation(operation_name)
            try:
                result = await func(*args, **kwargs)
                agent_logger.end_operation(operation_name, success=True)
                return result
            except Exception as e:
                agent_logger.end_operation(operation_name, success=False, error=str(e))
                raise
        
        @wraps(func)
        def sync_wrapper(*args, **kwargs):
            agent_logger.start_operation(operation_name)
            try:
                result = func(*args, **kwargs)
                agent_logger.end_operation(operation_name, success=True)
                return result
            except Exception as e:
                agent_logger.end_operation(operation_name, success=False, error=str(e))
                raise
        
        return async_wrapper if hasattr(func, '__code__') and func.__code__.co_flags & 0x80 else sync_wrapper
    return decorator


def create_progress_bar(description: str = "Processing..."):
    """Create a rich progress bar for operations."""
    return Progress(
        SpinnerColumn(),
        TextColumn("[bold blue]{task.description}"),
        BarColumn(),
        TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
        TimeRemainingColumn(),
        console=console
    )


# Global logger instance
agent_logger = AgentLogger() 