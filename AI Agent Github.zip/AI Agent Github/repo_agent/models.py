"""
Data models for the Repository Setup Agent.
"""

from typing import Optional, List, Dict, Any, Union
from pathlib import Path
from enum import Enum
from pydantic import BaseModel, Field, validator
from datetime import datetime


class ProjectLanguage(str, Enum):
    """Supported project languages."""
    PYTHON = "python"
    JAVASCRIPT = "javascript"
    TYPESCRIPT = "typescript"
    JAVA = "java"
    GO = "go"
    RUST = "rust"
    PHP = "php"
    RUBY = "ruby"
    C = "c"
    CPP = "cpp"
    CSHARP = "csharp"
    SWIFT = "swift"
    KOTLIN = "kotlin"
    UNKNOWN = "unknown"


class OperationStatus(str, Enum):
    """Status of operations."""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


class ProjectDetectionResult(BaseModel):
    """Result of project type detection."""
    language: ProjectLanguage
    confidence: float = Field(ge=0.0, le=1.0)
    detected_files: List[str] = Field(default_factory=list)
    package_manager_files: List[str] = Field(default_factory=list)
    build_files: List[str] = Field(default_factory=list)
    config_files: List[str] = Field(default_factory=list)
    framework_indicators: List[str] = Field(default_factory=list)
    
    @validator("confidence")
    def validate_confidence(cls, v):
        return round(v, 2)


class EnvironmentInfo(BaseModel):
    """Information about created environment."""
    type: str  # venv, conda, node_modules, etc.
    path: Path
    created: bool = False
    activated: bool = False
    python_version: Optional[str] = None
    node_version: Optional[str] = None
    
    class Config:
        arbitrary_types_allowed = True


class DependencyInstallation(BaseModel):
    """Information about dependency installation."""
    command: str
    working_directory: Path
    success: bool = False
    output: str = ""
    error: str = ""
    duration: float = 0.0
    
    class Config:
        arbitrary_types_allowed = True


class RepositoryInfo(BaseModel):
    """Information about the cloned repository."""
    url: str
    local_path: Path
    branch: str = "main"
    commit_hash: Optional[str] = None
    clone_success: bool = False
    clone_time: float = 0.0
    size_mb: float = 0.0
    
    class Config:
        arbitrary_types_allowed = True


class SetupOperation(BaseModel):
    """Individual setup operation."""
    name: str
    description: str
    status: OperationStatus = OperationStatus.PENDING
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    duration: Optional[float] = None
    error_message: Optional[str] = None
    output: Optional[str] = None
    
    def start(self):
        """Mark operation as started."""
        self.status = OperationStatus.IN_PROGRESS
        self.start_time = datetime.now()
    
    def complete(self, output: str = ""):
        """Mark operation as completed."""
        self.status = OperationStatus.COMPLETED
        self.end_time = datetime.now()
        self.output = output
        if self.start_time:
            self.duration = (self.end_time - self.start_time).total_seconds()
    
    def fail(self, error_message: str):
        """Mark operation as failed."""
        self.status = OperationStatus.FAILED
        self.end_time = datetime.now()
        self.error_message = error_message
        if self.start_time:
            self.duration = (self.end_time - self.start_time).total_seconds()
    
    def skip(self, reason: str = ""):
        """Mark operation as skipped."""
        self.status = OperationStatus.SKIPPED
        self.end_time = datetime.now()
        self.output = f"Skipped: {reason}"


class SetupResult(BaseModel):
    """Complete setup result."""
    repository: RepositoryInfo
    detection: ProjectDetectionResult
    environment: Optional[EnvironmentInfo] = None
    dependencies: List[DependencyInstallation] = Field(default_factory=list)
    operations: List[SetupOperation] = Field(default_factory=list)
    success: bool = False
    total_duration: float = 0.0
    created_files: List[str] = Field(default_factory=list)
    
    @property
    def failed_operations(self) -> List[SetupOperation]:
        """Get failed operations."""
        return [op for op in self.operations if op.status == OperationStatus.FAILED]
    
    @property
    def completed_operations(self) -> List[SetupOperation]:
        """Get completed operations."""
        return [op for op in self.operations if op.status == OperationStatus.COMPLETED]
    
    def add_operation(self, name: str, description: str) -> SetupOperation:
        """Add a new operation."""
        operation = SetupOperation(name=name, description=description)
        self.operations.append(operation)
        return operation


class AgentState(BaseModel):
    """State of the LangGraph agent."""
    repository_url: str
    target_directory: Optional[Path] = None
    setup_result: Optional[SetupResult] = None
    current_operation: Optional[str] = None
    error_count: int = 0
    max_retries: int = 3
    
    # Workflow flags
    cloned: bool = False
    detected: bool = False
    environment_created: bool = False
    dependencies_installed: bool = False
    configured: bool = False
    
    class Config:
        arbitrary_types_allowed = True
    
    def can_retry(self) -> bool:
        """Check if operation can be retried."""
        return self.error_count < self.max_retries
    
    def increment_error(self):
        """Increment error count."""
        self.error_count += 1 