"""
LangGraph-based AI Agent for Automatic Repository Setup

A professional-grade AI agent that automatically clones repositories,
detects project types, creates environments, and installs dependencies.
"""

__version__ = "1.0.0"
__author__ = "AI Agent Developer"

from .agent import RepoSetupAgent
from .config import AgentConfig
from .workflow import RepoSetupWorkflow

__all__ = ["RepoSetupAgent", "AgentConfig", "RepoSetupWorkflow"] 