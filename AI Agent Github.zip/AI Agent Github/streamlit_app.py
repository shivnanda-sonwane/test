"""
Streamlit Web Interface for LangGraph Repository Setup Agent

A beautiful, user-friendly web interface for automated repository setup.
"""

import streamlit as st
import asyncio
import os
import json
import time
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any, Optional

# Configure Streamlit page
st.set_page_config(
    page_title="🚀 Repository Setup Agent",
    page_icon="🚀",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Import agent after Streamlit config
try:
    from repo_agent import RepoSetupAgent
    from repo_agent.models import SetupResult, ProjectLanguage
    from repo_agent.config import config
except ImportError as e:
    st.error(f"Failed to import Repository Setup Agent: {e}")
    st.stop()


# Session state initialization
if 'agent' not in st.session_state:
    st.session_state.agent = None
if 'setup_results' not in st.session_state:
    st.session_state.setup_results = []
if 'current_operation' not in st.session_state:
    st.session_state.current_operation = None
if 'workspace_stats' not in st.session_state:
    st.session_state.workspace_stats = {}


def initialize_agent(custom_config: Dict[str, Any] = None) -> RepoSetupAgent:
    """Initialize the agent with configuration."""
    try:
        config_overrides = custom_config or {}
        agent = RepoSetupAgent(config_overrides)
        return agent
    except Exception as e:
        st.error(f"Failed to initialize agent: {e}")
        return None


def format_duration(seconds: float) -> str:
    """Format duration in a human-readable format."""
    if seconds < 60:
        return f"{seconds:.1f}s"
    elif seconds < 3600:
        minutes = seconds / 60
        return f"{minutes:.1f}m"
    else:
        hours = seconds / 3600
        return f"{hours:.1f}h"


def get_language_emoji(language: str) -> str:
    """Get emoji for programming language."""
    emoji_map = {
        'python': '🐍',
        'javascript': '🟨',
        'typescript': '🔷',
        'java': '☕',
        'go': '🐹',
        'rust': '🦀',
        'php': '🐘',
        'ruby': '💎',
        'c': '⚙️',
        'cpp': '⚙️',
        'csharp': '🔷',
        'unknown': '❓'
    }
    return emoji_map.get(language.lower(), '📁')


def display_setup_result(result: SetupResult, index: int = 0):
    """Display a setup result in an organized way."""
    
    # Create columns for layout
    col1, col2, col3 = st.columns([2, 1, 1])
    
    with col1:
        # Repository info
        repo_name = Path(result.repository.url).stem.replace('.git', '')
        language_emoji = get_language_emoji(result.detection.language.value if result.detection else 'unknown')
        
        if result.success:
            st.success(f"✅ {language_emoji} **{repo_name}**")
        else:
            st.error(f"❌ {language_emoji} **{repo_name}**")
        
        st.caption(f"📂 {result.repository.url}")
        st.caption(f"📁 {result.repository.local_path}")
    
    with col2:
        # Project details
        if result.detection:
            st.metric(
                "Language", 
                result.detection.language.value.title(),
                f"{result.detection.confidence:.0%} confidence"
            )
        else:
            st.metric("Language", "Unknown", "0% confidence")
    
    with col3:
        # Timing and stats
        st.metric(
            "Duration", 
            format_duration(result.total_duration),
            f"{len(result.completed_operations)} ops"
        )
    
    # Expandable details
    with st.expander(f"📊 Details for {repo_name}", expanded=False):
        
        # Tabs for different information
        tab1, tab2, tab3, tab4 = st.tabs(["🔍 Detection", "🏗️ Environment", "📦 Dependencies", "⚙️ Operations"])
        
        with tab1:
            if result.detection:
                col1, col2 = st.columns(2)
                with col1:
                    st.write("**Detected Files:**")
                    for file in result.detection.detected_files[:5]:
                        st.caption(f"📄 {file}")
                    if len(result.detection.detected_files) > 5:
                        st.caption(f"... and {len(result.detection.detected_files) - 5} more")
                
                with col2:
                    st.write("**Package Manager Files:**")
                    for file in result.detection.package_manager_files:
                        st.caption(f"📦 {file}")
                    
                    if result.detection.framework_indicators:
                        st.write("**Frameworks:**")
                        for framework in result.detection.framework_indicators:
                            st.caption(f"🔧 {framework}")
            else:
                st.warning("No detection information available")
        
        with tab2:
            if result.environment:
                col1, col2 = st.columns(2)
                with col1:
                    st.metric("Environment Type", result.environment.type)
                    st.metric("Created", "Yes" if result.environment.created else "No")
                
                with col2:
                    st.metric("Path", str(result.environment.path))
                    if result.environment.python_version:
                        st.metric("Python Version", result.environment.python_version)
            else:
                st.info("No environment was created for this project")
        
        with tab3:
            if result.dependencies:
                successful = sum(1 for dep in result.dependencies if dep.success)
                total = len(result.dependencies)
                
                progress = successful / total if total > 0 else 0
                st.progress(progress)
                st.caption(f"✅ {successful}/{total} dependencies installed successfully")
                
                for dep in result.dependencies:
                    status_icon = "✅" if dep.success else "❌"
                    duration_text = format_duration(dep.duration) if dep.duration else "N/A"
                    st.caption(f"{status_icon} `{dep.command}` ({duration_text})")
                    
                    if not dep.success and dep.error:
                        st.error(f"Error: {dep.error[:100]}...")
            else:
                st.info("No dependencies were installed")
        
        with tab4:
            for operation in result.operations:
                status_icons = {
                    "completed": "✅",
                    "failed": "❌",
                    "in_progress": "🔄",
                    "pending": "⏳",
                    "skipped": "⏭️"
                }
                
                icon = status_icons.get(operation.status.value, "❓")
                duration_text = f"({format_duration(operation.duration)})" if operation.duration else ""
                
                st.caption(f"{icon} **{operation.name}** {duration_text}")
                if operation.description:
                    st.caption(f"   {operation.description}")
                
                if operation.error_message:
                    st.error(f"   Error: {operation.error_message}")


def main():
    """Main Streamlit application."""
    
    # Header
    st.title("🚀 Repository Setup Agent")
    st.markdown("**Automated repository cloning, detection, and environment setup powered by LangGraph**")
    
    # Sidebar for configuration and controls
    with st.sidebar:
        st.header("⚙️ Configuration")
        
        # API Key configuration
        openai_key = st.text_input(
            "🔑 OpenAI API Key", 
            value=os.getenv('OPENAI_API_KEY', ''),
            type="password",
            help="Required for AI-powered project analysis"
        )
        
        if openai_key:
            os.environ['OPENAI_API_KEY'] = openai_key
        
        # Workspace configuration
        workspace_dir = st.text_input(
            "📁 Workspace Directory",
            value="./streamlit-workspace",
            help="Directory where repositories will be cloned"
        )
        
        # Agent configuration
        st.subheader("🔧 Agent Settings")
        
        max_concurrent = st.slider(
            "Max Concurrent Operations",
            min_value=1,
            max_value=10,
            value=3,
            help="Maximum number of concurrent operations"
        )
        
        timeout_minutes = st.slider(
            "Timeout (minutes)",
            min_value=5,
            max_value=60,
            value=30,
            help="Operation timeout in minutes"
        )
        
        log_level = st.selectbox(
            "Log Level",
            options=["DEBUG", "INFO", "WARNING", "ERROR"],
            index=1,
            help="Logging verbosity level"
        )
        
        force_env = st.checkbox(
            "Force Environment Recreation",
            value=False,
            help="Force recreation of existing environments"
        )
        
        # Initialize agent with configuration
        agent_config = {
            'workspace_dir': Path(workspace_dir),
            'max_concurrent_operations': max_concurrent,
            'timeout_minutes': timeout_minutes,
            'log_level': log_level,
            'force_environment_creation': force_env
        }
        
        if st.button("🔄 Initialize Agent"):
            with st.spinner("Initializing agent..."):
                st.session_state.agent = initialize_agent(agent_config)
                if st.session_state.agent:
                    st.success("Agent initialized successfully!")
                else:
                    st.error("Failed to initialize agent")
        
        # Display agent info
        if st.session_state.agent:
            st.subheader("📊 Agent Status")
            agent_info = st.session_state.agent.get_agent_info()
            st.metric("Supported Languages", len(agent_info['supported_languages']))
            st.metric("Workspace", str(agent_info['workspace_dir']))
        
        # Workspace management
        st.subheader("🧹 Workspace Management")
        
        if st.button("📊 Check Workspace Stats"):
            if st.session_state.agent:
                try:
                    workspace_path = Path(workspace_dir)
                    if workspace_path.exists():
                        repos = [d for d in workspace_path.iterdir() if d.is_dir() and (d / '.git').exists()]
                        st.session_state.workspace_stats = {
                            'total_repos': len(repos),
                            'workspace_size': sum(
                                sum(f.stat().st_size for f in d.rglob('*') if f.is_file())
                                for d in repos
                            ) / (1024 * 1024),  # MB
                            'repos': [d.name for d in repos]
                        }
                    else:
                        st.session_state.workspace_stats = {'total_repos': 0, 'workspace_size': 0, 'repos': []}
                except Exception as e:
                    st.error(f"Error checking workspace: {e}")
        
        if st.session_state.workspace_stats:
            stats = st.session_state.workspace_stats
            st.metric("Total Repositories", stats['total_repos'])
            st.metric("Workspace Size", f"{stats['workspace_size']:.1f} MB")
        
        if st.button("🧹 Cleanup Workspace", type="secondary"):
            if st.session_state.agent:
                try:
                    with st.spinner("Cleaning up workspace..."):
                        cleanup_stats = asyncio.run(
                            st.session_state.agent.cleanup_workspace(keep_successful=True)
                        )
                    st.success(f"Cleaned: {cleanup_stats['cleaned']}, Kept: {cleanup_stats['kept']}")
                except Exception as e:
                    st.error(f"Cleanup failed: {e}")
    
    # Main content area
    if not st.session_state.agent:
        st.warning("⚠️ Please initialize the agent in the sidebar first")
        
        # Show supported languages as a preview
        try:
            temp_agent = RepoSetupAgent()
            languages = temp_agent.get_supported_languages()
            
            st.subheader("🔧 Supported Technologies")
            
            # Create columns for languages
            cols = st.columns(4)
            for i, lang in enumerate(languages):
                with cols[i % 4]:
                    emoji = get_language_emoji(lang)
                    st.write(f"{emoji} **{lang.title()}**")
        except:
            pass
        
        return
    
    # Main tabs
    tab1, tab2, tab3, tab4 = st.tabs(["🚀 Single Setup", "🔄 Batch Setup", "📋 Repository Info", "📊 Results"])
    
    with tab1:
        st.header("🚀 Single Repository Setup")
        
        col1, col2 = st.columns([3, 1])
        
        with col1:
            repo_url = st.text_input(
                "Repository URL",
                placeholder="https://github.com/user/repository.git",
                help="Enter the Git repository URL to clone and setup"
            )
        
        with col2:
            st.write("")  # Spacing
            st.write("")  # Spacing
            setup_button = st.button("🚀 Setup Repository", type="primary")
        
        # Optional target directory
        custom_target = st.checkbox("Specify custom target directory")
        target_dir = None
        if custom_target:
            target_dir = st.text_input(
                "Target Directory",
                placeholder="./my-project",
                help="Custom directory for the repository (leave empty for auto-generation)"
            )
        
        if setup_button and repo_url:
            try:
                with st.spinner("🔄 Setting up repository..."):
                    # Create progress container
                    progress_container = st.container()
                    
                    with progress_container:
                        progress_bar = st.progress(0)
                        status_text = st.empty()
                        
                        # Simulate progress updates (in real implementation, this would be connected to the agent's progress)
                        steps = [
                            "📥 Cloning repository...",
                            "🔍 Detecting project type...",
                            "🏗️ Creating environment...",
                            "📦 Installing dependencies...",
                            "⚙️ Configuring project...",
                            "✅ Finalizing setup..."
                        ]
                        
                        for i, step in enumerate(steps):
                            status_text.text(step)
                            progress_bar.progress((i + 1) / len(steps))
                            if i < len(steps) - 1:  # Don't sleep on the last step
                                time.sleep(0.5)
                        
                        # Run actual setup
                        target_path = Path(target_dir) if target_dir else None
                        result = asyncio.run(st.session_state.agent.setup_repository(
                            repository_url=repo_url,
                            target_directory=target_path,
                            show_progress=False
                        ))
                        
                        progress_bar.progress(1.0)
                        status_text.text("✅ Setup completed!")
                
                # Store result
                st.session_state.setup_results.append(result)
                
                # Display result
                st.success("🎉 Repository setup completed!")
                display_setup_result(result)
                
            except Exception as e:
                st.error(f"❌ Setup failed: {str(e)}")
    
    with tab2:
        st.header("🔄 Batch Repository Setup")
        
        # Input methods
        input_method = st.radio(
            "Input Method:",
            ["📝 Manual Entry", "📄 Upload File", "📋 Paste List"],
            horizontal=True
        )
        
        repository_urls = []
        
        if input_method == "📝 Manual Entry":
            st.subheader("Enter Repository URLs")
            
            # Dynamic input fields
            if 'num_repos' not in st.session_state:
                st.session_state.num_repos = 2
            
            col1, col2 = st.columns([1, 3])
            with col1:
                num_repos = st.number_input(
                    "Number of repositories:",
                    min_value=1,
                    max_value=20,
                    value=st.session_state.num_repos
                )
                st.session_state.num_repos = num_repos
            
            for i in range(num_repos):
                url = st.text_input(
                    f"Repository {i+1}:",
                    key=f"batch_url_{i}",
                    placeholder=f"https://github.com/user/repo{i+1}.git"
                )
                if url:
                    repository_urls.append(url)
        
        elif input_method == "📄 Upload File":
            uploaded_file = st.file_uploader(
                "Upload a text file with repository URLs (one per line)",
                type=['txt'],
                help="Each line should contain one repository URL"
            )
            
            if uploaded_file:
                content = uploaded_file.read().decode('utf-8')
                lines = [line.strip() for line in content.split('\n')]
                repository_urls = [line for line in lines if line and not line.startswith('#')]
                
                st.success(f"📄 Loaded {len(repository_urls)} repository URLs")
                
                # Show preview
                with st.expander("📋 Preview URLs"):
                    for url in repository_urls:
                        st.caption(f"• {url}")
        
        elif input_method == "📋 Paste List":
            urls_text = st.text_area(
                "Paste repository URLs (one per line):",
                height=150,
                placeholder="https://github.com/user/repo1.git\nhttps://github.com/user/repo2.git\n..."
            )
            
            if urls_text:
                lines = [line.strip() for line in urls_text.split('\n')]
                repository_urls = [line for line in lines if line and not line.startswith('#')]
        
        # Batch configuration
        if repository_urls:
            st.subheader("⚙️ Batch Configuration")
            
            col1, col2 = st.columns(2)
            
            with col1:
                base_directory = st.text_input(
                    "Base Directory:",
                    value="./batch-repos",
                    help="Base directory where all repositories will be cloned"
                )
            
            with col2:
                batch_concurrent = st.slider(
                    "Concurrent Operations:",
                    min_value=1,
                    max_value=min(len(repository_urls), 5),
                    value=min(3, len(repository_urls)),
                    help="Number of repositories to process simultaneously"
                )
            
            st.write(f"📊 **{len(repository_urls)} repositories** will be processed with **{batch_concurrent} concurrent operations**")
            
            # Start batch setup
            if st.button("🚀 Start Batch Setup", type="primary"):
                try:
                    with st.spinner("🔄 Running batch setup..."):
                        
                        # Progress tracking
                        progress_container = st.container()
                        
                        with progress_container:
                            overall_progress = st.progress(0)
                            status_text = st.empty()
                            
                            # Run batch setup
                            results = asyncio.run(st.session_state.agent.setup_multiple_repositories(
                                repository_urls=repository_urls,
                                base_directory=Path(base_directory),
                                max_concurrent=batch_concurrent,
                                show_progress=False
                            ))
                            
                            overall_progress.progress(1.0)
                            status_text.text("✅ Batch setup completed!")
                    
                    # Store results
                    st.session_state.setup_results.extend(results)
                    
                    # Display summary
                    successful = sum(1 for r in results if r.success)
                    total = len(results)
                    
                    if successful == total:
                        st.success(f"🎉 All {total} repositories set up successfully!")
                    else:
                        st.warning(f"⚠️ {successful}/{total} repositories set up successfully")
                    
                    # Display individual results
                    for i, result in enumerate(results):
                        display_setup_result(result, i)
                
                except Exception as e:
                    st.error(f"❌ Batch setup failed: {str(e)}")
    
    with tab3:
        st.header("📋 Repository Information")
        st.markdown("Get information about a repository without cloning it")
        
        info_url = st.text_input(
            "Repository URL:",
            placeholder="https://github.com/user/repository.git",
            help="Enter repository URL to get information"
        )
        
        if st.button("🔍 Get Repository Info") and info_url:
            try:
                with st.spinner("🔍 Fetching repository information..."):
                    repo_info = asyncio.run(st.session_state.agent.get_repository_info(info_url))
                
                if 'error' in repo_info:
                    st.error(f"❌ Error: {repo_info['error']}")
                else:
                    # Display repository information
                    col1, col2, col3 = st.columns(3)
                    
                    with col1:
                        st.metric("Name", repo_info.get('name', 'N/A'))
                        st.metric("Language", repo_info.get('language', 'N/A'))
                        st.metric("Type", repo_info.get('type', 'N/A'))
                    
                    with col2:
                        st.metric("Stars", repo_info.get('stars', 'N/A'))
                        st.metric("Forks", repo_info.get('forks', 'N/A'))
                        st.metric("Size (KB)", repo_info.get('size', 'N/A'))
                    
                    with col3:
                        st.metric("Default Branch", repo_info.get('default_branch', 'N/A'))
                    
                    # Description
                    if 'description' in repo_info and repo_info['description']:
                        st.subheader("📝 Description")
                        st.write(repo_info['description'])
                    
                    # Raw data in expandable section
                    with st.expander("🔧 Raw Repository Data"):
                        st.json(repo_info)
            
            except Exception as e:
                st.error(f"❌ Failed to get repository info: {str(e)}")
    
    with tab4:
        st.header("📊 Setup Results")
        
        if not st.session_state.setup_results:
            st.info("No setup results yet. Run some repository setups to see results here.")
        else:
            # Summary statistics
            total_results = len(st.session_state.setup_results)
            successful_results = sum(1 for r in st.session_state.setup_results if r.success)
            total_time = sum(r.total_duration for r in st.session_state.setup_results)
            
            # Metrics
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                st.metric("Total Setups", total_results)
            
            with col2:
                st.metric("Successful", successful_results, f"{successful_results/total_results*100:.1f}%")
            
            with col3:
                st.metric("Failed", total_results - successful_results)
            
            with col4:
                st.metric("Total Time", format_duration(total_time))
            
            # Language distribution
            if st.session_state.setup_results:
                languages = {}
                for result in st.session_state.setup_results:
                    if result.detection:
                        lang = result.detection.language.value
                        languages[lang] = languages.get(lang, 0) + 1
                
                if languages:
                    st.subheader("📊 Language Distribution")
                    
                    # Create columns for language stats
                    lang_cols = st.columns(min(len(languages), 4))
                    for i, (lang, count) in enumerate(languages.items()):
                        with lang_cols[i % 4]:
                            emoji = get_language_emoji(lang)
                            st.metric(f"{emoji} {lang.title()}", count)
            
            # Filter and sort options
            st.subheader("🔍 Filter Results")
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                status_filter = st.selectbox(
                    "Status Filter:",
                    ["All", "Successful", "Failed"],
                    index=0
                )
            
            with col2:
                language_filter = st.selectbox(
                    "Language Filter:",
                    ["All"] + list(set(r.detection.language.value for r in st.session_state.setup_results if r.detection)),
                    index=0
                )
            
            with col3:
                sort_by = st.selectbox(
                    "Sort by:",
                    ["Recent First", "Duration (High to Low)", "Duration (Low to High)", "Name"],
                    index=0
                )
            
            # Apply filters
            filtered_results = st.session_state.setup_results
            
            if status_filter == "Successful":
                filtered_results = [r for r in filtered_results if r.success]
            elif status_filter == "Failed":
                filtered_results = [r for r in filtered_results if not r.success]
            
            if language_filter != "All":
                filtered_results = [r for r in filtered_results if r.detection and r.detection.language.value == language_filter]
            
            # Apply sorting
            if sort_by == "Duration (High to Low)":
                filtered_results.sort(key=lambda r: r.total_duration, reverse=True)
            elif sort_by == "Duration (Low to High)":
                filtered_results.sort(key=lambda r: r.total_duration)
            elif sort_by == "Name":
                filtered_results.sort(key=lambda r: Path(r.repository.url).stem)
            # "Recent First" is default order
            
            # Clear results button
            if st.button("🗑️ Clear All Results", type="secondary"):
                st.session_state.setup_results = []
                st.experimental_rerun()
            
            # Display filtered results
            if filtered_results:
                st.subheader(f"📋 Results ({len(filtered_results)})")
                
                for i, result in enumerate(filtered_results):
                    display_setup_result(result, i)
            else:
                st.info("No results match the current filters.")


if __name__ == "__main__":
    # Async wrapper for Streamlit
    try:
        import asyncio
        import nest_asyncio
        nest_asyncio.apply()  # Allow nested event loops in Streamlit
        
        main()
    except Exception as e:
        st.error(f"Application error: {e}")
        st.exception(e) 