"""
Help & Documentation Page for Repository Setup Agent

User guides, tutorials, and documentation.
"""

import streamlit as st

st.set_page_config(
    page_title="📚 Help & Documentation",
    page_icon="📚",
    layout="wide"
)

st.title("📚 Help & Documentation")
st.markdown("**Complete guide to using the Repository Setup Agent**")

# Sidebar navigation
st.sidebar.header("📋 Quick Navigation")
section = st.sidebar.selectbox(
    "Jump to section:",
    [
        "🚀 Getting Started",
        "⚙️ Basic Usage", 
        "🔧 Advanced Features",
        "❓ FAQ",
        "🐛 Troubleshooting",
        "📖 API Reference"
    ]
)

if section == "🚀 Getting Started":
    st.header("🚀 Getting Started")
    
    st.subheader("📋 Prerequisites")
    st.markdown("""
    Before using the Repository Setup Agent, ensure you have:
    
    - **Python 3.8+** installed
    - **Git** installed and accessible in PATH
    - **OpenAI API Key** (required for AI-powered analysis)
    - **GitHub Token** (optional, for private repositories)
    """)
    
    st.subheader("🔧 Installation")
    st.code("""
    # Clone the repository
    git clone <repository-url>
    cd langgraph-repo-agent
    
    # Install dependencies
    pip install -r requirements.txt
    
    # Install the package
    pip install -e .
    
    # Run the Streamlit app
    streamlit run streamlit_app.py
    """, language="bash")
    
    st.subheader("🔑 Configuration")
    st.markdown("""
    1. **Set your OpenAI API Key:**
       - In the sidebar: Configuration → OpenAI API Key
       - Or set environment variable: `export OPENAI_API_KEY=your_key`
    
    2. **Optional GitHub Token:**
       - For private repositories and higher API limits
       - Get token from GitHub Settings → Developer settings → Personal access tokens
    
    3. **Configure Workspace:**
       - Set your preferred workspace directory
       - Default: `./streamlit-workspace`
    """)

elif section == "⚙️ Basic Usage":
    st.header("⚙️ Basic Usage")
    
    tab1, tab2, tab3 = st.tabs(["🚀 Single Setup", "🔄 Batch Setup", "📋 Repository Info"])
    
    with tab1:
        st.subheader("🚀 Single Repository Setup")
        st.markdown("""
        **Steps:**
        1. Navigate to the **Single Setup** tab
        2. Enter a repository URL (e.g., `https://github.com/user/repo.git`)
        3. Optionally specify a custom target directory
        4. Click **Setup Repository**
        
        **What happens:**
        - Repository is cloned to your workspace
        - Project type and language are detected
        - Virtual environment is created (if applicable)
        - Dependencies are installed automatically
        - Project is configured and ready for development
        """)
        
        st.info("💡 **Tip:** The agent supports Python, JavaScript, TypeScript, Java, Go, Rust, PHP, Ruby, and more!")
    
    with tab2:
        st.subheader("🔄 Batch Repository Setup")
        st.markdown("""
        **Three input methods:**
        
        **1. Manual Entry:**
        - Set number of repositories
        - Enter URLs one by one
        
        **2. Upload File:**
        - Create a text file with URLs (one per line)
        - Upload the file
        - Comments starting with `#` are ignored
        
        **3. Paste List:**
        - Copy/paste multiple URLs
        - One URL per line
        
        **Configuration:**
        - Set base directory for all repositories
        - Configure concurrent operations (1-5 recommended)
        - Monitor progress in real-time
        """)
    
    with tab3:
        st.subheader("📋 Repository Information")
        st.markdown("""
        Get information about a repository **without cloning it:**
        
        - Repository name and description
        - Primary programming language
        - Stars, forks, and size
        - Default branch
        - Repository type (GitHub, GitLab, etc.)
        
        **Use cases:**
        - Preview before setup
        - Verify repository details
        - Check repository accessibility
        """)

elif section == "🔧 Advanced Features":
    st.header("🔧 Advanced Features")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("⚙️ Configuration Options")
        st.markdown("""
        **Performance Settings:**
        - Max concurrent operations
        - Operation timeout
        - Async operations toggle
        - Parallel dependency installation
        
        **Environment Settings:**
        - Force environment recreation
        - Skip existing environments
        - Auto-detect language
        - Logging verbosity
        
        **Detection Settings:**
        - Confidence thresholds
        - Scan depth limits
        - File size limits
        - Ignore patterns
        """)
    
    with col2:
        st.subheader("📊 Analytics & Monitoring")
        st.markdown("""
        **Analytics Dashboard:**
        - Setup success rates
        - Performance metrics
        - Language distribution
        - Time trends
        
        **Monitoring:**
        - Real-time logs
        - System health metrics
        - Performance tracking
        - Error analysis
        
        **Workspace Management:**
        - Repository statistics
        - Cleanup tools
        - Size monitoring
        """)
    
    st.subheader("🔍 Supported Technologies")
    
    tech_data = {
        "Language": ["Python", "JavaScript", "TypeScript", "Java", "Go", "Rust", "PHP", "Ruby"],
        "Package Manager": ["pip, poetry, pipenv", "npm, yarn, pnpm", "npm, yarn", "Maven, Gradle", "go modules", "Cargo", "Composer", "Bundler"],
        "Environment": ["venv, conda", "node_modules", "node_modules", "JVM", "Built-in", "Built-in", "Built-in", "Built-in"],
        "Frameworks": ["Django, Flask, FastAPI", "React, Vue, Angular", "React, Angular, NestJS", "Spring Boot", "Gin, Fiber", "Actix, Rocket", "Laravel, Symfony", "Rails, Sinatra"]
    }
    
    import pandas as pd
    df = pd.DataFrame(tech_data)
    st.dataframe(df, use_container_width=True)

elif section == "❓ FAQ":
    st.header("❓ Frequently Asked Questions")
    
    faqs = [
        {
            "question": "🔑 Do I need an OpenAI API key?",
            "answer": "Yes, an OpenAI API key is required for AI-powered project analysis. The agent can still work with basic functionality without it, but AI features will be limited."
        },
        {
            "question": "🐙 Can I use this with private repositories?",
            "answer": "Yes! Provide a GitHub Personal Access Token in the configuration to access private repositories."
        },
        {
            "question": "⚡ How many repositories can I process at once?",
            "answer": "You can configure concurrent operations (1-10). We recommend 3-5 for optimal performance depending on your system resources."
        },
        {
            "question": "🔄 What if a setup fails?",
            "answer": "The agent has retry mechanisms and detailed error reporting. Check the logs for specific issues and try again. You can also use the cleanup tools to remove failed setups."
        },
        {
            "question": "📁 Where are repositories stored?",
            "answer": "By default in `./streamlit-workspace`. You can configure a custom workspace directory in the settings."
        },
        {
            "question": "🧹 How do I clean up old repositories?",
            "answer": "Use the workspace management tools in Advanced Settings or the cleanup button in the sidebar."
        },
        {
            "question": "📊 Can I export the results?",
            "answer": "Yes! The Analytics page provides CSV and JSON export options for all data and statistics."
        },
        {
            "question": "🚀 Does this work offline?",
            "answer": "Repository cloning requires internet access. The AI analysis requires OpenAI API access. Local operations work offline."
        }
    ]
    
    for faq in faqs:
        with st.expander(faq["question"]):
            st.write(faq["answer"])

elif section == "🐛 Troubleshooting":
    st.header("🐛 Troubleshooting")
    
    st.subheader("🔧 Common Issues")
    
    issues = [
        {
            "problem": "❌ Git not found",
            "solution": "Install Git and ensure it's in your PATH:\n- Windows: Download from git-scm.com\n- macOS: `brew install git`\n- Linux: `sudo apt install git`"
        },
        {
            "problem": "🔑 OpenAI API errors",
            "solution": "Check your API key:\n- Verify the key is correct\n- Check your OpenAI account billing\n- Ensure you have API access"
        },
        {
            "problem": "🐍 Python environment issues",
            "solution": "Python environment problems:\n- Ensure Python 3.8+ is installed\n- Check virtual environment creation permissions\n- Try running with elevated permissions"
        },
        {
            "problem": "🌐 Network timeouts",
            "solution": "Network issues:\n- Check internet connection\n- Increase timeout in settings\n- Try smaller repositories first"
        },
        {
            "problem": "💾 Permission errors",
            "solution": "File permission issues:\n- Check workspace directory permissions\n- Run with appropriate user permissions\n- Verify disk space availability"
        },
        {
            "problem": "📦 Dependency installation fails",
            "solution": "Dependency issues:\n- Check package manager installation\n- Verify network access to package repositories\n- Check project's dependency files"
        }
    ]
    
    for issue in issues:
        with st.expander(issue["problem"]):
            st.code(issue["solution"])
    
    st.subheader("🔍 Debug Mode")
    st.markdown("""
    **Enable debug logging:**
    1. Go to Advanced Settings
    2. Set Log Level to "DEBUG"
    3. Check the logs in the Monitoring section
    
    **Manual debugging:**
    ```bash
    # Run with debug logging
    export LOG_LEVEL=DEBUG
    streamlit run streamlit_app.py
    
    # Check agent logs
    tail -f agent.log
    ```
    """)

elif section == "📖 API Reference":
    st.header("📖 API Reference")
    
    st.subheader("🐍 Python API")
    
    st.markdown("**Basic Usage:**")
    st.code("""
import asyncio
from repo_agent import RepoSetupAgent

async def main():
    # Initialize agent
    agent = RepoSetupAgent()
    
    # Setup single repository
    result = await agent.setup_repository(
        repository_url="https://github.com/user/repo.git",
        target_directory=Path("./my-project")
    )
    
    if result.success:
        print(f"✅ Setup completed!")
        print(f"Language: {result.detection.language}")
        print(f"Location: {result.repository.local_path}")

asyncio.run(main())
    """, language="python")
    
    st.markdown("**Batch Processing:**")
    st.code("""
# Batch setup
results = await agent.setup_multiple_repositories(
    repository_urls=[
        "https://github.com/user/repo1.git",
        "https://github.com/user/repo2.git"
    ],
    base_directory=Path("./projects"),
    max_concurrent=3
)

successful = sum(1 for r in results if r.success)
print(f"Completed: {successful}/{len(results)}")
    """, language="python")
    
    st.subheader("🖥️ Command Line Interface")
    
    st.markdown("**Available Commands:**")
    st.code("""
# Single repository setup
repo-agent setup https://github.com/user/repo.git

# Batch setup
repo-agent batch repo1.git repo2.git repo3.git

# Repository information
repo-agent info https://github.com/user/repo.git

# List supported languages
repo-agent languages

# Show agent status
repo-agent status

# Cleanup workspace
repo-agent cleanup
    """, language="bash")
    
    st.subheader("📊 Data Models")
    
    st.markdown("**SetupResult:**")
    st.code("""
class SetupResult:
    repository: RepositoryInfo      # Repository information
    detection: ProjectDetectionResult  # Language/framework detection
    environment: EnvironmentInfo    # Virtual environment details
    dependencies: List[DependencyInstallation]  # Dependency results
    operations: List[SetupOperation]  # All operations performed
    success: bool                   # Overall success status
    total_duration: float          # Total time taken
    created_files: List[str]       # Files created during setup
    """, language="python")

# Footer
st.markdown("---")
st.subheader("🤝 Need More Help?")

col1, col2, col3 = st.columns(3)

with col1:
    st.markdown("""
    **📧 Contact Support**
    - Email: support@example.com
    - Response time: 24 hours
    """)

with col2:
    st.markdown("""
    **🐛 Report Issues**
    - GitHub Issues
    - Include logs and error details
    """)

with col3:
    st.markdown("""
    **📖 Documentation**
    - Full documentation
    - API reference
    - Examples repository
    """)

st.info("💡 **Pro Tip:** Use the Analytics dashboard to monitor your setup patterns and optimize your workflow!") 