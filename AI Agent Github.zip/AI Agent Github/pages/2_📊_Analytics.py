"""
Analytics Dashboard for Repository Setup Agent

Comprehensive statistics and insights about repository setups.
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from datetime import datetime, timedelta
import json

st.set_page_config(
    page_title="📊 Analytics Dashboard",
    page_icon="📊",
    layout="wide"
)

st.title("📊 Analytics Dashboard")
st.markdown("**Comprehensive insights and statistics about repository setup operations**")

# Generate sample data for demonstration
@st.cache_data
def generate_sample_data():
    """Generate sample analytics data."""
    np.random.seed(42)
    
    # Time series data
    dates = pd.date_range('2024-01-01', periods=90, freq='D')
    
    # Repository setup data
    setups_data = []
    languages = ['python', 'javascript', 'typescript', 'java', 'go', 'rust', 'php', 'ruby']
    frameworks = {
        'python': ['django', 'flask', 'fastapi', 'streamlit'],
        'javascript': ['react', 'vue', 'angular', 'express'],
        'typescript': ['react', 'angular', 'nestjs', 'next.js'],
        'java': ['spring', 'maven', 'gradle'],
        'go': ['gin', 'fiber', 'echo'],
        'rust': ['actix', 'rocket', 'warp'],
        'php': ['laravel', 'symfony', 'codeigniter'],
        'ruby': ['rails', 'sinatra', 'hanami']
    }
    
    for i, date in enumerate(dates):
        # Number of setups per day (varying with some pattern)
        base_setups = 5 + 3 * np.sin(i / 7) + np.random.poisson(3)
        
        for _ in range(int(base_setups)):
            language = np.random.choice(languages, p=[0.25, 0.20, 0.15, 0.12, 0.08, 0.06, 0.08, 0.06])
            framework = np.random.choice(frameworks.get(language, ['none']))
            
            # Success rate varies by language
            success_rates = {
                'python': 0.94, 'javascript': 0.91, 'typescript': 0.89,
                'java': 0.87, 'go': 0.96, 'rust': 0.93,
                'php': 0.88, 'ruby': 0.90
            }
            
            success = np.random.random() < success_rates.get(language, 0.90)
            
            # Setup time varies by language and complexity
            base_time = {
                'python': 120, 'javascript': 90, 'typescript': 110,
                'java': 180, 'go': 60, 'rust': 150,
                'php': 100, 'ruby': 130
            }
            
            setup_time = max(30, np.random.normal(
                base_time.get(language, 120), 
                base_time.get(language, 120) * 0.3
            ))
            
            setups_data.append({
                'date': date,
                'language': language,
                'framework': framework,
                'success': success,
                'setup_time': setup_time,
                'repository_size_mb': max(1, np.random.exponential(20)),
                'dependencies_count': max(0, np.random.poisson(15)),
                'files_detected': max(1, np.random.poisson(50))
            })
    
    return pd.DataFrame(setups_data)

# Load data
df = generate_sample_data()

# Sidebar filters
st.sidebar.header("🔍 Filters")

# Date range filter
date_range = st.sidebar.date_input(
    "📅 Date Range",
    value=(df['date'].min().date(), df['date'].max().date()),
    min_value=df['date'].min().date(),
    max_value=df['date'].max().date()
)

# Language filter
languages = ['All'] + sorted(df['language'].unique().tolist())
selected_languages = st.sidebar.multiselect(
    "🔧 Languages",
    options=languages,
    default=['All']
)

# Success filter
success_filter = st.sidebar.selectbox(
    "✅ Success Status",
    options=['All', 'Successful Only', 'Failed Only'],
    index=0
)

# Apply filters
filtered_df = df.copy()

# Date filter
if len(date_range) == 2:
    start_date, end_date = date_range
    filtered_df = filtered_df[
        (filtered_df['date'].dt.date >= start_date) & 
        (filtered_df['date'].dt.date <= end_date)
    ]

# Language filter
if 'All' not in selected_languages and selected_languages:
    filtered_df = filtered_df[filtered_df['language'].isin(selected_languages)]

# Success filter
if success_filter == 'Successful Only':
    filtered_df = filtered_df[filtered_df['success'] == True]
elif success_filter == 'Failed Only':
    filtered_df = filtered_df[filtered_df['success'] == False]

# Main dashboard
if filtered_df.empty:
    st.warning("No data matches the selected filters.")
    st.stop()

# Key Metrics Row
st.subheader("📈 Key Metrics")

col1, col2, col3, col4, col5 = st.columns(5)

total_setups = len(filtered_df)
successful_setups = len(filtered_df[filtered_df['success']])
success_rate = successful_setups / total_setups if total_setups > 0 else 0
avg_setup_time = filtered_df['setup_time'].mean()
total_repos_size = filtered_df['repository_size_mb'].sum()

with col1:
    st.metric(
        "Total Setups",
        f"{total_setups:,}",
        delta=f"+{int(total_setups * 0.12)}" if total_setups > 0 else None
    )

with col2:
    st.metric(
        "Success Rate",
        f"{success_rate:.1%}",
        delta=f"+{2.1:.1f}%" if success_rate > 0 else None
    )

with col3:
    st.metric(
        "Avg Setup Time",
        f"{avg_setup_time:.0f}s",
        delta=f"-{5:.0f}s" if avg_setup_time > 0 else None
    )

with col4:
    st.metric(
        "Total Data",
        f"{total_repos_size:.1f} MB",
        delta=f"+{total_repos_size * 0.08:.1f} MB" if total_repos_size > 0 else None
    )

with col5:
    unique_languages = filtered_df['language'].nunique()
    st.metric(
        "Languages Used",
        f"{unique_languages}",
        delta=f"+{1}" if unique_languages > 0 else None
    )

# Charts Row 1
st.subheader("📊 Trends & Distribution")

col1, col2 = st.columns(2)

with col1:
    # Daily setups trend
    daily_stats = filtered_df.groupby('date').agg({
        'success': ['count', 'sum'],
        'setup_time': 'mean'
    }).round(2)
    
    daily_stats.columns = ['total_setups', 'successful_setups', 'avg_setup_time']
    daily_stats = daily_stats.reset_index()
    
    fig_trend = make_subplots(
        rows=2, cols=1,
        subplot_titles=('Daily Setup Count', 'Average Setup Time'),
        vertical_spacing=0.1
    )
    
    # Setup count
    fig_trend.add_trace(
        go.Scatter(
            x=daily_stats['date'],
            y=daily_stats['total_setups'],
            mode='lines+markers',
            name='Total Setups',
            line=dict(color='#1f77b4')
        ),
        row=1, col=1
    )
    
    fig_trend.add_trace(
        go.Scatter(
            x=daily_stats['date'],
            y=daily_stats['successful_setups'],
            mode='lines+markers',
            name='Successful Setups',
            line=dict(color='#2ca02c')
        ),
        row=1, col=1
    )
    
    # Setup time
    fig_trend.add_trace(
        go.Scatter(
            x=daily_stats['date'],
            y=daily_stats['avg_setup_time'],
            mode='lines+markers',
            name='Avg Setup Time',
            line=dict(color='#ff7f0e')
        ),
        row=2, col=1
    )
    
    fig_trend.update_layout(
        height=500,
        title_text="📈 Setup Trends Over Time",
        showlegend=True
    )
    
    fig_trend.update_xaxes(title_text="Date", row=2, col=1)
    fig_trend.update_yaxes(title_text="Count", row=1, col=1)
    fig_trend.update_yaxes(title_text="Seconds", row=2, col=1)
    
    st.plotly_chart(fig_trend, use_container_width=True)

with col2:
    # Language distribution
    lang_stats = filtered_df.groupby('language').agg({
        'success': ['count', 'sum', 'mean'],
        'setup_time': 'mean'
    }).round(2)
    
    lang_stats.columns = ['total', 'successful', 'success_rate', 'avg_time']
    lang_stats = lang_stats.reset_index().sort_values('total', ascending=False)
    
    # Create donut chart for language distribution
    fig_lang = go.Figure(data=[go.Pie(
        labels=lang_stats['language'],
        values=lang_stats['total'],
        hole=.3,
        hovertemplate="<b>%{label}</b><br>" +
                      "Setups: %{value}<br>" +
                      "Percentage: %{percent}<br>" +
                      "<extra></extra>"
    )])
    
    fig_lang.update_layout(
        title_text="🔧 Language Distribution",
        height=500,
        showlegend=True,
        legend=dict(
            orientation="v",
            yanchor="middle",
            y=0.5,
            xanchor="left",
            x=1.01
        )
    )
    
    st.plotly_chart(fig_lang, use_container_width=True)

# Charts Row 2
col1, col2 = st.columns(2)

with col1:
    # Success rate by language
    fig_success = px.bar(
        lang_stats,
        x='language',
        y='success_rate',
        title='✅ Success Rate by Language',
        color='success_rate',
        color_continuous_scale='RdYlGn',
        range_color=[0.8, 1.0]
    )
    
    fig_success.update_layout(height=400)
    fig_success.update_yaxes(title_text="Success Rate", tickformat=".0%")
    fig_success.update_xaxes(title_text="Language")
    
    st.plotly_chart(fig_success, use_container_width=True)

with col2:
    # Setup time by language
    fig_time = px.box(
        filtered_df,
        x='language',
        y='setup_time',
        title='⏱️ Setup Time Distribution by Language',
        color='language'
    )
    
    fig_time.update_layout(height=400, showlegend=False)
    fig_time.update_yaxes(title_text="Setup Time (seconds)")
    fig_time.update_xaxes(title_text="Language")
    
    st.plotly_chart(fig_time, use_container_width=True)

# Framework Analysis
st.subheader("🔧 Framework Analysis")

framework_stats = filtered_df.groupby(['language', 'framework']).agg({
    'success': ['count', 'sum'],
    'setup_time': 'mean'
}).round(2)

framework_stats.columns = ['total_setups', 'successful_setups', 'avg_setup_time']
framework_stats = framework_stats.reset_index()
framework_stats = framework_stats[framework_stats['total_setups'] >= 3]  # Filter for significance

if not framework_stats.empty:
    # Sunburst chart for language-framework relationship
    fig_sunburst = px.sunburst(
        framework_stats,
        path=['language', 'framework'],
        values='total_setups',
        title='🌅 Language-Framework Hierarchy',
        color='avg_setup_time',
        color_continuous_scale='Viridis'
    )
    
    fig_sunburst.update_layout(height=500)
    st.plotly_chart(fig_sunburst, use_container_width=True)

# Performance Analysis
st.subheader("⚡ Performance Analysis")

col1, col2 = st.columns(2)

with col1:
    # Setup time vs Repository size
    fig_scatter = px.scatter(
        filtered_df,
        x='repository_size_mb',
        y='setup_time',
        color='language',
        size='dependencies_count',
        hover_data=['framework', 'success'],
        title='📊 Setup Time vs Repository Size',
        labels={
            'repository_size_mb': 'Repository Size (MB)',
            'setup_time': 'Setup Time (seconds)',
            'dependencies_count': 'Dependencies Count'
        }
    )
    
    fig_scatter.update_layout(height=400)
    st.plotly_chart(fig_scatter, use_container_width=True)

with col2:
    # Dependencies impact on setup time
    deps_bins = pd.cut(filtered_df['dependencies_count'], bins=5)
    deps_analysis = filtered_df.groupby(deps_bins)['setup_time'].agg(['mean', 'std', 'count']).reset_index()
    deps_analysis['dependencies_range'] = deps_analysis['dependencies_count'].astype(str)
    
    fig_deps = px.bar(
        deps_analysis,
        x='dependencies_range',
        y='mean',
        error_y='std',
        title='📦 Setup Time vs Dependencies Count',
        labels={
            'dependencies_range': 'Dependencies Range',
            'mean': 'Average Setup Time (seconds)'
        }
    )
    
    fig_deps.update_layout(height=400)
    st.plotly_chart(fig_deps, use_container_width=True)

# Detailed Statistics Table
st.subheader("📋 Detailed Statistics")

# Create detailed stats by language
detailed_stats = filtered_df.groupby('language').agg({
    'success': ['count', 'sum', 'mean'],
    'setup_time': ['mean', 'median', 'std'],
    'repository_size_mb': ['mean', 'sum'],
    'dependencies_count': 'mean',
    'files_detected': 'mean'
}).round(2)

# Flatten column names
detailed_stats.columns = [
    'Total Setups', 'Successful Setups', 'Success Rate',
    'Avg Setup Time', 'Median Setup Time', 'Setup Time Std',
    'Avg Repo Size (MB)', 'Total Repo Size (MB)',
    'Avg Dependencies', 'Avg Files Detected'
]

detailed_stats = detailed_stats.reset_index()

# Format the table
styled_stats = detailed_stats.style.format({
    'Success Rate': '{:.1%}',
    'Avg Setup Time': '{:.0f}s',
    'Median Setup Time': '{:.0f}s',
    'Setup Time Std': '{:.0f}s',
    'Avg Repo Size (MB)': '{:.1f}',
    'Total Repo Size (MB)': '{:.1f}',
    'Avg Dependencies': '{:.0f}',
    'Avg Files Detected': '{:.0f}'
}).background_gradient(subset=['Success Rate'], cmap='RdYlGn')

st.dataframe(styled_stats, use_container_width=True)

# Export functionality
st.subheader("📤 Export Data")

col1, col2, col3 = st.columns(3)

with col1:
    # Export filtered data as CSV
    csv_data = filtered_df.to_csv(index=False)
    st.download_button(
        label="📥 Download Raw Data (CSV)",
        data=csv_data,
        file_name=f"setup_data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
        mime="text/csv"
    )

with col2:
    # Export summary statistics
    summary_data = detailed_stats.to_csv(index=False)
    st.download_button(
        label="📥 Download Summary (CSV)",
        data=summary_data,
        file_name=f"setup_summary_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
        mime="text/csv"
    )

with col3:
    # Export configuration
    config_data = {
        "filters": {
            "date_range": [str(date_range[0]), str(date_range[1])] if len(date_range) == 2 else None,
            "languages": selected_languages,
            "success_filter": success_filter
        },
        "summary": {
            "total_setups": int(total_setups),
            "success_rate": float(success_rate),
            "avg_setup_time": float(avg_setup_time),
            "languages_count": int(unique_languages)
        }
    }
    
    st.download_button(
        label="📥 Download Report (JSON)",
        data=json.dumps(config_data, indent=2),
        file_name=f"analytics_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
        mime="application/json"
    )

# Footer with insights
st.markdown("---")
st.subheader("💡 Key Insights")

insights = []

# Generate insights based on data
if not filtered_df.empty:
    # Most popular language
    top_language = lang_stats.iloc[0]['language']
    insights.append(f"🔥 **{top_language.title()}** is the most popular language with {lang_stats.iloc[0]['total']} setups")
    
    # Best success rate
    best_success_lang = lang_stats.loc[lang_stats['success_rate'].idxmax()]
    insights.append(f"🏆 **{best_success_lang['language'].title()}** has the highest success rate at {best_success_lang['success_rate']:.1%}")
    
    # Fastest setup
    fastest_lang = lang_stats.loc[lang_stats['avg_time'].idxmin()]
    insights.append(f"⚡ **{fastest_lang['language'].title()}** has the fastest average setup time at {fastest_lang['avg_time']:.0f} seconds")
    
    # Recent trend
    recent_days = 7
    if len(daily_stats) >= recent_days:
        recent_avg = daily_stats.tail(recent_days)['total_setups'].mean()
        overall_avg = daily_stats['total_setups'].mean()
        if recent_avg > overall_avg * 1.1:
            insights.append(f"📈 Setup activity has increased by {(recent_avg/overall_avg - 1)*100:.1f}% in the last {recent_days} days")
        elif recent_avg < overall_avg * 0.9:
            insights.append(f"📉 Setup activity has decreased by {(1 - recent_avg/overall_avg)*100:.1f}% in the last {recent_days} days")

for insight in insights:
    st.markdown(f"• {insight}")

if not insights:
    st.info("Generate more data to see insights and recommendations!") 