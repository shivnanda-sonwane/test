"""
Advanced Settings Page for Repository Setup Agent

Detailed configuration and management options.
"""

import streamlit as st
import asyncio
import os
import json
from pathlib import Path
from datetime import datetime

st.set_page_config(
    page_title="🔧 Advanced Settings",
    page_icon="🔧",
    layout="wide"
)

st.title("🔧 Advanced Settings")
st.markdown("**Detailed configuration and management options for the Repository Setup Agent**")

# Load current configuration
try:
    from repo_agent.config import config as default_config
    from repo_agent import RepoSetupAgent
except ImportError:
    st.error("Failed to import Repository Setup Agent")
    st.stop()

# Tabs for different settings categories
tab1, tab2, tab3, tab4, tab5 = st.tabs([
    "⚙️ Agent Config", 
    "🔑 API Keys", 
    "📁 Workspace", 
    "🔍 Detection", 
    "📊 Monitoring"
])

with tab1:
    st.header("⚙️ Agent Configuration")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("🚀 Performance Settings")
        
        max_concurrent = st.number_input(
            "Max Concurrent Operations",
            min_value=1,
            max_value=20,
            value=getattr(default_config, 'max_concurrent_operations', 3),
            help="Maximum number of repositories to process simultaneously"
        )
        
        timeout_minutes = st.number_input(
            "Operation Timeout (minutes)",
            min_value=1,
            max_value=120,
            value=getattr(default_config, 'timeout_minutes', 30),
            help="Timeout for individual operations"
        )
        
        enable_async = st.checkbox(
            "Enable Async Operations",
            value=getattr(default_config, 'enable_async_operations', True),
            help="Enable asynchronous processing for better performance"
        )
        
        parallel_deps = st.checkbox(
            "Parallel Dependency Installation",
            value=getattr(default_config, 'parallel_dependency_install', True),
            help="Install dependencies in parallel when possible"
        )
        
        cache_results = st.checkbox(
            "Cache Detection Results",
            value=getattr(default_config, 'cache_detection_results', True),
            help="Cache project detection results to avoid redundant analysis"
        )
    
    with col2:
        st.subheader("🔧 Environment Settings")
        
        force_env_creation = st.checkbox(
            "Force Environment Recreation",
            value=getattr(default_config, 'force_environment_creation', False),
            help="Always recreate environments even if they exist"
        )
        
        skip_existing_envs = st.checkbox(
            "Skip Existing Environments",
            value=getattr(default_config, 'skip_existing_environments', True),
            help="Skip environment creation if one already exists"
        )
        
        auto_detect_language = st.checkbox(
            "Auto-detect Project Language",
            value=getattr(default_config, 'auto_detect_language', True),
            help="Automatically detect project programming language"
        )
        
        log_level = st.selectbox(
            "Logging Level",
            options=["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
            index=1,  # INFO
            help="Set the verbosity of logging output"
        )
    
    # Package Manager Configuration
    st.subheader("📦 Package Manager Configuration")
    
    package_managers = getattr(default_config, 'package_managers', {})
    
    selected_language = st.selectbox(
        "Configure Package Manager for:",
        options=list(package_managers.keys()),
        help="Select a language to configure its package manager settings"
    )
    
    if selected_language and selected_language in package_managers:
        pm_config = package_managers[selected_language]
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.write("**Package Files:**")
            files = st.text_area(
                "Files (one per line):",
                value="\n".join(pm_config.get('files', [])),
                height=100,
                key=f"files_{selected_language}"
            )
        
        with col2:
            st.write("**Install Commands:**")
            commands = st.text_area(
                "Commands (one per line):",
                value="\n".join(pm_config.get('install_commands', [])),
                height=100,
                key=f"commands_{selected_language}"
            )
        
        venv_command = st.text_input(
            "Virtual Environment Command:",
            value=pm_config.get('venv_command', ''),
            help="Command to create virtual environment (leave empty if not applicable)"
        )
        
        if st.button(f"💾 Save {selected_language.title()} Configuration"):
            # In a real implementation, this would save to configuration
            st.success(f"Configuration saved for {selected_language}")

with tab2:
    st.header("🔑 API Keys & Authentication")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("🤖 OpenAI Configuration")
        
        openai_key = st.text_input(
            "OpenAI API Key",
            value=os.getenv('OPENAI_API_KEY', ''),
            type="password",
            help="Required for AI-powered project analysis"
        )
        
        openai_model = st.selectbox(
            "OpenAI Model",
            options=["gpt-4", "gpt-4-turbo-preview", "gpt-3.5-turbo"],
            index=0,
            help="Model to use for AI analysis"
        )
        
        if st.button("🧪 Test OpenAI Connection"):
            if openai_key:
                try:
                    os.environ['OPENAI_API_KEY'] = openai_key
                    # Test connection (simplified)
                    st.success("✅ OpenAI connection test successful!")
                except Exception as e:
                    st.error(f"❌ OpenAI connection failed: {e}")
            else:
                st.warning("Please enter your OpenAI API key first")
    
    with col2:
        st.subheader("🐙 GitHub Configuration")
        
        github_token = st.text_input(
            "GitHub Personal Access Token",
            value=os.getenv('GITHUB_TOKEN', ''),
            type="password",
            help="Optional - for accessing private repositories and higher API limits"
        )
        
        if st.button("🧪 Test GitHub Connection"):
            if github_token:
                try:
                    import requests
                    headers = {'Authorization': f'token {github_token}'}
                    response = requests.get('https://api.github.com/user', headers=headers)
                    if response.status_code == 200:
                        user_data = response.json()
                        st.success(f"✅ GitHub connection successful! Logged in as: {user_data.get('login', 'Unknown')}")
                    else:
                        st.error(f"❌ GitHub connection failed: {response.status_code}")
                except Exception as e:
                    st.error(f"❌ GitHub connection failed: {e}")
            else:
                st.info("No GitHub token provided - public repositories only")
    
    # Environment Variables
    st.subheader("🌍 Environment Variables")
    
    if st.button("💾 Save Environment Variables"):
        env_vars = {
            'OPENAI_API_KEY': openai_key,
            'OPENAI_MODEL': openai_model,
            'GITHUB_TOKEN': github_token
        }
        
        # Save to .env file
        env_content = []
        for key, value in env_vars.items():
            if value:
                env_content.append(f"{key}={value}")
        
        try:
            with open('.env', 'w') as f:
                f.write('\n'.join(env_content))
            st.success("✅ Environment variables saved to .env file")
        except Exception as e:
            st.error(f"❌ Failed to save environment variables: {e}")

with tab3:
    st.header("📁 Workspace Management")
    
    # Current workspace info
    workspace_dir = Path(getattr(default_config, 'workspace_dir', './workspace'))
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("📊 Workspace Statistics")
        
        if workspace_dir.exists():
            # Calculate workspace stats
            total_repos = len([d for d in workspace_dir.iterdir() if d.is_dir() and (d / '.git').exists()])
            
            # Calculate total size
            total_size = 0
            file_count = 0
            for root, dirs, files in os.walk(workspace_dir):
                for file in files:
                    try:
                        file_path = Path(root) / file
                        total_size += file_path.stat().st_size
                        file_count += 1
                    except (OSError, PermissionError):
                        continue
            
            total_size_mb = total_size / (1024 * 1024)
            
            st.metric("Total Repositories", total_repos)
            st.metric("Total Files", file_count)
            st.metric("Total Size", f"{total_size_mb:.1f} MB")
            st.metric("Workspace Path", str(workspace_dir))
            
            # List repositories
            if total_repos > 0:
                st.subheader("📋 Repository List")
                repos = [d for d in workspace_dir.iterdir() if d.is_dir() and (d / '.git').exists()]
                
                for repo in repos[:10]:  # Show first 10
                    repo_size = sum(f.stat().st_size for f in repo.rglob('*') if f.is_file()) / (1024 * 1024)
                    st.caption(f"📁 {repo.name} ({repo_size:.1f} MB)")
                
                if len(repos) > 10:
                    st.caption(f"... and {len(repos) - 10} more repositories")
        else:
            st.warning("Workspace directory does not exist yet")
    
    with col2:
        st.subheader("🧹 Workspace Actions")
        
        # Workspace configuration
        new_workspace = st.text_input(
            "Workspace Directory",
            value=str(workspace_dir),
            help="Path where repositories will be cloned"
        )
        
        if st.button("📁 Create Workspace Directory"):
            try:
                Path(new_workspace).mkdir(parents=True, exist_ok=True)
                st.success(f"✅ Workspace directory created: {new_workspace}")
            except Exception as e:
                st.error(f"❌ Failed to create workspace: {e}")
        
        # Cleanup options
        st.subheader("🧹 Cleanup Options")
        
        cleanup_options = st.multiselect(
            "What to clean up:",
            [
                "Failed setups only",
                "All repositories",
                "Log files",
                "Cache files",
                "Temporary files"
            ],
            default=["Failed setups only"]
        )
        
        if st.button("🧹 Run Cleanup", type="secondary"):
            if workspace_dir.exists():
                cleaned_count = 0
                
                try:
                    if "Failed setups only" in cleanup_options:
                        # Remove repositories without successful setup indicators
                        for repo_dir in workspace_dir.iterdir():
                            if repo_dir.is_dir() and (repo_dir / '.git').exists():
                                # Simple heuristic: if no venv/node_modules, consider failed
                                has_env = (repo_dir / 'venv').exists() or (repo_dir / 'node_modules').exists()
                                if not has_env:
                                    import shutil
                                    shutil.rmtree(repo_dir)
                                    cleaned_count += 1
                    
                    if "Log files" in cleanup_options:
                        for log_file in workspace_dir.glob("*.log"):
                            log_file.unlink()
                            cleaned_count += 1
                    
                    st.success(f"✅ Cleanup completed! Removed {cleaned_count} items")
                    
                except Exception as e:
                    st.error(f"❌ Cleanup failed: {e}")
            else:
                st.warning("Workspace directory does not exist")

with tab4:
    st.header("🔍 Detection & Analysis Settings")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("🎯 Detection Configuration")
        
        confidence_threshold = st.slider(
            "Minimum Confidence Threshold",
            min_value=0.0,
            max_value=1.0,
            value=0.5,
            step=0.05,
            help="Minimum confidence required for language detection"
        )
        
        max_scan_depth = st.number_input(
            "Maximum Scan Depth",
            min_value=1,
            max_value=10,
            value=3,
            help="Maximum directory depth to scan for project files"
        )
        
        max_file_size_mb = st.number_input(
            "Maximum File Size (MB)",
            min_value=1,
            max_value=100,
            value=10,
            help="Maximum file size to analyze for content detection"
        )
        
        ignore_patterns = st.text_area(
            "Ignore Patterns (one per line):",
            value=".git\n__pycache__\nnode_modules\n.vscode\n.idea",
            height=100,
            help="Patterns to ignore during project scanning"
        )
    
    with col2:
        st.subheader("🧠 AI Analysis Settings")
        
        enable_ai_analysis = st.checkbox(
            "Enable AI-Powered Analysis",
            value=True,
            help="Use AI for complex project analysis"
        )
        
        ai_analysis_timeout = st.number_input(
            "AI Analysis Timeout (seconds)",
            min_value=5,
            max_value=300,
            value=30,
            help="Timeout for AI analysis operations"
        )
        
        fallback_detection = st.checkbox(
            "Enable Fallback Detection",
            value=True,
            help="Use rule-based detection if AI analysis fails"
        )
        
        detailed_framework_detection = st.checkbox(
            "Detailed Framework Detection",
            value=True,
            help="Perform detailed framework and library detection"
        )
    
    # Test detection
    st.subheader("🧪 Test Detection")
    
    test_repo_url = st.text_input(
        "Test Repository URL:",
        placeholder="https://github.com/user/repository.git",
        help="Test project detection on a repository"
    )
    
    if st.button("🔍 Test Detection") and test_repo_url:
        try:
            # Create a temporary agent for testing
            agent = RepoSetupAgent()
            
            with st.spinner("Testing detection..."):
                repo_info = asyncio.run(agent.get_repository_info(test_repo_url))
                
                if 'error' not in repo_info:
                    st.success("✅ Detection test successful!")
                    
                    col1, col2 = st.columns(2)
                    with col1:
                        st.metric("Detected Language", repo_info.get('language', 'Unknown'))
                    with col2:
                        st.metric("Repository Type", repo_info.get('type', 'Unknown'))
                    
                    with st.expander("🔧 Full Detection Results"):
                        st.json(repo_info)
                else:
                    st.error(f"❌ Detection failed: {repo_info['error']}")
                    
        except Exception as e:
            st.error(f"❌ Detection test failed: {e}")

with tab5:
    st.header("📊 Monitoring & Logs")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("📈 Performance Metrics")
        
        # Mock performance data (in real implementation, this would come from actual metrics)
        st.metric("Average Setup Time", "2.3 minutes")
        st.metric("Success Rate", "94.2%")
        st.metric("Cache Hit Rate", "78.5%")
        st.metric("Concurrent Operations", "3")
        
        # Performance chart placeholder
        st.subheader("📊 Performance Over Time")
        import matplotlib.pyplot as plt
        import numpy as np
        
        # Generate sample data
        import pandas as pd
        import numpy as np
        dates = pd.date_range('2024-01-01', periods=30, freq='D')
        success_rates = np.random.normal(0.92, 0.05, 30)
        setup_times = np.random.normal(150, 30, 30)  # seconds
        
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 6))
        
        ax1.plot(dates, success_rates, 'g-', linewidth=2)
        ax1.set_title('Success Rate Over Time')
        ax1.set_ylabel('Success Rate')
        ax1.set_ylim(0.8, 1.0)
        
        ax2.plot(dates, setup_times, 'b-', linewidth=2)
        ax2.set_title('Average Setup Time')
        ax2.set_ylabel('Time (seconds)')
        ax2.set_xlabel('Date')
        
        plt.tight_layout()
        st.pyplot(fig)
    
    with col2:
        st.subheader("📋 Recent Logs")
        
        log_level_filter = st.selectbox(
            "Log Level Filter:",
            ["ALL", "DEBUG", "INFO", "WARNING", "ERROR"],
            index=2  # INFO
        )
        
        # Mock log entries
        log_entries = [
            {"time": "2024-01-15 10:30:25", "level": "INFO", "message": "Repository cloned successfully: https://github.com/user/repo.git"},
            {"time": "2024-01-15 10:30:30", "level": "INFO", "message": "Detected Python project with 0.95 confidence"},
            {"time": "2024-01-15 10:30:45", "level": "INFO", "message": "Created virtual environment at /path/to/venv"},
            {"time": "2024-01-15 10:31:20", "level": "WARNING", "message": "Some dependencies failed to install"},
            {"time": "2024-01-15 10:31:25", "level": "INFO", "message": "Setup completed with warnings"},
        ]
        
        # Display logs
        for entry in log_entries:
            level = entry["level"]
            if log_level_filter == "ALL" or level == log_level_filter:
                if level == "ERROR":
                    st.error(f"[{entry['time']}] {entry['message']}")
                elif level == "WARNING":
                    st.warning(f"[{entry['time']}] {entry['message']}")
                elif level == "INFO":
                    st.info(f"[{entry['time']}] {entry['message']}")
                else:
                    st.text(f"[{entry['time']}] [{level}] {entry['message']}")
        
        # Log file download
        if st.button("📥 Download Full Log"):
            # In real implementation, this would provide actual log file
            st.info("Log file download would be implemented here")
    
    # System Health
    st.subheader("🏥 System Health")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("CPU Usage", "45%", "↓ 5%")
    
    with col2:
        st.metric("Memory Usage", "2.1 GB", "↑ 0.3 GB")
    
    with col3:
        st.metric("Disk Space", "87% free", "↓ 2%")
    
    with col4:
        st.metric("Active Operations", "2", "+1")

# Save Configuration
st.markdown("---")
st.subheader("💾 Save Configuration")

col1, col2, col3 = st.columns(3)

with col1:
    if st.button("💾 Save Current Configuration", type="primary"):
        # In real implementation, this would save all current settings
        st.success("✅ Configuration saved successfully!")

with col2:
    if st.button("🔄 Reset to Defaults"):
        # In real implementation, this would reset to default configuration
        st.info("🔄 Configuration reset to defaults")

with col3:
    if st.button("📤 Export Configuration"):
        # Export configuration as JSON
        config_dict = {
            "max_concurrent_operations": max_concurrent,
            "timeout_minutes": timeout_minutes,
            "log_level": log_level,
            "force_environment_creation": force_env_creation,
            "enable_async_operations": enable_async,
            "parallel_dependency_install": parallel_deps
        }
        
        st.download_button(
            label="📥 Download Config JSON",
            data=json.dumps(config_dict, indent=2),
            file_name=f"agent_config_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
            mime="application/json"
        ) 